import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  Smartphone, 
  KeyRound, 
  ArrowRight, 
  RotateCcw, 
  CheckCircle2, 
  Lock, 
  Sparkles,
  Bot,
  AlertCircle
} from 'lucide-react';

interface SecureTestCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerifiedAndStart: (verifiedPhone: string) => void;
  defaultPhone?: string;
  skillTitle?: string;
}

const COUNTRY_CODES = [
  { code: '+91', country: 'IN', label: 'India (+91)' },
  { code: '+1', country: 'US', label: 'United States / Canada (+1)' },
  { code: '+44', country: 'UK', label: 'United Kingdom (+44)' },
  { code: '+61', country: 'AU', label: 'Australia (+61)' },
  { code: '+49', country: 'DE', label: 'Germany (+49)' },
  { code: '+65', country: 'SG', label: 'Singapore (+65)' },
  { code: '+971', country: 'AE', label: 'United Arab Emirates (+971)' },
];

export const SecureTestCheckInModal: React.FC<SecureTestCheckInModalProps> = ({
  isOpen,
  onClose,
  onVerifiedAndStart,
  defaultPhone = '',
  skillTitle = 'Digital Systems & Workflow Coordination',
}) => {
  const [step, setStep] = useState<'PHONE_ENTRY' | 'OTP_ENTRY'>('PHONE_ENTRY');
  const [countryCode, setCountryCode] = useState('+91');
  const [phoneNumber, setPhoneNumber] = useState(() => {
    if (defaultPhone) {
      const cleaned = defaultPhone.replace(/\D/g, '');
      return cleaned.slice(-10);
    }
    return '9820145672';
  });
  const [otpValues, setOtpValues] = useState<string[]>(['', '', '', '', '', '']);
  const [resendTimer, setResendTimer] = useState(30);
  const [isSendingCode, setIsSendingCode] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [demoSentCode, setDemoSentCode] = useState<string>('849201');

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    let interval: any;
    if (step === 'OTP_ENTRY' && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, resendTimer]);

  if (!isOpen) return null;

  const handleSendCode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const cleanNum = phoneNumber.trim().replace(/\D/g, '');
    if (cleanNum.length < 8) {
      setErrorMessage('Please enter a valid mobile number to receive your secure verification code.');
      return;
    }

    setIsSendingCode(true);
    setTimeout(() => {
      setIsSendingCode(false);
      const generatedCode = String(Math.floor(100000 + Math.random() * 900000));
      setDemoSentCode(generatedCode);
      setStep('OTP_ENTRY');
      setResendTimer(30);
      setErrorMessage(null);
    }, 700);
  };

  const handleOtpChange = (index: number, value: string) => {
    const digit = value.slice(-1).replace(/\D/g, '');
    const newValues = [...otpValues];
    newValues[index] = digit;
    setOtpValues(newValues);

    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpValues[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleFillDemoOtp = () => {
    const digits = demoSentCode.split('');
    setOtpValues(digits);
    setErrorMessage(null);
  };

  const handleVerifyOtp = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const enteredOtp = otpValues.join('');
    if (enteredOtp.length !== 6) {
      setErrorMessage('Please enter all 6 digits of the verification code sent to your phone.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      const fullPhone = `${countryCode} ${phoneNumber}`;
      onVerifiedAndStart(fullPhone);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/35 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="quantum-glass bg-white/95 rounded-2xl shadow-xl border border-emerald-500/30 max-w-lg w-full overflow-hidden text-slate-800 relative animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header Bar with Ski branding */}
        <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 text-white p-6 relative overflow-hidden">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 border border-white/30 flex items-center justify-center text-white">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-emerald-100 tracking-wide uppercase">
                Powered by Ski — Your Secure Career Assistant
              </span>
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Ready for Your Assessment?
          </h2>
          <p className="text-xs text-emerald-100 mt-1.5 leading-relaxed">
            To ensure fairness and protect your verified results, please verify your mobile number before your test begins.
          </p>

          <div className="mt-3 flex items-center gap-2 text-[11px] text-emerald-50 bg-emerald-800/60 px-3 py-1.5 rounded-lg border border-emerald-400/30">
            <Lock className="w-3.5 h-3.5 text-emerald-200 shrink-0" />
            <span>Target Field: <strong className="text-white">{skillTitle}</strong></span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {step === 'PHONE_ENTRY' ? (
            /* Step 1: Mobile Number Entry */
            <form onSubmit={handleSendCode} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1.5">
                  Enter Your Mobile Number
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="h-11 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 cursor-pointer"
                    >
                      {COUNTRY_CODES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.code} ({c.country})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="relative flex-1">
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="Enter 10-digit mobile number"
                      className="w-full h-11 px-3.5 bg-white border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                      autoFocus
                    />
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  We will send a quick 6-digit code to verify it is you. No spam, ever.
                </p>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSendingCode}
                  className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  {isSendingCode ? (
                    <span>Sending Code...</span>
                  ) : (
                    <>
                      <span>Send Verification Code</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            /* Step 2: OTP Entry (Appears after code is sent) */
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-700" />
                  <span>
                    Code sent to <strong className="font-mono">{countryCode} {phoneNumber}</strong>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setStep('PHONE_ENTRY')}
                  className="text-[11px] font-bold text-emerald-800 underline hover:text-emerald-950 cursor-pointer"
                >
                  Change
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-2 text-center">
                  Enter the 6-Digit Code
                </label>
                
                {/* 6 Digit Input Boxes */}
                <div className="flex justify-center items-center gap-2 sm:gap-3">
                  {otpValues.map((val, idx) => (
                    <input
                      key={idx}
                      ref={(el) => {
                        inputRefs.current[idx] = el;
                      }}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={val}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                      className="w-11 h-12 text-center text-lg font-bold font-mono bg-slate-50 border-2 border-slate-300 rounded-xl focus:bg-white focus:border-emerald-600 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 text-slate-900 transition-all"
                      autoFocus={idx === 0}
                    />
                  ))}
                </div>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                  <span className="text-slate-500">
                    Code sent via SMS. Didn't receive it?{' '}
                    {resendTimer > 0 ? (
                      <span className="font-semibold text-slate-700">
                        Resend Code in {resendTimer}s
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setResendTimer(30);
                          const generatedCode = String(Math.floor(100000 + Math.random() * 900000));
                          setDemoSentCode(generatedCode);
                        }}
                        className="font-bold text-emerald-700 hover:underline cursor-pointer"
                      >
                        Resend Code Now
                      </button>
                    )}
                  </span>

                  {/* Demo Helper Button */}
                  <button
                    type="button"
                    onClick={handleFillDemoOtp}
                    className="inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 cursor-pointer"
                    title="Click to automatically fill the demo OTP"
                  >
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>Auto-Fill Code: {demoSentCode}</span>
                  </button>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setStep('PHONE_ENTRY')}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isVerifying}
                  className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  {isVerifying ? (
                    <span>Verifying Identity...</span>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Verify & Start Test</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

          {/* Footer / Reassurance Note */}
          <div className="pt-4 border-t border-emerald-500/20">
            <blockquote className="text-[11px] text-slate-500 leading-relaxed italic bg-emerald-50/50 p-3 rounded-xl border border-emerald-500/20">
              <strong className="text-slate-700 not-italic font-semibold block mb-0.5">
                Privacy & Security Guarantee:
              </strong>
              Your mobile number is used strictly for one-time test verification and secure identity confirmation. Once verified, your assessment will launch immediately on screen.
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};
