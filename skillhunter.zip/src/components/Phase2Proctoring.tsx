import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  Video, 
  Monitor, 
  Mic, 
  AlertTriangle, 
  Eye, 
  CheckCircle2, 
  ArrowRight, 
  RefreshCw, 
  Lock, 
  Zap, 
  Info,
  Smartphone,
  Sparkles
} from 'lucide-react';
import { ProctoringState } from '../types';
import { SecureTestCheckInModal } from './SecureTestCheckInModal';

interface Phase2ProctoringProps {
  selectedSkill: string;
  userPhone?: string;
  onProceedToAssessment: (proctoringState: ProctoringState) => void;
}

export const Phase2Proctoring: React.FC<Phase2ProctoringProps> = ({
  selectedSkill,
  userPhone,
  onProceedToAssessment,
}) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isScreenActive, setIsScreenActive] = useState(false);
  const [isMicActive, setIsMicActive] = useState(false);
  const [violations, setViolations] = useState<Array<{ timestamp: string; text: string }>>([]);
  const [gazeStatus, setGazeStatus] = useState<'FOCUSED_ON_SCREEN' | 'LOOKING_AWAY'>('FOCUSED_ON_SCREEN');
  const [micLevel, setMicLevel] = useState(28);
  const [showCheckInModal, setShowCheckInModal] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);

  // Tab Switching Anti-Cheat listener
  useEffect(() => {
    const handleBlur = () => {
      const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setViolations((prev) => [
        { timestamp: time, text: 'Window focus lost (tab switch or background blur detected)' },
        ...prev.slice(0, 4),
      ]);
      setGazeStatus('LOOKING_AWAY');
    };

    const handleFocus = () => {
      setGazeStatus('FOCUSED_ON_SCREEN');
    };

    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);

    // Audio level oscillation simulation
    const interval = setInterval(() => {
      if (isMicActive) {
        setMicLevel(Math.floor(20 + Math.random() * 35));
      }
    }, 400);

    return () => {
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
      clearInterval(interval);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, [isMicActive]);

  const handleStartCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setIsCameraActive(true);
        setIsMicActive(true);
      } else {
        setIsCameraActive(true);
        setIsMicActive(true);
      }
    } catch (e) {
      console.log('Media access fallback to simulated camera feed:', e);
      setIsCameraActive(true);
      setIsMicActive(true);
    }
  };

  const handleStartScreenShare = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        screenStreamRef.current = screenStream;
        if (screenVideoRef.current) {
          screenVideoRef.current.srcObject = screenStream;
        }
        setIsScreenActive(true);
      } else {
        setIsScreenActive(true);
      }
    } catch (e) {
      console.log('Screen share fallback to simulated environment:', e);
      setIsScreenActive(true);
    }
  };

  const handleStartBothSimulatedOrReal = async () => {
    await handleStartCamera();
    await handleStartScreenShare();
  };

  const isReady = isCameraActive && isScreenActive;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 text-slate-800">
      {/* 2050 Quantum Frosted Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-mono font-semibold mb-3 border border-emerald-500/30 shadow-xs">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Phase 2: 2050 Quantum Proctoring & Readiness Setup • Ski Guide</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight sm:text-4xl">
          System Check & Readiness Setup
        </h1>
        <p className="mt-2 text-sm text-slate-600">
          Why we check: A verified camera and screen shield guarantees full merit transparency for global employers.
        </p>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Video & Screen Feeds */}
        <div className="lg:col-span-7 space-y-6">
          {/* WebCam Video Card */}
          <div className="quantum-glass rounded-2xl border border-emerald-500/30 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-emerald-500/20 bg-emerald-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-900 font-mono uppercase tracking-wider">
                  Candidate Identity Video Feed
                </span>
              </div>
              <span
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-mono font-medium flex items-center gap-1 ${
                  isCameraActive
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-500/40 shadow-xs'
                    : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${isCameraActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                {isCameraActive ? 'Identity Locked' : 'Camera Disconnected'}
              </span>
            </div>

            <div className="relative aspect-video bg-slate-800 flex items-center justify-center overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${isCameraActive ? 'block' : 'hidden'}`}
              />

              {isCameraActive && (
                <div className="absolute inset-0 pointer-events-none border-2 border-emerald-400/40 m-4 rounded-xl flex flex-col justify-between p-3">
                  <div className="flex justify-between items-center text-[10px] font-mono text-emerald-300 bg-slate-900/80 px-2 py-0.5 rounded-md border border-emerald-500/30">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      FACE_VERIFIED: PRIMARY_HUMAN
                    </span>
                    <span>GAZE: {gazeStatus}</span>
                  </div>

                  <div className="flex justify-between items-end text-[10px] font-mono text-emerald-300/90">
                    <span>BIO_SHIELD: ACTIVE</span>
                    <span>1080P_60FPS</span>
                  </div>
                </div>
              )}

              {!isCameraActive && (
                <div className="text-center p-6 space-y-3 bg-white/95 w-full h-full flex flex-col items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 border border-emerald-500/30 flex items-center justify-center text-emerald-600 mx-auto">
                    <Video className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-800 font-semibold">
                      Camera permissions required for proctoring
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Ensures singular human identity throughout the assessment
                    </p>
                  </div>
                  <button
                    onClick={handleStartCamera}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all shadow-[0_4px_12px_rgba(16,185,129,0.3)] cursor-pointer"
                  >
                    Enable Camera & Mic
                  </button>
                </div>
              )}
            </div>

            {/* Hardware Metrics Bar */}
            <div className="p-3 bg-white/80 border-t border-emerald-500/20 flex flex-wrap items-center justify-between text-xs gap-3 font-mono">
              <div className="flex items-center gap-2">
                <Mic className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-slate-500">Audio Telemetry:</span>
                <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden flex border border-slate-200">
                  <div
                    className="bg-emerald-500 h-full transition-all duration-300 shadow-[0_0_6px_#10B981]"
                    style={{ width: `${isMicActive ? micLevel : 0}%` }}
                  />
                </div>
                <span className="text-[10px] text-emerald-700 font-bold">{isMicActive ? `${micLevel} dB` : '0 dB'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-slate-500">Gaze Tracking:</span>
                <span className="font-semibold text-emerald-700">Active (Continuous)</span>
              </div>
            </div>
          </div>

          {/* Screen Share Card */}
          <div className="quantum-glass rounded-2xl border border-emerald-500/30 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-emerald-500/20 bg-emerald-50/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-900 font-mono uppercase tracking-wider">
                  Live Screen Stream & Tab Verification
                </span>
              </div>
              <span
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-mono font-medium ${
                  isScreenActive
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-500/40 shadow-xs'
                    : 'bg-slate-100 text-slate-500 border border-slate-200'
                }`}
              >
                {isScreenActive ? 'Screen Stream Locked' : 'Not Shared Yet'}
              </span>
            </div>

            <div className="p-4 bg-white/70 aspect-video flex flex-col items-center justify-center border-dashed border border-emerald-500/30 m-4 rounded-xl">
              {isScreenActive ? (
                screenStreamRef.current ? (
                  <video
                    ref={screenVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-contain rounded-lg"
                  />
                ) : (
                  <div className="text-center p-6 space-y-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                    <p className="text-xs font-bold text-slate-900 font-mono">
                      Screen Share Stream Active (Simulated Proctored Canvas)
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Window blur events and dual-monitor inputs are actively monitored.
                    </p>
                  </div>
                )
              ) : (
                <div className="text-center p-6 space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 border border-emerald-500/30 flex items-center justify-center text-emerald-600 mx-auto">
                    <Monitor className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-800 font-semibold">
                      Entire screen share is required for evaluation
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Prevents third-party assistance and verifies independent technical execution
                    </p>
                  </div>
                  <button
                    onClick={handleStartScreenShare}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all shadow-[0_4px_12px_rgba(16,185,129,0.3)] cursor-pointer"
                  >
                    Share Entire Screen
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Verification Shield & Launch Assessment */}
        <div className="lg:col-span-5 space-y-6">
          {/* Anti-Cheat Shield Status */}
          <div className="quantum-glass rounded-2xl p-5 border border-emerald-500/30 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Anti-Cheat Verification Matrix
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-500/30 font-semibold">
                ACTIVE
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-slate-700">Camera Feed Lock:</span>
                <span className={`font-mono font-bold ${isCameraActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {isCameraActive ? 'VERIFIED' : 'PENDING'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-slate-700">Screen Share Stream:</span>
                <span className={`font-mono font-bold ${isScreenActive ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {isScreenActive ? 'VERIFIED' : 'PENDING'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-slate-700">Window Blur Sentry:</span>
                <span className="text-emerald-700 font-mono font-bold">MONITORING</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-slate-700">Mobile OTP Gate:</span>
                <span className="text-emerald-800 font-mono font-bold">LOCKED AT LAUNCH</span>
              </div>
            </div>

            {/* Live Violation Log */}
            {violations.length > 0 && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-300 space-y-1.5 text-xs">
                <div className="text-[11px] font-bold text-red-600 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                  <span>Proctoring Warnings Recorded ({violations.length})</span>
                </div>
                <ul className="space-y-1 text-[11px] text-slate-700 font-mono">
                  {violations.map((v, i) => (
                    <li key={i} className="flex items-start gap-1">
                      <span className="text-slate-400">[{v.timestamp}]</span>
                      <span className="text-red-600 font-medium">{v.text}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Assessment Target Card */}
          <div className="quantum-glass rounded-2xl p-5 border border-emerald-500/30 space-y-4 shadow-xs">
            <div>
              <span className="text-[10px] font-mono uppercase text-emerald-700 font-bold tracking-wider">
                Evaluation Subject
              </span>
              <div className="text-lg font-bold text-slate-900 mt-0.5">
                {selectedSkill}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                You will complete a 15-minute hands-on practical scenario, submit your artifact, and record a 60-second verbal defense.
              </p>
            </div>

            {/* Launch Evaluation CTA Button */}
            {!isReady ? (
              <div className="space-y-2">
                <button
                  onClick={handleStartBothSimulatedOrReal}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all shadow-[0_4px_16px_rgba(16,185,129,0.3)] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>Turn On Camera & Screen Check</span>
                </button>
                <p className="text-[11px] text-slate-500 text-center font-mono">
                  Enables camera and screen streams simultaneously for assessment readiness.
                </p>
              </div>
            ) : (
              <button
                onClick={() => setShowCheckInModal(true)}
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-sm transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(16,185,129,0.35)] cursor-pointer"
              >
                <span>Begin Practical Evaluation (OTP Check-In)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Secure Mobile & OTP Registration Check-In Modal right before test begins */}
      <SecureTestCheckInModal
        isOpen={showCheckInModal}
        onClose={() => setShowCheckInModal(false)}
        defaultPhone={userPhone}
        skillTitle={selectedSkill}
        onVerifiedAndStart={(verifiedPhone) => {
          setShowCheckInModal(false);
          onProceedToAssessment({
            isScreenSharing: true,
            isCameraActive: true,
            isAudioActive: true,
            antiCheatViolations: violations.map((v) => ({
              timestamp: v.timestamp,
              type: 'TAB_SWITCH',
              description: v.text,
            })),
            faceDetected: true,
            gazeStatus: 'FOCUSED_ON_SCREEN',
            ambientAudioDb: micLevel,
            sessionHeartbeat: Date.now(),
          });
        }}
      />
    </div>
  );
};
