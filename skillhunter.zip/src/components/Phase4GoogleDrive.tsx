import React, { useState } from 'react';
import { 
  FolderGit2, 
  FileText, 
  Upload, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  Plus, 
  Trash2, 
  FileCheck2, 
  HardDrive, 
  RefreshCw,
  Bot,
  Cpu
} from 'lucide-react';
import { DriveDocument, GradingResult, UserProfile } from '../types';
import { INITIAL_DRIVE_DOCS } from '../data/mockData';

interface Phase4GoogleDriveProps {
  user: UserProfile;
  badge: GradingResult | null;
  onProceedToResume: (selectedDocs: DriveDocument[]) => void;
  onOpenMCPModal?: () => void;
}

export const Phase4GoogleDrive: React.FC<Phase4GoogleDriveProps> = ({
  user,
  badge,
  onProceedToResume,
  onOpenMCPModal,
}) => {
  const [docs, setDocs] = useState<DriveDocument[]>(INITIAL_DRIVE_DOCS);
  const [selectedDocIds, setSelectedDocIds] = useState<string[]>(
    INITIAL_DRIVE_DOCS.map((d) => d.id)
  );
  const [isParsing, setIsParsing] = useState(false);
  const [parsedStatus, setParsedStatus] = useState<string | null>(
    '4 documents ingested: Project records, client briefs, and performance summaries mapped.'
  );

  const toggleDocSelection = (id: string) => {
    setSelectedDocIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const newDoc: DriveDocument = {
      id: `drv-${Date.now()}`,
      name: file.name,
      mimeType: file.type || 'application/pdf',
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      modifiedTime: new Date().toISOString().split('T')[0],
      category: file.name.endsWith('.mp4') ? 'VIDEO' : 'PORTFOLIO',
      extractedInsights: [
        'Supplemental candidate work sample and project evidence',
        'Verified compatibility with Skill Hunter profile standards',
      ],
    };

    setDocs((prev) => [newDoc, ...prev]);
    setSelectedDocIds((prev) => [newDoc.id, ...prev]);
  };

  const selectedDocs = docs.filter((d) => selectedDocIds.includes(d.id));

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-slate-800">
      {/* 2050 Quantum Frosted Header */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-mono font-semibold mb-3 border border-emerald-500/30 shadow-xs">
          <HardDrive className="w-3.5 h-3.5 text-emerald-600" />
          <span>Step 4 of 9: 2050 Work Profile Hub & File Storage</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight sm:text-4xl">
          Ski's Quantum File Storage
        </h1>
        <p className="mt-2 text-sm text-slate-600">
          Your verified files and project work, securely stored and organized to back up your skills.
        </p>
      </div>

      <div className="space-y-6">
        {/* Connected Account Bar */}
        <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-5 border border-emerald-500/30 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-500">Connected Account:</span>
                <span className="text-xs font-bold text-slate-900 font-mono">{user.email || 'alex.chen@worksystems.co'}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-500/30">
                  Status: Connected
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                All uploaded documents are encrypted and accessible only by you and Ski.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-xs">
              <Plus className="w-4 h-4" />
              <span>Add New File</span>
              <input
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                accept=".pdf,.docx,.txt,.png,.jpg,.mp4"
              />
            </label>
            {onOpenMCPModal && (
              <button
                type="button"
                onClick={onOpenMCPModal}
                className="px-3 py-2 rounded-xl border border-slate-200 hover:border-emerald-500/40 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer bg-white/80 shadow-xs"
              >
                <Cpu className="w-3.5 h-3.5 text-emerald-600" />
                <span>Connected Tools</span>
              </button>
            )}
          </div>
        </div>

        {/* Saved Files List */}
        <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl border border-emerald-500/30 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 bg-white/90">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 font-mono">
              <FileCheck2 className="w-5 h-5 text-emerald-600" />
              Your Saved Files ({docs.length} Files)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Ski has organized your files so they are ready to use:
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {docs.map((doc, idx) => {
              const isSelected = selectedDocIds.includes(doc.id);
              const displayName = doc.name.replace(/\.[^/.]+$/, '');
              const extension = doc.name.split('.').pop()?.toUpperCase() || 'PDF';

              return (
                <div
                  key={doc.id}
                  onClick={() => toggleDocSelection(doc.id)}
                  className={`p-5 flex items-start justify-between gap-4 transition-colors cursor-pointer ${
                    isSelected ? 'bg-emerald-50/70' : 'hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => {}}
                      className="mt-1 rounded accent-emerald-600 cursor-pointer w-4 h-4"
                    />
                    <div className="w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold font-mono text-slate-700 shrink-0">
                      {idx + 1}
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                        <span>{displayName} ({extension})</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                          {doc.size}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        <strong className="text-emerald-700 font-semibold font-mono">What it shows: </strong>
                        {doc.extractedInsights?.[0] || 'Demonstrates verified practical mastery and real-world results.'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDocs((prev) => prev.filter((d) => d.id !== doc.id));
                      setSelectedDocIds((prev) => prev.filter((id) => id !== doc.id));
                    }}
                    className="text-slate-400 hover:text-red-500 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
                    title="Remove file"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Next Step Banner */}
        <div className="quantum-glass bg-white/80 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold">
              Next Step
            </h4>
            <p className="text-sm text-slate-900 font-semibold">
              Ready to create your job-ready verified profile with Ski?
            </p>
            <p className="text-xs text-slate-500 font-mono">
              {selectedDocs.length} of {docs.length} files selected to back up your application.
            </p>
          </div>

          <button
            type="button"
            onClick={() => onProceedToResume(selectedDocs)}
            className="py-3 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition-all flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <span>Proceed to Step 5: Verified Resume</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
