import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  X, 
  MessageSquare, 
  Bot, 
  Send, 
  Check, 
  Copy, 
  HelpCircle, 
  ChevronUp, 
  ChevronDown,
  RotateCcw
} from 'lucide-react';
import { UserProfile } from '../types';

interface SkiVoiceAgentProps {
  currentPhase: number;
  user: UserProfile;
  onDictateText?: (text: string) => void;
}

interface VoiceDialogueItem {
  id: string;
  sender: 'SKI' | 'USER';
  text: string;
  timestamp: string;
}

export const SkiVoiceAgent: React.FC<SkiVoiceAgentProps> = ({
  currentPhase,
  user,
  onDictateText,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [typedInput, setTypedInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Initial welcome message based on phase
  const getPhaseContextAdvice = (phase: number, track: string): string => {
    switch (phase) {
      case 1:
        return `Welcome! I'm Ski, your career navigator. On this screen, we're setting up your background. You can choose between Systems & Coordination, Business & Operations, or Hands-On & Craft. Tell me your story or ask me which path fits best!`;
      case 2:
        return `This is our system check step. We make sure your camera and screen are ready so your evaluation is completely transparent and certified for employers.`;
      case 3:
        return `Here you will complete a practical evaluation for ${user.primarySkill}. Take your time, adjust the sliders to your preferred strategy, write your notes, and speak your verbal explanation.`;
      case 4:
        return `This is your work files hub. Connect your real project records, client proposals, or presentation decks so we can showcase your genuine accomplishments.`;
      case 5:
        return `Here is your merit-first resume! It highlights your verified skills and practical deliverables first, putting your proven capabilities front and center.`;
      case 6:
        return `Review matched opportunities across regional, national, and remote roles. Pick the ones that interest you, and we'll prepare personalized outreach pitches.`;
      case 7:
        return `This is your review and approval step. You have full control: review each pitch, approve them one by one or all together, and watch your calendar and updates sync automatically.`;
      case 8:
        return `Let's practice your interview answers! Pick a question and rehearse with me using the Situation, Task, Action, Result, and Takeaway method.`;
      case 9:
        return `Ready to offer direct client advisory or project work? Choose a project tier and generate a complete, ready-to-sign agreement with clear deliverables.`;
      default:
        return `Hello ${user.fullName.split(' ')[0]}! I'm Ski. I'm here to listen, guide your choices, and help you take the next step.`;
    }
  };

  const [dialogue, setDialogue] = useState<VoiceDialogueItem[]>([
    {
      id: 'ski-init',
      sender: 'SKI',
      text: getPhaseContextAdvice(currentPhase, user.trackName),
      timestamp: 'Just now',
    },
  ]);

  // Update dialogue when phase changes
  useEffect(() => {
    const advice = getPhaseContextAdvice(currentPhase, user.trackName);
    setDialogue((prev) => [
      ...prev,
      {
        id: `ski-${Date.now()}`,
        sender: 'SKI',
        text: advice,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  }, [currentPhase, user.trackName]);

  // Scroll to bottom of chat
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [dialogue, isOpen]);

  // Speech Synthesis Helper
  const speakText = (text: string) => {
    if (isMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    try {
      window.speechSynthesis.cancel(); // stop previous speech
      const cleanText = text.replace(/[*_#`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;

      // Select pleasant voice if available
      const voices = window.speechSynthesis.getVoices();
      const englishVoice = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha')));
      if (englishVoice) {
        utterance.voice = englishVoice;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
      setIsSpeaking(false);
    }
  };

  // Web Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
          setIsListening(true);
        };

        recognition.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setTranscript(currentTranscript);
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition error:', event.error);
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleToggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      if (transcript.trim()) {
        handleProcessUserVoice(transcript.trim());
        setTranscript('');
      }
    } else {
      setTranscript('');
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {
          console.warn('Recognition start exception, using fallback prompt:', e);
          setIsListening(true);
        }
      } else {
        // Fallback for browsers without Web Speech API
        simulateVoiceInput();
      }
    }
  };

  const simulateVoiceInput = () => {
    setIsListening(true);
    setTranscript('Listening to your voice...');
    setTimeout(() => {
      const sampleQueries = [
        'How should I explain my career gap to an employer?',
        'Can you review my strategy notes for this phase?',
        'Which career path is best for my background?',
        'How does the final approval step work?',
      ];
      const randomQuery = sampleQueries[Math.floor(Math.random() * sampleQueries.length)];
      setTranscript(randomQuery);
      setIsListening(false);
      handleProcessUserVoice(randomQuery);
      setTranscript('');
    }, 2000);
  };

  const handleProcessUserVoice = (text: string) => {
    if (!text.trim()) return;

    const userMessage: VoiceDialogueItem = {
      id: `u-${Date.now()}`,
      sender: 'USER',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setDialogue((prev) => [...prev, userMessage]);

    // Generate Ski's response in plain, supportive, corporate-friendly language
    let skiReply = '';
    const lower = text.toLowerCase();

    if (lower.includes('gap') || lower.includes('break') || lower.includes('sabbatical')) {
      skiReply = `Great question! Frame your career break positively as intentional skill-building. Highlight your verified project deliverables and certified test score—employers care about what you can execute today, not downtime in the past.`;
    } else if (lower.includes('track') || lower.includes('path') || lower.includes('which')) {
      skiReply = `Here are our 3 clear paths:\n1. Systems & Coordination: Best if you like organizing workflows, teamwork, and project delivery.\n2. Business & Operations: Best for planning, budgets, strategy, and reporting.\n3. Hands-On & Craft: Best for quality control, practical work, and craftsmanship.\nYou can switch anytime at the top of the screen!`;
    } else if (lower.includes('approval') || lower.includes('step') || lower.includes('control')) {
      skiReply = `You have complete control over every step. We prepare drafts of your pitches and applications, but nothing is ever sent until you review and click approve.`;
    } else if (lower.includes('interview') || lower.includes('practice')) {
      skiReply = `In Phase 8, we practice with the STAR-T framework: Situation, Task, Action, Result, and Takeaway. I'll listen to your answer and give you tips to make it clear and memorable.`;
    } else if (lower.includes('what should i do') || lower.includes('help') || lower.includes('explain')) {
      skiReply = getPhaseContextAdvice(currentPhase, user.trackName);
    } else {
      skiReply = `I understand. I've noted that for your profile in ${user.trackName}. You can apply this directly to your work notes, or proceed to the next step when you feel ready.`;
    }

    setTimeout(() => {
      const skiMessage: VoiceDialogueItem = {
        id: `ski-${Date.now()}`,
        sender: 'SKI',
        text: skiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setDialogue((prev) => [...prev, skiMessage]);
      speakText(skiReply);
    }, 600);
  };

  const handleSendTyped = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedInput.trim()) return;
    const msg = typedInput.trim();
    setTypedInput('');
    handleProcessUserVoice(msg);
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleQuickQuestion = (prompt: string) => {
    handleProcessUserVoice(prompt);
  };

  return (
    <>
      {/* Floating Trigger Pill */}
      {!isOpen && (
        <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2 animate-bounce-subtle">
          <button
            type="button"
            onClick={() => setIsOpen(true)}
            className="group flex items-center gap-3 bg-stone-900 hover:bg-stone-800 text-white pl-4 pr-5 py-3 rounded-full shadow-xl border border-stone-700 transition-all hover:scale-105 cursor-pointer"
            title="Talk with Ski, your interactive voice assistant"
          >
            <div className="relative w-8 h-8 rounded-full bg-emerald-500 text-stone-950 flex items-center justify-center font-bold text-xs shadow-inner">
              <Mic className="w-4 h-4 text-stone-950" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400" />
              </span>
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Talk with Ski</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                  Voice Active
                </span>
              </div>
              <p className="text-[11px] text-stone-400 leading-none mt-0.5">
                Speak your thoughts or ask for guidance
              </p>
            </div>
          </button>
        </div>
      )}

      {/* Expanded Voice Agent Drawer / Modal */}
      {isOpen && (
        <div className="fixed bottom-5 right-5 z-50 w-full max-w-md bg-stone-900 border border-stone-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-stone-100 animate-slide-up">
          {/* Header */}
          <div className="p-4 bg-stone-950/90 border-b border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="relative w-8 h-8 rounded-full bg-emerald-500 text-stone-950 flex items-center justify-center font-bold text-xs">
                <Bot className="w-4 h-4" />
                {isSpeaking && (
                  <span className="absolute -inset-1 rounded-full border border-emerald-400 animate-ping opacity-50" />
                )}
              </div>
              <div>
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>Ski — Interactive Voice Helper</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                    Live
                  </span>
                </h3>
                <p className="text-[11px] text-stone-400">
                  Phase {currentPhase}: {user.trackName}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Mute / Unmute Button */}
              <button
                type="button"
                onClick={() => {
                  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                  }
                  setIsMuted(!isMuted);
                }}
                className={`p-1.5 rounded-lg border text-xs transition-colors ${
                  isMuted
                    ? 'bg-stone-800 border-stone-700 text-stone-400 hover:text-stone-200'
                    : 'bg-emerald-950 border-emerald-800 text-emerald-400 hover:bg-emerald-900'
                }`}
                title={isMuted ? 'Unmute voice playback' : 'Mute voice playback'}
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>

              {/* Close Button */}
              <button
                type="button"
                onClick={() => {
                  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                  }
                  setIsOpen(false);
                }}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
                title="Minimize voice helper"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Spoken Waveform / Status Bar */}
          <div className="px-4 py-2 bg-stone-950/40 border-b border-stone-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  isListening
                    ? 'bg-red-500 animate-ping'
                    : isSpeaking
                    ? 'bg-emerald-400 animate-pulse'
                    : 'bg-stone-500'
                }`}
              />
              <span className="text-[11px] text-stone-300 font-medium">
                {isListening
                  ? 'Ski is listening to your voice...'
                  : isSpeaking
                  ? 'Ski is speaking...'
                  : 'Ready to listen or discuss'}
              </span>
            </div>

            {/* Quick sound wave animation when active */}
            {(isListening || isSpeaking) && (
              <div className="flex items-center gap-0.5 h-3">
                <span className="w-0.5 h-2 bg-emerald-400 rounded-full animate-pulse" />
                <span className="w-0.5 h-3 bg-emerald-400 rounded-full animate-pulse delay-75" />
                <span className="w-0.5 h-1.5 bg-emerald-400 rounded-full animate-pulse delay-150" />
                <span className="w-0.5 h-3.5 bg-emerald-400 rounded-full animate-pulse delay-100" />
                <span className="w-0.5 h-2 bg-emerald-400 rounded-full animate-pulse delay-200" />
              </div>
            )}
          </div>

          {/* Dialogue History */}
          <div className="p-4 space-y-3 max-h-72 overflow-y-auto text-xs">
            {dialogue.map((item) => {
              const isSki = item.sender === 'SKI';
              return (
                <div
                  key={item.id}
                  className={`flex gap-2.5 ${isSki ? 'items-start' : 'items-start flex-row-reverse'}`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold ${
                      isSki ? 'bg-emerald-500 text-stone-950' : 'bg-stone-700 text-stone-200'
                    }`}
                  >
                    {isSki ? 'S' : 'You'}
                  </div>

                  <div
                    className={`p-3 rounded-2xl max-w-[82%] leading-relaxed ${
                      isSki
                        ? 'bg-stone-800 text-stone-100 rounded-tl-xs border border-stone-700/80'
                        : 'bg-emerald-600 text-white rounded-tr-xs'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{item.text}</p>
                    <div className="flex items-center justify-between mt-1.5 text-[10px] text-stone-400">
                      <span>{item.timestamp}</span>
                      {isSki && (
                        <div className="flex items-center gap-1.5 ml-2">
                          <button
                            type="button"
                            onClick={() => speakText(item.text)}
                            className="hover:text-emerald-400 p-0.5"
                            title="Play audio aloud"
                          >
                            <Volume2 className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleCopyMessage(item.id, item.text)}
                            className="hover:text-emerald-400 p-0.5"
                            title="Copy text"
                          >
                            {copiedId === item.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            {transcript && (
              <div className="flex gap-2.5 items-start flex-row-reverse">
                <div className="w-6 h-6 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0 text-[10px] animate-pulse">
                  Mic
                </div>
                <div className="p-3 rounded-2xl bg-stone-800/80 border border-stone-700 text-stone-300 italic text-[11px] max-w-[82%]">
                  {transcript}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Voice Prompt Suggestions */}
          <div className="px-3 py-2 bg-stone-950/60 border-t border-stone-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[10px] text-stone-500 font-semibold uppercase tracking-wider shrink-0">
              Ask Ski:
            </span>
            {[
              'Explain this phase',
              'Which track is best?',
              'How do approvals work?',
              'Help me with my pitch',
            ].map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleQuickQuestion(prompt)}
                className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Voice Input & Text Control Bar */}
          <div className="p-3 bg-stone-950 border-t border-stone-800 flex flex-col gap-2">
            {/* Primary Voice Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleToggleListening}
                className={`flex-1 py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  isListening
                    ? 'bg-red-600 hover:bg-red-500 text-white shadow-lg animate-pulse'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-stone-950 shadow-md'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    <span>Stop & Send Voice</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>Click to Speak with Ski</span>
                  </>
                )}
              </button>

              {onDictateText && transcript && (
                <button
                  type="button"
                  onClick={() => onDictateText(transcript)}
                  className="px-3 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-emerald-400 border border-stone-700 text-xs font-semibold shrink-0"
                  title="Insert this text directly into your notes"
                >
                  Insert Notes
                </button>
              )}
            </div>

            {/* Typed fallback input */}
            <form onSubmit={handleSendTyped} className="flex items-center gap-2">
              <input
                type="text"
                value={typedInput}
                onChange={(e) => setTypedInput(e.target.value)}
                placeholder="Or type a message to Ski..."
                className="flex-1 bg-stone-900 border border-stone-700 text-xs px-3 py-2 rounded-xl text-stone-200 placeholder-stone-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                disabled={!typedInput.trim()}
                className="p-2 bg-stone-800 hover:bg-stone-700 disabled:opacity-40 text-stone-200 rounded-xl transition-colors cursor-pointer"
                title="Send message"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
