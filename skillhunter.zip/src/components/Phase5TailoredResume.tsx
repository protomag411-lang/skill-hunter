import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Award, 
  Download, 
  Copy, 
  Check, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Printer, 
  ExternalLink, 
  Code2, 
  FolderGit2, 
  Layers, 
  HeartHandshake,
  Bot
} from 'lucide-react';
import { TailoredResume, UserProfile, GradingResult, DriveDocument } from '../types';
import { generateTailoredResume } from '../services/api';

interface Phase5TailoredResumeProps {
  user: UserProfile;
  badge: GradingResult | null;
  driveDocs: DriveDocument[];
  onProceedToJobDiscovery: (resume: TailoredResume) => void;
}

export const Phase5TailoredResume: React.FC<Phase5TailoredResumeProps> = ({
  user,
  badge,
  driveDocs,
  onProceedToJobDiscovery,
}) => {
  const [resume, setResume] = useState<TailoredResume | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function loadResume() {
      setLoading(true);
      const activeBadge: GradingResult = badge || {
        overallScore: 98,
        badgeTier: 'ADVANCED',
        certificateId: 'SH-2026-V5-99A1',
        verificationHash: '0x8f3c719e21a04b56d39e',
        pillarScores: {
          technicalProficiency: 99,
          problemSolvingProcess: 98,
          verbalDefense: 97,
        },
        keyStrengths: ['Autonomous Agent Orchestration', 'Structured JSON Output Guardrails'],
        constructiveFeedback: 'Verified Senior Autonomous AI Engineering capability.',
        employerPitchSnippet: 'Candidate demonstrated top-tier execution on verified performance evaluation.',
        verifiedAt: new Date().toISOString(),
      };

      const result = await generateTailoredResume(user, activeBadge, driveDocs);
      setResume(result);
      setLoading(false);
    }
    loadResume();
  }, [user, badge, driveDocs]);

  const handleCopyText = () => {
    if (!resume) return;

    const competencies = Array.isArray(resume.verifiedCoreCompetencies)
      ? resume.verifiedCoreCompetencies
      : typeof resume.verifiedCoreCompetencies === 'string'
      ? (resume.verifiedCoreCompetencies as string).split(',').map((s) => s.trim()).filter(Boolean)
      : [];

    let text = `${resume.candidateName} — ${resume.professionalHeadline}\n`;
    text += `Contact: ${resume.contactEmail} | ${resume.contactPhone} | ${resume.location}\n`;
    text += `Skill Hunter Verified Badge: ${resume.verifiedBadge?.tier || 'ADVANCED'} (${resume.verifiedBadge?.score || 95}/100) — Cert #${resume.verifiedBadge?.certificateId || 'SH-CERT'}\n\n`;
    text += `SUMMARY:\n${resume.empowermentSummary}\n\n`;
    text += `VERIFIED COMPETENCIES:\n${competencies.join(' • ')}\n\n`;

    if (resume.meritProjects && resume.meritProjects.length > 0) {
      text += `VERIFIED MERIT PROJECTS (Zero-Pedigree Proof):\n`;
      resume.meritProjects.forEach((p) => {
        const stackStr = Array.isArray(p.techStack)
          ? p.techStack.join(', ')
          : typeof p.techStack === 'string'
          ? p.techStack
          : '';
        text += `• ${p.title} [${stackStr}]\n  ${p.summary}\n  Artifact: ${p.liveArtifactUrl}\n`;
        const outs = Array.isArray(p.outcomes) ? p.outcomes : typeof p.outcomes === 'string' ? [p.outcomes] : [];
        outs.forEach((o) => (text += `  - ${o}\n`));
      });
      text += `\n`;
    }

    if (resume.careerBreakBridge) {
      text += `CAREER SABBATICAL & UPSKILLING:\n`;
      text += `${resume.careerBreakBridge.duration}\n`;
      text += `Focus: ${resume.careerBreakBridge.learningFocus}\n`;
      const sabProjects = Array.isArray(resume.careerBreakBridge.projectsUndertaken)
        ? resume.careerBreakBridge.projectsUndertaken
        : typeof resume.careerBreakBridge.projectsUndertaken === 'string'
        ? [resume.careerBreakBridge.projectsUndertaken]
        : [];
      sabProjects.forEach((p) => (text += `  - ${p}\n`));
      text += `\n`;
    }

    text += `EXPERIENCE:\n`;
    if (Array.isArray(resume.experience)) {
      resume.experience.forEach((e) => {
        text += `${e.role} at ${e.company} (${e.period})\n`;
        const expHighs = Array.isArray(e.highlights) ? e.highlights : typeof e.highlights === 'string' ? [e.highlights] : [];
        expHighs.forEach((h) => (text += `  - ${h}\n`));
      });
    }

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading || !resume) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-12 h-12 border-3 border-emerald-500/30 border-t-emerald-600 rounded-full animate-spin mx-auto shadow-xs" />
        <h2 className="text-xl font-bold text-slate-900 font-mono">
          Synthesizing 2050 Quantum Verified Resume...
        </h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto font-mono">
          Structuring verified merit credentials, proctored evaluation metrics, and live work artifacts.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-slate-800">
      {/* 2050 Quantum Frosted Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 print:hidden">
        <div>
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-mono font-semibold mb-2 border border-emerald-500/30 shadow-xs">
            <Award className="w-3.5 h-3.5 text-emerald-600" />
            <span>Phase 5: Verified Skill-First Resume • Curated by Ski</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Verified Competency & Practical Impact Resume
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Features your verified merit credential at the top so employers immediately see authentic capability and proven business outcomes.
          </p>
        </div>

        {/* Actions Bar */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyText}
            className="px-3.5 py-2 rounded-xl border border-slate-200 hover:border-emerald-500/40 bg-white/80 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors font-mono"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl border border-slate-200 hover:border-emerald-500/40 bg-white/80 text-xs font-semibold text-slate-700 flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors font-mono"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-600" />
            <span>Print / PDF</span>
          </button>
          <button
            onClick={() => onProceedToJobDiscovery(resume)}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center gap-1.5 cursor-pointer shadow-xs transition-all font-mono"
          >
            <span>Explore Opportunities</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Resume Document Canvas (Quantum Frosted Glass) */}
      <div className="quantum-glass bg-white/90 backdrop-blur-xl rounded-2xl border border-emerald-500/30 shadow-xs p-8 sm:p-12 space-y-8 print:bg-white print:text-black print:border-none print:p-0">
        {/* Top Header */}
        <div className="border-b border-slate-200 pb-6 print:border-stone-200">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 print:text-black tracking-tight">
                  {resume.candidateName}
                </h1>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-500/30 font-semibold print:bg-stone-100 print:text-stone-800">
                  {user.archetype.replace('_', ' ')}
                </span>
              </div>
              <p className="text-sm font-semibold text-emerald-700 print:text-emerald-800 mt-1 font-mono">
                {resume.professionalHeadline}
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 print:text-stone-600 mt-2 font-mono">
                <span>{resume.location}</span>
                <span>•</span>
                <span>{resume.contactEmail}</span>
                <span>•</span>
                <span>{resume.contactPhone}</span>
              </div>
            </div>

            {/* Prominent Skill Hunter Badge Box */}
            <div className="bg-emerald-50/80 border border-emerald-500/40 rounded-xl p-4 sm:max-w-xs shadow-xs shrink-0 print:border-stone-300 print:bg-stone-50">
              <div className="flex items-center gap-2 mb-1">
                <Award className="w-5 h-5 text-emerald-600 print:text-amber-600" />
                <span className="text-[11px] font-bold text-emerald-800 print:text-amber-950 uppercase tracking-wider font-mono">
                  Skill Hunter Verified
                </span>
              </div>
              <div className="text-xs text-slate-800 print:text-stone-800">
                <span className="font-extrabold text-slate-900 print:text-black text-sm">
                  {resume.verifiedBadge.tier} Certified
                </span>{' '}
                <span className="text-emerald-700 print:text-emerald-700 font-bold font-mono">
                  ({resume.verifiedBadge.score}/100)
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-mono mt-1">
                Cert ID: {resume.verifiedBadge.certificateId}
              </p>
              <p className="text-[10px] text-slate-500 font-mono">
                Verified: {resume.verifiedBadge.issuedDate}
              </p>
            </div>
          </div>
        </div>

        {/* Executive Empowerment Summary */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 print:text-stone-900 border-b border-slate-200 pb-1 font-mono">
            Professional Summary
          </h3>
          <p className="text-xs text-slate-700 print:text-stone-700 leading-relaxed font-sans">
            {resume.empowermentSummary}
          </p>
        </div>

        {/* Verified Core Competencies */}
        <div className="space-y-2.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 print:text-stone-900 border-b border-slate-200 pb-1 flex items-center justify-between font-mono">
            <span>Verified Core Competencies</span>
            <span className="text-[10px] font-normal text-emerald-700 print:text-emerald-700 font-mono">
              ✓ Tested Under Verified Integrity Standard
            </span>
          </h3>
          <div className="flex flex-wrap gap-2">
            {(Array.isArray(resume.verifiedCoreCompetencies)
              ? resume.verifiedCoreCompetencies
              : typeof resume.verifiedCoreCompetencies === 'string'
              ? (resume.verifiedCoreCompetencies as string).split(',').map((s) => s.trim()).filter(Boolean)
              : []
            ).map((comp, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg bg-emerald-50/70 border border-emerald-500/30 text-slate-800 print:bg-stone-100 print:text-stone-800 text-xs font-medium flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>{comp}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Merit-First Projects Section */}
        {resume.meritProjects && resume.meritProjects.length > 0 && (
          <div className="space-y-3 bg-slate-50/80 p-5 rounded-xl border border-emerald-500/20 shadow-xs print:bg-stone-50 print:border-stone-200">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 print:text-stone-900 flex items-center gap-2 font-mono">
                <Code2 className="w-4 h-4 text-emerald-600" />
                <span>Verified Merit Projects & Applied Codebases</span>
              </h3>
              <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 border border-emerald-500/30 px-2 py-0.5 rounded font-semibold">
                100% Verifiable Software
              </span>
            </div>

            <div className="space-y-4 pt-1">
              {resume.meritProjects.map((proj, idx) => {
                const stackList = Array.isArray(proj.techStack)
                  ? proj.techStack
                  : typeof proj.techStack === 'string'
                  ? (proj.techStack as string).split(',').map((s) => s.trim()).filter(Boolean)
                  : [];
                const outcomeList = Array.isArray(proj.outcomes)
                  ? proj.outcomes
                  : typeof proj.outcomes === 'string'
                  ? [proj.outcomes]
                  : [];

                return (
                  <div key={idx} className="space-y-1.5 bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs print:bg-white print:border-stone-200">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-bold text-xs text-slate-900 print:text-stone-900">{proj.title}</span>
                      <a
                        href={proj.liveArtifactUrl || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-emerald-700 hover:text-emerald-600 font-mono flex items-center gap-1 font-semibold"
                      >
                        <span>View Code / Demo</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    {stackList.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {stackList.map((tech, i) => (
                          <span
                            key={i}
                            className="text-[10px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    )}

                    <p className="text-xs text-slate-600 print:text-stone-700 leading-relaxed mt-1">
                      {proj.summary}
                    </p>

                    {outcomeList.length > 0 && (
                      <ul className="space-y-1 mt-1">
                        {outcomeList.map((out, oi) => (
                          <li key={oi} className="text-xs text-slate-600 print:text-stone-600 flex items-start gap-1.5">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span>{out}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Experience Section */}
        {resume.experience && resume.experience.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 print:text-stone-900 border-b border-slate-200 pb-1 font-mono">
              Professional Work History
            </h3>
            <div className="space-y-4">
              {resume.experience.map((exp, idx) => {
                const highlights = Array.isArray(exp.highlights)
                  ? exp.highlights
                  : typeof exp.highlights === 'string'
                  ? [exp.highlights]
                  : [];

                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex flex-wrap items-center justify-between gap-1">
                      <span className="font-bold text-xs text-slate-900 print:text-stone-900">
                        {exp.role} <span className="font-normal text-slate-500 print:text-stone-600">at</span> {exp.company}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500 print:text-stone-600">
                        {exp.period}
                      </span>
                    </div>
                    {highlights.length > 0 && (
                      <ul className="space-y-1 mt-1">
                        {highlights.map((h, hi) => (
                          <li key={hi} className="text-xs text-slate-600 print:text-stone-700 flex items-start gap-1.5">
                            <span className="text-emerald-600 font-bold">•</span>
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
