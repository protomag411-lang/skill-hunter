import React, { useState } from 'react';
import { 
  Globe2, 
  CheckCircle2, 
  RefreshCw, 
  ExternalLink, 
  ShieldCheck, 
  Sliders, 
  X, 
  ArrowRight, 
  Bot, 
  Zap, 
  Clock, 
  Sparkles, 
  Layers 
} from 'lucide-react';
import { GradingResult } from '../types';

export interface JobBoardConnector {
  id: string;
  name: string;
  domain: string;
  category: string;
  status: 'CONNECTED' | 'DISCONNECTED' | 'SYNCING';
  lastSynced: string;
  syncedJobsCount: number;
  activeApplicationsCount: number;
  autoApplyBadgeEnabled: boolean;
  color: string;
  logoLetter: string;
}

const INITIAL_CONNECTORS: JobBoardConnector[] = [
  {
    id: 'linkedin',
    name: 'LinkedIn Jobs & Easy Apply',
    domain: 'linkedin.com/jobs',
    category: 'Professional Network',
    status: 'CONNECTED',
    lastSynced: '2 mins ago',
    syncedJobsCount: 14,
    activeApplicationsCount: 3,
    autoApplyBadgeEnabled: true,
    color: 'bg-emerald-600',
    logoLetter: 'in',
  },
  {
    id: 'indeed',
    name: 'Indeed Direct & Smart Apply',
    domain: 'indeed.com',
    category: 'Global Board',
    status: 'CONNECTED',
    lastSynced: '15 mins ago',
    syncedJobsCount: 19,
    activeApplicationsCount: 2,
    autoApplyBadgeEnabled: true,
    color: 'bg-emerald-700',
    logoLetter: 'in',
  },
  {
    id: 'ziprecruiter',
    name: 'ZipRecruiter 1-Click Sync',
    domain: 'ziprecruiter.com',
    category: 'Instant Matching',
    status: 'CONNECTED',
    lastSynced: '1 hour ago',
    syncedJobsCount: 8,
    activeApplicationsCount: 1,
    autoApplyBadgeEnabled: false,
    color: 'bg-emerald-500',
    logoLetter: 'ZR',
  },
  {
    id: 'glassdoor',
    name: 'Glassdoor Verified Jobs',
    domain: 'glassdoor.com',
    category: 'Salary & Reviews',
    status: 'CONNECTED',
    lastSynced: '3 hours ago',
    syncedJobsCount: 6,
    activeApplicationsCount: 0,
    autoApplyBadgeEnabled: true,
    color: 'bg-emerald-600',
    logoLetter: 'GD',
  },
  {
    id: 'wellfound',
    name: 'Wellfound (AngelList)',
    domain: 'wellfound.com',
    category: 'Startups & Tech',
    status: 'CONNECTED',
    lastSynced: 'Just now',
    syncedJobsCount: 11,
    activeApplicationsCount: 2,
    autoApplyBadgeEnabled: true,
    color: 'bg-emerald-500',
    logoLetter: 'W',
  },
  {
    id: 'remoteok',
    name: 'RemoteOK & Otta Global',
    domain: 'remoteok.com',
    category: 'Borderless Remote',
    status: 'CONNECTED',
    lastSynced: '30 mins ago',
    syncedJobsCount: 12,
    activeApplicationsCount: 1,
    autoApplyBadgeEnabled: true,
    color: 'bg-emerald-600',
    logoLetter: 'RO',
  },
];

interface UniversalJobBoardConnectorsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSyncCompleted?: (totalSynced: number) => void;
  verifiedBadge?: GradingResult | null;
}

export const UniversalJobBoardConnectorsModal: React.FC<UniversalJobBoardConnectorsModalProps> = ({
  isOpen,
  onClose,
  onSyncCompleted,
  verifiedBadge,
}) => {
  const [connectors, setConnectors] = useState<JobBoardConnector[]>(INITIAL_CONNECTORS);
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncStatusBanner, setSyncStatusBanner] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggleConnect = (id: string) => {
    setConnectors((prev) =>
      prev.map((conn) => {
        if (conn.id === id) {
          const nextStatus = conn.status === 'CONNECTED' ? 'DISCONNECTED' : 'CONNECTED';
          return {
            ...conn,
            status: nextStatus,
            lastSynced: nextStatus === 'CONNECTED' ? 'Just now' : conn.lastSynced,
          };
        }
        return conn;
      })
    );
  };

  const handleToggleAutoBadge = (id: string) => {
    setConnectors((prev) =>
      prev.map((conn) =>
        conn.id === id ? { ...conn, autoApplyBadgeEnabled: !conn.autoApplyBadgeEnabled } : conn
      )
    );
  };

  const handleSyncAll = () => {
    setIsSyncingAll(true);
    setSyncStatusBanner('Establishing quantum handshake across external endpoints...');

    setTimeout(() => {
      setConnectors((prev) =>
        prev.map((c) => ({
          ...c,
          lastSynced: 'Just now',
          syncedJobsCount: c.status === 'CONNECTED' ? c.syncedJobsCount + Math.floor(Math.random() * 3) : c.syncedJobsCount,
        }))
      );
      setIsSyncingAll(false);
      setSyncStatusBanner('Successfully synchronized 70+ matched listings and 9 active applications across 6 major platforms!');
      if (onSyncCompleted) {
        onSyncCompleted(70);
      }
    }, 1200);
  };

  const connectedCount = connectors.filter((c) => c.status === 'CONNECTED').length;
  const totalActiveApps = connectors.reduce((acc, c) => acc + (c.status === 'CONNECTED' ? c.activeApplicationsCount : 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="quantum-glass bg-white/90 backdrop-blur-xl rounded-2xl shadow-xl border border-emerald-500/30 max-w-2xl w-full overflow-hidden text-slate-800 relative max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="p-6 relative border-b border-slate-200 bg-white/90">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-1.5 rounded-lg bg-slate-100 border border-slate-200 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2 font-mono">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <Globe2 className="w-4 h-4" />
            </div>
            <span className="text-xs font-semibold text-emerald-700 tracking-wide uppercase">
              2050 Universal Multi-Platform Hub
            </span>
          </div>

          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            Universal Job Board Connectors
          </h2>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">
            Link and synchronize your verified applications, job matches, and interview invites across all major external job boards into your single dashboard.
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-3 text-xs font-mono">
            <div className="px-3 py-1.5 rounded-lg bg-slate-100/80 border border-slate-200 text-slate-700 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-xs" />
              <span><strong className="text-slate-900">{connectedCount} of {connectors.length}</strong> Boards Connected</span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-100/80 border border-slate-200 text-slate-700 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-600" />
              <span><strong className="text-slate-900">{totalActiveApps}</strong> External Applications Active</span>
            </div>
          </div>
        </div>

        {/* Action & Sync Status Bar */}
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-slate-600 font-sans">
            Ski automatically refreshes listings and syncs your verified badges with connected accounts.
          </div>
          <button
            type="button"
            onClick={handleSyncAll}
            disabled={isSyncingAll}
            className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono flex items-center gap-2 transition-all cursor-pointer shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAll ? 'animate-spin' : ''}`} />
            <span>{isSyncingAll ? 'Synchronizing Platforms...' : 'Sync All Job Boards'}</span>
          </button>
        </div>

        {/* Banner feedback */}
        {syncStatusBanner && (
          <div className="px-5 py-2.5 bg-emerald-50 border-b border-emerald-500/30 text-emerald-800 text-xs font-mono font-medium flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncStatusBanner}</span>
          </div>
        )}

        {/* Connectors List */}
        <div className="p-6 overflow-y-auto space-y-3 flex-1">
          {connectors.map((connector) => {
            const isConnected = connector.status === 'CONNECTED';

            return (
              <div
                key={connector.id}
                className={`p-4 rounded-xl border transition-all ${
                  isConnected
                    ? 'border-emerald-500/30 bg-white/90 shadow-xs hover:border-emerald-500/50'
                    : 'border-slate-200 bg-slate-50/50 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-bold font-mono text-sm flex items-center justify-center shrink-0 shadow-xs">
                      {connector.logoLetter}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">
                          {connector.name}
                        </h4>
                        <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono">
                          {connector.category}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5 font-mono">
                        <span>{connector.domain}</span>
                        <span>•</span>
                        <span>Last Synced: {connector.lastSynced}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 font-mono">
                    <button
                      type="button"
                      onClick={() => handleToggleConnect(connector.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        isConnected
                          ? 'bg-emerald-50 border border-emerald-500/30 text-emerald-700 hover:bg-emerald-100'
                          : 'bg-emerald-600 text-white hover:bg-emerald-500'
                      }`}
                    >
                      {isConnected ? 'Linked' : 'Connect'}
                    </button>
                  </div>
                </div>

                {isConnected && (
                  <div className="mt-3 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                    <div className="flex items-center gap-4 text-slate-600">
                      <span><strong className="text-slate-900">{connector.syncedJobsCount}</strong> jobs tracked</span>
                      <span><strong className="text-slate-900">{connector.activeApplicationsCount}</strong> apps sent</span>
                    </div>

                    <label className="flex items-center gap-1.5 cursor-pointer text-slate-500 select-none">
                      <input
                        type="checkbox"
                        checked={connector.autoApplyBadgeEnabled}
                        onChange={() => handleToggleAutoBadge(connector.id)}
                        className="rounded accent-emerald-600 cursor-pointer"
                      />
                      <span>Auto-inject Ski Verified Badge</span>
                    </label>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50/90 border-t border-slate-200 flex items-center justify-between font-mono">
          <span className="text-xs text-slate-500">
            End-to-end encrypted career protocol
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200 cursor-pointer shadow-xs"
          >
            Close & Continue
          </button>
        </div>
      </div>
    </div>
  );
};
