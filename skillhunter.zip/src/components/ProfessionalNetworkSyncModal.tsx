import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  CheckCircle2, 
  RefreshCw, 
  Linkedin, 
  Github, 
  Globe, 
  ShieldCheck, 
  Award, 
  Sparkles,
  ExternalLink,
  Zap,
  ArrowRight
} from 'lucide-react';
import { UserProfile, GradingResult } from '../types';

interface ProfessionalNetworkSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  badge: GradingResult | null;
}

interface NetworkPlatform {
  id: string;
  name: string;
  category: string;
  icon: string;
  connected: boolean;
  lastSynced: string;
  syncedBadge: boolean;
  syncedBio: boolean;
  externalUrl: string;
}

export const ProfessionalNetworkSyncModal: React.FC<ProfessionalNetworkSyncModalProps> = ({
  isOpen,
  onClose,
  user,
  badge,
}) => {
  const [platforms, setPlatforms] = useState<NetworkPlatform[]>([
    {
      id: 'linkedin',
      name: 'LinkedIn Professional',
      category: 'Corporate & Executive Network',
      icon: '💼',
      connected: true,
      lastSynced: '2 mins ago',
      syncedBadge: true,
      syncedBio: true,
      externalUrl: 'https://linkedin.com',
    },
    {
      id: 'github',
      name: 'GitHub Developer Profile',
      category: 'Technical Portfolio & Artifacts',
      icon: '🐙',
      connected: true,
      lastSynced: '14 mins ago',
      syncedBadge: true,
      syncedBio: false,
      externalUrl: 'https://github.com',
    },
    {
      id: 'upwork',
      name: 'Upwork Enterprise',
      category: 'High-Ticket Contract Escrow',
      icon: '⚡',
      connected: true,
      lastSynced: '1 hour ago',
      syncedBadge: true,
      syncedBio: true,
      externalUrl: 'https://upwork.com',
    },
    {
      id: 'indeed',
      name: 'Indeed Global Radar',
      category: 'Automated Job Match Relay',
      icon: '🌐',
      connected: false,
      lastSynced: 'Not connected',
      syncedBadge: false,
      syncedBio: false,
      externalUrl: 'https://indeed.com',
    },
  ]);

  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncStatusMessage, setSyncStatusMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggleConnect = (id: string) => {
    setPlatforms((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const next = !p.connected;
          return {
            ...p,
            connected: next,
            lastSynced: next ? 'Just now' : 'Disconnected',
            syncedBadge: next,
            syncedBio: next,
          };
        }
        return p;
      })
    );
  };

  const handleSyncAll = () => {
    setIsSyncingAll(true);
    setSyncStatusMessage('Broadcasting 2050 Quantum Verified Credentials across all connected profiles...');
    setTimeout(() => {
      setPlatforms((prev) =>
        prev.map((p) => ({
          ...p,
          connected: true,
          lastSynced: 'Just now (Quantum Synced)',
          syncedBadge: true,
          syncedBio: true,
        }))
      );
      setIsSyncingAll(false);
      setSyncStatusMessage('Success: All 4 external profiles are harmonized with your proctored badge and verified bio!');
      setTimeout(() => setSyncStatusMessage(null), 4000);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="quantum-glass border border-emerald-500/40 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative text-stone-200">
        <div className="h-1 w-full bg-gradient-to-r from-transparent via-emerald-400 to-transparent" />

        {/* Modal Header */}
        <div className="p-6 border-b border-emerald-500/20 flex items-center justify-between bg-stone-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Professional Network Sync
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 uppercase font-semibold">
                  2050 Quantum Mesh
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Keep your external platforms aligned with verified achievements automatically
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-2 rounded-lg hover:bg-stone-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Active Verified Proof Banner */}
          <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/30">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <span>Pushing Proof: {user.primarySkill}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/30 text-emerald-300">
                    {badge ? badge.badgeTier : 'CERTIFIED'}
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Cryptographic verification hash: <span className="font-mono text-emerald-400">0x8F92...E41</span>
                </p>
              </div>
            </div>

            <button
              onClick={handleSyncAll}
              disabled={isSyncingAll}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 text-xs font-bold transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center gap-1.5 shrink-0 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAll ? 'animate-spin' : ''}`} />
              <span>{isSyncingAll ? 'Quantum Syncing...' : 'Sync All Networks'}</span>
            </button>
          </div>

          {syncStatusMessage && (
            <div className="p-3 rounded-xl bg-emerald-900/40 border border-emerald-500/50 text-xs text-emerald-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{syncStatusMessage}</span>
            </div>
          )}

          {/* Platform List */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider">
              Connected External Profiles
            </div>

            {platforms.map((platform) => (
              <div
                key={platform.id}
                className={`p-4 rounded-xl border transition-all flex items-center justify-between gap-4 ${
                  platform.connected
                    ? 'bg-stone-900/70 border-emerald-500/30'
                    : 'bg-stone-900/30 border-stone-800 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div className="text-2xl">{platform.icon}</div>
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{platform.name}</span>
                      {platform.connected && (
                        <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          Live Sync
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-stone-400">
                      {platform.category} • <span className="text-stone-300 font-mono text-[11px]">Last sync: {platform.lastSynced}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleToggleConnect(platform.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      platform.connected
                        ? 'bg-stone-800 hover:bg-stone-700 text-stone-300'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {platform.connected ? 'Disconnect' : 'Connect'}
                  </button>
                  <a
                    href={platform.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800/60 transition-colors"
                    title={`Open ${platform.name}`}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>

          {/* Feature Highlights */}
          <div className="p-3.5 rounded-xl bg-stone-950/60 border border-stone-800 text-xs text-stone-400 space-y-1.5">
            <div className="font-semibold text-stone-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
              Automated 2050 Synchronization Rules:
            </div>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-stone-400">
              <li>When you achieve a higher verified score in Phase 3, your LinkedIn credential badge updates within 30 seconds.</li>
              <li>Your ATS-optimized markdown and PDF resume is automatically mirrored to your GitHub profile repository.</li>
              <li>Upwork contract proposals automatically include your verified verification link and proctored screen proof.</li>
            </ul>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-emerald-500/20 bg-stone-950/80 flex items-center justify-between">
          <div className="text-xs text-stone-400">
            Zero credentials stored • Authorized via OAuth 2.0 PKCE tokens
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
