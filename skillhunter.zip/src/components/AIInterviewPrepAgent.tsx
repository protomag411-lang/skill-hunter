import React, { useState } from 'react';
import { 
  Video, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  HelpCircle, 
  Shirt, 
  Eye, 
  Mic, 
  Compass, 
  Award, 
  Send, 
  RefreshCw, 
  Copy, 
  Check, 
  ArrowRight,
  ShieldCheck,
  Zap,
  BookOpen
} from 'lucide-react';
import { UserProfile, GradingResult } from '../types';
import { fetchInterviewPrep } from '../services/api';

interface AIInterviewPrepAgentProps {
  user: UserProfile;
  badge: GradingResult | null;
  onClose?: () => void;
  onProceedToMonetization?: () => void;
}

const SAMPLE_QUESTIONS = [
  "How do you address the employment gap on your resume, and why are you ready to excel now?",
  "Walk me through a difficult technical or business challenge you solved hands-on.",
  "Why should we hire a non-traditional or self-taught candidate over someone with a corporate degree?",
  "How do you ensure your skills and tools stay up to date in the fast-moving AI era?",
];

export const AIInterviewPrepAgent: React.FC<AIInterviewPrepAgentProps> = ({
  user,
  badge,
  onClose,
  onProceedToMonetization,
}) => {
  const [format, setFormat] = useState<'VIDEO' | 'IN_PERSON'>('VIDEO');
  const [selectedQuestion, setSelectedQuestion] = useState<string>(SAMPLE_QUESTIONS[0]);
  const [customQuestion, setCustomQuestion] = useState<string>('');
  const [candidateAnswer, setCandidateAnswer] = useState<string>(
    `I spent my career sabbatical intentionally mastering ${user.primarySkill}. Under Skill Hunter's certified verification standards, my practical capability was certified in the ${badge?.badgeTier || 'ADVANCED'} tier (Score: ${badge?.overallScore || 96}/100). In today's market, proven hands-on execution is the strongest predictor of day-one impact.`
  );
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedAnswer, setCopiedAnswer] = useState<boolean>(false);
  const [prepResult, setPrepResult] = useState<any>(null);

  const activeQuestion = customQuestion.trim() || selectedQuestion;

  const handleAnalyzeAnswer = async () => {
    setIsLoading(true);
    try {
      const result = await fetchInterviewPrep({
        skillDomain: user.primarySkill,
        badgeTier: badge?.badgeTier || 'ADVANCED',
        format,
        question: activeQuestion,
        candidateAnswer,
        roleTitle: `Senior ${user.primarySkill} Specialist`,
        companyName: 'Top Partner Organization',
      });
      setPrepResult(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedAnswer(true);
    setTimeout(() => setCopiedAnswer(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 text-slate-800">
      {/* 2050 Quantum Frosted Header */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 shadow-xs border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-500/30 text-xs font-mono font-semibold uppercase tracking-wider shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Phase 8 of 9: 2050 Real-Time Interview Coach • Coach Ski
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Master Your Interviews with Ski's Real-Time Coaching
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              When an interview is scheduled, speak with total confidence. Ski coaches you on professional presence, strategic phrasing, format-specific tactics, and the proven <strong className="text-emerald-700">STAR-T Framework</strong> to showcase your verified execution.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 font-mono">
            {onProceedToMonetization && (
              <button
                onClick={onProceedToMonetization}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Zap className="w-4 h-4" />
                <span>Next: Skill Selling Engine (Phase 9)</span>
              </button>
            )}
            {onClose && (
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-medium text-xs transition-all cursor-pointer shadow-xs"
              >
                Return to Applications
              </button>
            )}
          </div>
        </div>

        {/* Format Selector Toggle */}
        <div className="mt-6 pt-6 border-t border-emerald-500/20 flex flex-wrap items-center justify-between gap-4 font-mono">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>Choose Interview Modality:</span>
          </div>
          <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200">
            <button
              onClick={() => setFormat('VIDEO')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                format === 'VIDEO'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Remote Video Call (Meet/Zoom)</span>
            </button>
            <button
              onClick={() => setFormat('IN_PERSON')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                format === 'IN_PERSON'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>On-Site / Face-to-Face Meeting</span>
            </button>
          </div>
        </div>
      </div>

      {/* Pillar 1 & 2: Posture, Clothing & Format Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Presentation & Posture */}
        <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-mono">Posture & Eye Contact</h3>
              <p className="text-xs text-slate-500">Physical presence & body language</p>
            </div>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-600">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">Eye-Level Gaze:</strong> Look directly into the camera lens (or friendly direct eye contact in person) when speaking.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">Open Hand Gestures:</strong> Keep your hands visible in the lower frame to project honesty and calm confidence.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">10-Degree Engagement Lean:</strong> Lean slightly forward when addressing practical problem solving.</span>
            </li>
          </ul>
        </div>

        {/* Clothing & Attire */}
        <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <Shirt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-mono">Clothing & Grooming</h3>
              <p className="text-xs text-slate-500">Visual professionalism & palette</p>
            </div>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-600">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">Solid Tones:</strong> Wear solid colors (Deep Navy, Charcoal, Forest Green, Slate). Avoid busy plaids.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">No Strobe Artifacts:</strong> Avoid tight micro-stripes that create moiré patterns on high-definition webcams.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong className="text-slate-900">Clean Minimalist Jewelry:</strong> Keep accessories simple to keep the panel's focus squarely on your technical words.</span>
            </li>
          </ul>
        </div>

        {/* Format Specific Logistics */}
        <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              {format === 'VIDEO' ? <Video className="w-5 h-5" /> : <Compass className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 font-mono">
                {format === 'VIDEO' ? 'Video Setup Strategy' : 'In-Person Protocol'}
              </h3>
              <p className="text-xs text-slate-500">Technical check & environment</p>
            </div>
          </div>
          <ul className="space-y-2.5 text-xs text-slate-600">
            {format === 'VIDEO' ? (
              <>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">Lighting:</strong> Key light placed in front of you at 45°. Never sit with a bright window behind you.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">Clean Audio:</strong> Use a dedicated headset or lapel mic with background noise suppression tested.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">Tab Preparedness:</strong> Have your Skill Hunter verified badge and GitHub repo open in adjacent tabs.</span>
                </li>
              </>
            ) : (
              <>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">12-Minute Arrival Window:</strong> Arrive at the building lobby exactly 12 minutes before schedule.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">Physical Portfolio Binder:</strong> Bring 3 printed color copies of your Skill Hunter Badge certificate.</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span><strong className="text-slate-900">Firm Neutral Greeting:</strong> Confident handshake or warm verbal greeting with upright posture.</span>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>

      {/* Pillar 3: Interactive STAR-T Framework Practice Chamber */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 border border-emerald-500/30 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-emerald-500/20">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-500/30 font-mono">
                Pillar 3: Skill-First Storytelling
              </span>
              <span className="text-xs font-semibold text-slate-500 font-mono">
                STAR-T Framework
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Practice Answering with Absolute Technical Authority
            </h2>
            <p className="text-xs text-slate-600">
              The STAR-T framework turns traditional employment gaps into high-value proof: <strong>S</strong>ituation, <strong>T</strong>ask, <strong>A</strong>ction, <strong>R</strong>esult, and <strong>T</strong>ech stack.
            </p>
          </div>

          {badge && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-500/30 text-xs font-mono text-emerald-700 shadow-xs">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>Verified Score: {badge.overallScore}/100</span>
            </div>
          )}
        </div>

        {/* Question Selector */}
        <div className="space-y-3">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 font-mono">
            Select an Interview Question to Practice:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {SAMPLE_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSelectedQuestion(q);
                  setCustomQuestion('');
                }}
                className={`text-left p-3 rounded-xl text-xs transition-all cursor-pointer border font-mono ${
                  selectedQuestion === q && !customQuestion
                    ? 'bg-emerald-50/90 border-emerald-500 text-slate-900 font-semibold shadow-xs'
                    : 'bg-white/80 border-slate-200 text-slate-700 hover:border-emerald-500/40 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5 border border-emerald-500/30">
                    {idx + 1}
                  </span>
                  <span>{q}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Custom Question Input */}
          <div className="pt-2">
            <input
              type="text"
              placeholder="Or type any specific interview question you want to rehearse..."
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:border-emerald-500 focus:outline-none transition-all font-mono shadow-xs"
            />
          </div>
        </div>

        {/* Candidate Answer Workspace */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 font-mono">
              <span>Your Draft Answer / Rehearsal Notes:</span>
              <span className="text-slate-400 font-normal">({candidateAnswer.length} characters)</span>
            </label>
            <button
              onClick={() =>
                setCandidateAnswer(
                  `During my career break, I focused completely on verified practical mastery in ${user.primarySkill}. Under Skill Hunter's proctored evaluation, my practical execution was verified in the top ${badge?.badgeTier || 'ADVANCED'} tier. In today's AI era, hands-on ability is what shields projects from downtime, and my verified badge guarantees immediate productivity.`
                )
              }
              className="text-[11px] text-emerald-700 hover:text-emerald-800 font-mono underline cursor-pointer"
            >
              Reset to Recommended Foundation
            </button>
          </div>
          <textarea
            rows={4}
            value={candidateAnswer}
            onChange={(e) => setCandidateAnswer(e.target.value)}
            className="w-full p-3.5 text-xs font-mono rounded-xl border border-slate-200 bg-white text-slate-900 focus:border-emerald-500 focus:outline-none leading-relaxed shadow-xs"
            placeholder="Type your spoken answer or talking points here..."
          />
        </div>

        {/* Action Button */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>AI evaluates your delivery, STAR-T alignment, and resume gap defense.</span>
          </div>

          <button
            onClick={handleAnalyzeAnswer}
            disabled={isLoading || !candidateAnswer.trim()}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 cursor-pointer transition-all shadow-xs font-mono"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Evaluating via STAR-T Matrix...</span>
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>Coach Me on This Answer</span>
              </>
            )}
          </button>
        </div>

        {/* Feedback Display Container */}
        {prepResult && (
          <div className="mt-6 pt-6 border-t border-emerald-500/20 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-emerald-50/90 border border-emerald-500/30 rounded-xl p-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                  {prepResult.confidenceScore || 95}%
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 font-mono">
                    STAR-T Delivery & Authority Score
                  </h4>
                  <p className="text-[11px] text-emerald-700">
                    High clarity, strong gap deflection, and crisp technical emphasis.
                  </p>
                </div>
              </div>

              <button
                onClick={() => handleCopy(prepResult.modelAnswer)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-emerald-500/30 text-emerald-700 text-xs font-mono font-medium hover:bg-emerald-50 transition-colors cursor-pointer shadow-xs"
              >
                {copiedAnswer ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedAnswer ? 'Copied Model Answer!' : 'Copy Model Answer'}</span>
              </button>
            </div>

            {/* STAR-T Breakdown Cards */}
            {prepResult.startBreakdown && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div className="p-3.5 rounded-xl bg-white/90 border border-slate-200 space-y-1 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">
                    [S] Situation
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prepResult.startBreakdown.situation}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/90 border border-slate-200 space-y-1 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">
                    [T] Task
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prepResult.startBreakdown.task}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/90 border border-slate-200 space-y-1 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">
                    [A] Action
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prepResult.startBreakdown.action}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/90 border border-slate-200 space-y-1 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">
                    [R] Result
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prepResult.startBreakdown.result}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/90 border border-slate-200 space-y-1 shadow-xs">
                  <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block font-mono">
                    [T] Tech Stack
                  </span>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {prepResult.startBreakdown.tech}
                  </p>
                </div>
              </div>
            )}

            {/* Gap Defense Strategic Reframe */}
            {prepResult.startBreakdown?.gapDefense && (
              <div className="p-4 rounded-xl bg-emerald-50/80 border border-emerald-500/30 flex items-start gap-3 shadow-xs">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h5 className="text-xs font-bold text-slate-900 font-mono">
                    Strategic Career Gap Reframe (Defense Shield):
                  </h5>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {prepResult.startBreakdown.gapDefense}
                  </p>
                </div>
              </div>
            )}

            {/* Executive Model Answer */}
            {prepResult.modelAnswer && (
              <div className="p-5 rounded-xl bg-slate-50 border border-emerald-500/30 space-y-2 shadow-xs">
                <div className="flex items-center justify-between font-mono">
                  <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-700">
                    Recommended Model Spoken Answer:
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Timed for ~45 seconds speaking pace
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-800 leading-relaxed italic font-sans">
                  &ldquo;{prepResult.modelAnswer}&rdquo;
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
