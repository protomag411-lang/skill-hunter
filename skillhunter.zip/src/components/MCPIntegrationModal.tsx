import React, { useState } from 'react';
import { 
  X, 
  Cpu, 
  HardDrive, 
  Database, 
  FolderGit2, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ShieldCheck, 
  Zap, 
  Sparkles, 
  Plus, 
  Server,
  Activity,
  Check,
  ExternalLink
} from 'lucide-react';
import { MCPServerConfig, AIProviderConfig } from '../types';
import { DEFAULT_MCP_SERVERS, DEFAULT_AI_PROVIDERS } from '../data/mockData';

interface MCPIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MCPIntegrationModal: React.FC<MCPIntegrationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'SERVERS' | 'MODELS'>('SERVERS');
  const [servers, setServers] = useState<MCPServerConfig[]>(DEFAULT_MCP_SERVERS);
  const [aiProviders, setAiProviders] = useState<AIProviderConfig[]>(DEFAULT_AI_PROVIDERS);
  const [selectedProviderId, setSelectedProviderId] = useState<string>('ai-prov-gemini');
  const [customEndpoint, setCustomEndpoint] = useState<string>('http://localhost:8080/sse');
  const [testingId, setTestingId] = useState<string | null>(null);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggleServer = (id: string) => {
    setServers((prev) =>
      prev.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
    );
  };

  const handleTestConnection = (id: string) => {
    setTestingId(id);
    setTimeout(() => {
      setTestingId(null);
      setServers((prev) =>
        prev.map((s) =>
          s.id === id
            ? {
                ...s,
                status: 'CONNECTED',
                latencyMs: Math.floor(Math.random() * 25) + 10,
              }
            : s
        )
      );
      setSuccessBanner(`MCP connection verified: Protocol active with secure local parameters.`);
      setTimeout(() => setSuccessBanner(null), 3500);
    }, 800);
  };

  const handleAddCustomEndpoint = () => {
    if (!customEndpoint.trim()) return;
    const newServer: MCPServerConfig = {
      id: `mcp-cust-${Date.now()}`,
      name: 'Custom Local MCP Server',
      type: 'CUSTOM',
      protocolUri: customEndpoint.trim(),
      status: 'CONNECTED',
      description: 'Private enterprise or local tool protocol connected via SSE/stdio transport.',
      enabled: true,
      capabilities: ['Local Tool Execution', 'Document Retrieval'],
      latencyMs: 15,
    };
    setServers((prev) => [...prev, newServer]);
    setSuccessBanner('Custom MCP server successfully registered and connected.');
    setTimeout(() => setSuccessBanner(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/35 backdrop-blur-md animate-fadeIn">
      <div className="quantum-glass bg-white/95 backdrop-blur-2xl border border-emerald-500/30 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden text-slate-800">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 flex items-center justify-between bg-white/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-500/30 flex items-center justify-center shadow-xs">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  Connected Workspace Tools & AI Models
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-500/30">
                  Private & Secure
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Connect your workspace files, cloud storage, and productivity tools alongside fast, high-performance AI models.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 px-6 pt-3 gap-3">
          <button
            onClick={() => setActiveTab('SERVERS')}
            className={`pb-3 px-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'SERVERS'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Model Context Protocol (MCP) Servers ({servers.filter((s) => s.enabled).length} Active)</span>
          </button>
          <button
            onClick={() => setActiveTab('MODELS')}
            className={`pb-3 px-3 text-xs font-semibold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'MODELS'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>Free & Top-Tier AI Models</span>
          </button>
        </div>

        {/* Notification Banner */}
        {successBanner && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-2.5 flex items-center gap-2 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successBanner}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {activeTab === 'SERVERS' ? (
            <div className="space-y-4">
              <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-500/25 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-700 leading-relaxed">
                  <strong className="text-slate-900 font-semibold">Standard Model Context Protocol Architecture:</strong> MCP establishes secure, local communication channels between your environment and verified external data sources. Sensitive files and customer databases never leave your control or pass through unverified third-party intermediaries.
                </div>
              </div>

              {/* Server List */}
              <div className="space-y-3">
                {servers.map((srv) => (
                  <div
                    key={srv.id}
                    className={`p-4 rounded-xl border transition-all ${
                      srv.enabled
                        ? 'bg-white border-emerald-500/30 shadow-xs hover:border-emerald-500/60'
                        : 'bg-slate-50 border-slate-200 opacity-60'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200 shrink-0 mt-0.5">
                          {srv.type === 'FILESYSTEM' && <HardDrive className="w-4 h-4" />}
                          {srv.type === 'DATABASE' && <Database className="w-4 h-4" />}
                          {srv.type === 'WORKSPACE' && <FolderGit2 className="w-4 h-4" />}
                          {srv.type === 'CUSTOM' && <Server className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold text-slate-900">{srv.name}</h3>
                            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                              {srv.protocolUri}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">{srv.description}</p>
                          <div className="flex flex-wrap items-center gap-1.5 mt-2">
                            {srv.capabilities.map((cap, i) => (
                              <span
                                key={i}
                                className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200"
                              >
                                {cap}
                              </span>
                            ))}
                            {srv.latencyMs !== undefined && srv.status === 'CONNECTED' && (
                              <span className="text-[10px] font-mono text-emerald-700 flex items-center gap-1 ml-1 font-semibold">
                                <Activity className="w-3 h-3" />
                                {srv.latencyMs}ms latency
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        <button
                          type="button"
                          onClick={() => handleTestConnection(srv.id)}
                          disabled={testingId === srv.id}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs text-slate-700 border border-slate-300 flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
                        >
                          {testingId === srv.id ? (
                            <>
                              <RefreshCw className="w-3 h-3 animate-spin text-emerald-600" />
                              <span>Pinging...</span>
                            </>
                          ) : (
                            <>
                              <Activity className="w-3 h-3 text-emerald-600" />
                              <span>Test Protocol</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleToggleServer(srv.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                            srv.enabled
                              ? 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-xs'
                              : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          }`}
                        >
                          {srv.enabled ? 'Enabled' : 'Disabled'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Custom MCP Server */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Plus className="w-3.5 h-3.5 text-emerald-600" />
                  Connect Custom MCP Server Endpoint
                </h4>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={customEndpoint}
                    onChange={(e) => setCustomEndpoint(e.target.value)}
                    placeholder="e.g. http://localhost:8080/sse or mcp://custom-tools"
                    className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomEndpoint}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-all shrink-0 cursor-pointer shadow-xs"
                  >
                    Register Endpoint
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-500/25 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-700 leading-relaxed">
                  <strong className="text-slate-900 font-semibold">Free & Cost-Effective Model Orchestration:</strong> Skill Hunter utilizes Google AI Studio's high-performance Gemini models as the default free-tier reasoning engine, with seamless fallback to local open-weights engines (e.g., Llama 3 via Ollama) for complete offline data autonomy.
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {aiProviders.map((prov) => {
                  const isSelected = selectedProviderId === prov.id;
                  return (
                    <div
                      key={prov.id}
                      onClick={() => setSelectedProviderId(prov.id)}
                      className={`p-5 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-white border-emerald-500 ring-2 ring-emerald-500/30 shadow-md'
                          : 'bg-white/80 border-slate-200 hover:border-emerald-500/30 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-sm font-bold text-slate-900">{prov.name}</h3>
                          </div>
                          <span className="inline-block mt-1 text-[11px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                            Model ID: {prov.modelId}
                          </span>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                            isSelected
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                        {prov.description}
                      </p>

                      <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100">
                        <span className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {prov.isFreeTier ? '100% Free Tier Included' : 'Custom Config'}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {prov.endpointUrl || 'Default Cloud Gateway'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-white/90 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Active Engine: <strong className="text-slate-800">Google AI Studio (Gemini 3.6 Flash)</strong> • Safe Sandbox
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-all shadow-xs cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
