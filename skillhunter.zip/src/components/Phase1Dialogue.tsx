import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Send, 
  ArrowRight, 
  CheckCircle2, 
  Clock, 
  Briefcase,
  Layers,
  Zap,
  ShieldCheck, 
  UserCheck,
  Bot,
  TrendingUp,
  Award,
  Cpu,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Radio,
  FileCode,
  Globe
} from 'lucide-react';
import { UserProfile, ProfileTrack } from '../types';
import { SKILL_DOMAINS, PROFILE_TRACK_PRESETS } from '../data/mockData';
import { sendChatMessage } from '../services/api';

interface Phase1DialogueProps {
  user: UserProfile;
  onUpdateUser: (updated: Partial<UserProfile>) => void;
  onProceedToProctoring: (selectedSkill: string) => void;
  onOpenMCPModal?: () => void;
  onOpenForecastModal?: () => void;
}

interface Message {
  id: string;
  sender: 'AI' | 'USER';
  text: string;
  timestamp: string;
  structuredHypotheses?: string[];
  showNextCta?: boolean;
}

export const Phase1Dialogue: React.FC<Phase1DialogueProps> = ({
  user,
  onUpdateUser,
  onProceedToProctoring,
  onOpenMCPModal,
  onOpenForecastModal,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-1',
      sender: 'AI',
      text: `Greetings ${user.fullName.split(' ')[0]}. I am Ski, your 2050 Autonomous Career Orchestrator.\n\nIn the AI Era, your verified capability is your unshakeable shield. Regardless of career breaks or non-traditional backgrounds, employers prioritize verified merit over resumes.\n\nSelect your profile track on the left, speak into the neural interface, or type your core expertise below to begin.`,
      timestamp: 'Just now',
    },
  ]);

  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [isDictating, setIsDictating] = useState(false);
  const [isAudioSpeaking, setIsAudioSpeaking] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState(user.primarySkill || 'Systems & Coordination');
  const [customGapYears, setCustomGapYears] = useState(user.careerGapYears);
  const [gapReason, setGapReason] = useState(user.gapReason);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Voice speech synthesis
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const clean = text.replace(/[*#_`]/g, '');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsAudioSpeaking(true);
      utterance.onend = () => setIsAudioSpeaking(false);
      utterance.onerror = () => setIsAudioSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleSelectTrack = (trackKey: ProfileTrack) => {
    const preset = PROFILE_TRACK_PRESETS[trackKey];
    if (!preset) return;

    onUpdateUser({
      ...preset,
      track: trackKey,
    });
    setSelectedSkill(preset.primarySkill);
    setCustomGapYears(preset.careerGapYears);
    setGapReason(preset.gapReason);

    let introText = '';
    if (trackKey === 'TECHNICAL') {
      introText = `Track morphed to Systems & Coordination: ${preset.fullName}. Specialized in organizing workflows, distributed teamwork, and complex project delivery.`;
    } else if (trackKey === 'NON_TECHNICAL') {
      introText = `Track morphed to Business & Operations: ${preset.fullName}. Specialized in strategic planning, budgeting, client communication, and performance governance.`;
    } else {
      introText = `Track morphed to Hands-On & Craft: ${preset.fullName}. Specialized in precision execution, technical craftsmanship, and quality validation.`;
    }

    const switchMsg: Message = {
      id: `track-${Date.now()}`,
      sender: 'AI',
      text: `${introText}\n\nI have loaded your baseline benchmarks for ${preset.primarySkill}. Would you like to calibrate further or proceed directly to our proctored system check?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, switchMsg]);
    speakText(switchMsg.text);
  };

  const handleSelectPredefinedSkill = async (skillName: string) => {
    setSelectedSkill(skillName);
    onUpdateUser({ primarySkill: skillName });

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'USER',
      text: `I specialize in ${skillName}.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const chatHistory = messages.map((m) => ({
        role: m.sender === 'AI' ? 'model' : 'user',
        content: m.text,
      }));
      const res = await sendChatMessage(
        chatHistory,
        `I specialize in ${skillName}. My current career gap is ${customGapYears} years (${gapReason}).`,
        customGapYears,
        skillName
      );

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'AI',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        structuredHypotheses: res.structuredHypotheses,
        showNextCta: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
      speakText(res.reply);
    } catch {
      const fallbackMsg: Message = {
        id: `ai-err-${Date.now()}`,
        sender: 'AI',
        text: `Understood! In the 2050 ecosystem, your mastery in ${skillName} speaks for itself. Let's proceed to the proctored system check to earn your verified badge.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        showNextCta: true,
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      speakText(fallbackMsg.text);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputVal.trim() || loading) return;

    const userText = inputVal;
    setInputVal('');
    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'USER',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const chatHistory = messages.map((m) => ({
        role: m.sender === 'AI' ? 'model' : 'user',
        content: m.text,
      }));
      const res = await sendChatMessage(chatHistory, userText, customGapYears, selectedSkill);
      if (res.detectedSkill) {
        setSelectedSkill(res.detectedSkill);
        onUpdateUser({ primarySkill: res.detectedSkill });
      }

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'AI',
        text: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        structuredHypotheses: res.structuredHypotheses,
        showNextCta: true,
      };
      setMessages((prev) => [...prev, aiMsg]);
      speakText(res.reply);
    } catch {
      const fallbackMsg: Message = {
        id: `ai-fallback-${Date.now()}`,
        sender: 'AI',
        text: `Excellent. In the 2050 talent ecosystem, real verified execution renders resume gaps obsolete. Let's establish your camera and screen proctoring shield to secure your verified credentials.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        showNextCta: true,
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      speakText(fallbackMsg.text);
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceToggle = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser environment. You can type your response below.');
      return;
    }

    if (isDictating) {
      setIsDictating(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsDictating(true);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputVal(transcript);
      setIsDictating(false);
    };
    recognition.onerror = () => setIsDictating(false);
    recognition.onend = () => setIsDictating(false);
    recognition.start();
  };

  const tracks: Array<{
    id: ProfileTrack;
    label: string;
    candidateName: string;
    sub: string;
    icon: React.ElementType;
    badgeStyle: string;
  }> = [
    {
      id: 'TECHNICAL',
      label: 'Systems & Coordination',
      candidateName: 'Alex Mercer',
      sub: 'Organizing workflows, teamwork, and project delivery.',
      icon: Cpu,
      badgeStyle: 'border-emerald-500/30 bg-emerald-50 text-emerald-800',
    },
    {
      id: 'NON_TECHNICAL',
      label: 'Business & Operations',
      candidateName: 'Elena Rostova',
      sub: 'Planning, strategy, budgets, and reporting.',
      icon: Briefcase,
      badgeStyle: 'border-emerald-500/30 bg-emerald-50 text-emerald-800',
    },
    {
      id: 'MANUAL',
      label: 'Hands-On & Craft',
      candidateName: 'David Miller',
      sub: 'Quality control, practical work, and craftsmanship.',
      icon: Award,
      badgeStyle: 'border-emerald-500/30 bg-emerald-50 text-emerald-800',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* 2050 Quantum Hero Header */}
      <div className="text-center max-w-4xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-mono font-semibold mb-3 border border-emerald-500/30 shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>2050 Quantum Frosted Glass Architecture • Powered by Ski</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight sm:text-4xl">
          Skill to Job Opportunity — In the AI Era, a Verified Skill Means You Are Never Out of Work.
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-600 max-w-2xl mx-auto font-normal">
          Turn individual technical abilities into secure, borderless career opportunities instantly.
        </p>

        {/* 4D Time-Awareness & Merit Shield Hologram */}
        <div className="mt-4 p-3 rounded-2xl quantum-glass max-w-2xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs border border-emerald-500/30 shadow-xs">
          <div className="flex items-center gap-2.5 text-slate-700 text-left">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <strong className="text-slate-900">Anti-Layoff Quantum Shield:</strong> In the AI era, continuous verified capability protects you from restructuring. Demonstrated execution replaces pedigree.
            </div>
          </div>
          {onOpenForecastModal && (
            <button
              onClick={onOpenForecastModal}
              className="px-3 py-1.5 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-500/40 text-xs font-mono font-semibold transition-all flex items-center gap-1.5 shrink-0"
            >
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span>4D Trajectory Forecast</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Interactive Workspace (Split-Pane Holographic Cards) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Pane — Profile & Track Selector (3D Frosted Cards) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Floating 3D Frosted Cards for 3 Tracks */}
          <div className="quantum-glass rounded-2xl p-5 border border-emerald-500/30 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-600" />
                Profile & Track Selector
              </h3>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-500/40 font-semibold">
                Theme Morpher
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Select a specialized track to dynamically morph the surrounding workspace, proctoring scenarios & job radars:
            </p>

            <div className="grid grid-cols-1 gap-3">
              {tracks.map((trk) => {
                const IconComponent = trk.icon;
                const isSelected = user.track === trk.id;
                return (
                  <button
                    key={trk.id}
                    type="button"
                    onClick={() => handleSelectTrack(trk.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 quantum-tilt-card ${
                      isSelected
                        ? 'bg-emerald-50/90 border-2 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.2)] text-slate-900'
                        : 'bg-white/70 border-slate-200/80 hover:border-emerald-500/40 hover:bg-white/90 text-slate-700'
                    }`}
                  >
                    <div className={`p-2.5 rounded-xl border mt-0.5 shrink-0 transition-colors ${
                      isSelected 
                        ? 'bg-emerald-500 text-white border-emerald-400 shadow-[0_0_12px_#10B981]' 
                        : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                    }`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 flex items-center justify-between gap-1.5">
                        <span className="truncate">{trk.label}</span>
                        {isSelected && (
                          <span className="text-[10px] font-mono bg-emerald-500 text-white font-bold px-2 py-0.2 rounded-full">
                            Active
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-emerald-700 font-semibold mt-0.5">
                        Persona: {trk.candidateName}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                        {trk.sub}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Candidate Telemetry & Gap Shield */}
          <div className="quantum-glass rounded-2xl p-5 border border-emerald-500/30 space-y-4 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" />
              Candidate Telemetry & Merit Context
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-[10px] text-slate-500 uppercase font-mono">Candidate</span>
                <div className="font-bold text-slate-900 mt-0.5 truncate">{user.fullName}</div>
                <div className="text-[11px] text-slate-500 font-mono truncate">{user.location}</div>
              </div>
              <div className="p-3 rounded-xl bg-white/80 border border-emerald-500/20 shadow-xs">
                <span className="text-[10px] text-slate-500 uppercase font-mono">Career Pause / Break</span>
                <div className="font-bold text-emerald-700 mt-0.5 font-mono">{customGapYears} Years</div>
                <div className="text-[11px] text-slate-500 truncate">{gapReason}</div>
              </div>
            </div>

            {/* Predefined Core Competency Chips */}
            <div>
              <div className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2 font-mono">
                Featured Benchmark Competencies
              </div>
              <div className="flex flex-wrap gap-1.5">
                {SKILL_DOMAINS.slice(0, 6).map((skillObj) => (
                  <button
                    key={skillObj.id}
                    type="button"
                    onClick={() => handleSelectPredefinedSkill(skillObj.name)}
                    className={`text-xs px-2.5 py-1 rounded-lg border font-mono transition-all ${
                      selectedSkill === skillObj.name
                        ? 'bg-emerald-500 text-white font-bold border-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                        : 'bg-white/80 text-slate-700 border-slate-200 hover:border-emerald-500/40 hover:text-emerald-900 hover:bg-emerald-50'
                    }`}
                  >
                    {skillObj.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Proceed to System Check CTA */}
            <button
              type="button"
              onClick={() => onProceedToProctoring(selectedSkill)}
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(16,185,129,0.3)] cursor-pointer"
            >
              <span>Lock Track & Launch System Check</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Pane — Ski Neural Interface & Voice Hub (Live Audio Waves) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="quantum-glass rounded-2xl border border-emerald-500/30 overflow-hidden shadow-xs flex flex-col h-[640px]">
            {/* Neural Hub Header */}
            <div className="p-4 bg-emerald-50/70 border-b border-emerald-500/20 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white shadow-[0_0_15px_#10B981]">
                    <Bot className="w-5 h-5 font-bold" />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white animate-ping" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>Ski Neural Interface</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-500/40 font-semibold">
                      Voice & Text Synchronized
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Autonomous Ingestion, Verification Guidance & Merit Defense
                  </p>
                </div>
              </div>

              {/* Live Audio Wave Graphic */}
              <div className="flex items-center gap-1 bg-white/90 px-3 py-1.5 rounded-xl border border-emerald-500/30 shadow-xs">
                <Radio className={`w-3.5 h-3.5 text-emerald-600 ${isAudioSpeaking || isDictating ? 'animate-pulse' : ''}`} />
                <div className="flex items-end gap-0.5 h-5 w-16 px-1">
                  <span className={`w-1 bg-emerald-500 rounded-full transition-all ${isAudioSpeaking ? 'h-4 animate-bounce' : 'h-1.5'}`} />
                  <span className={`w-1 bg-emerald-500 rounded-full transition-all ${isAudioSpeaking ? 'h-5 animate-pulse' : 'h-2'}`} />
                  <span className={`w-1 bg-emerald-500 rounded-full transition-all ${isAudioSpeaking ? 'h-3 animate-bounce' : 'h-1'}`} />
                  <span className={`w-1 bg-emerald-500 rounded-full transition-all ${isAudioSpeaking ? 'h-5 animate-pulse' : 'h-2.5'}`} />
                  <span className={`w-1 bg-emerald-500 rounded-full transition-all ${isAudioSpeaking ? 'h-2 animate-bounce' : 'h-1'}`} />
                </div>
                <span className="text-[10px] font-mono text-emerald-700 font-bold">
                  {isAudioSpeaking ? 'SPEAKING' : isDictating ? 'LISTENING' : 'ONLINE'}
                </span>
              </div>
            </div>

            {/* Dialogue Transcript Window */}
            <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs font-sans bg-emerald-50/20">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'AI' && (
                    <div className="w-7 h-7 rounded-lg bg-emerald-100 border border-emerald-500/40 flex items-center justify-center text-emerald-700 shrink-0 text-xs font-bold shadow-xs">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-4 transition-all ${
                      msg.sender === 'USER'
                        ? 'bg-emerald-600 text-white font-medium rounded-tr-xs shadow-[0_4px_16px_rgba(16,185,129,0.25)]'
                        : 'bg-white text-slate-800 border border-emerald-500/25 rounded-tl-xs shadow-xs'
                    }`}
                  >
                    <div className="text-xs leading-relaxed whitespace-pre-line">
                      {msg.text}
                    </div>

                    {/* Inferred Hypotheses Pill Cards */}
                    {msg.structuredHypotheses && msg.structuredHypotheses.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-emerald-500/20 space-y-1.5">
                        <div className="text-[11px] font-bold text-emerald-700 uppercase font-mono tracking-wider">
                          Inferred Core Competencies:
                        </div>
                        <ul className="space-y-1 text-[11px] text-slate-600">
                          {msg.structuredHypotheses.map((hyp, i) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                              <span>{hyp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {msg.showNextCta && (
                      <div className="mt-3 pt-2">
                        <button
                          type="button"
                          onClick={() => onProceedToProctoring(selectedSkill)}
                          className="w-full py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(16,185,129,0.3)]"
                        >
                          <span>Proceed to System Check</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    <div className="text-[10px] text-slate-400 mt-2 text-right font-mono">
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex gap-2 items-center text-xs text-emerald-700 font-mono p-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span>Ski is calibrating merit rubric with Gemini 3.6...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Neural Message & Voice Input Tray */}
            <form
              onSubmit={handleSendMessage}
              className="p-3 bg-white/90 border-t border-emerald-500/20 flex items-center gap-2"
            >
              {/* Mic Voice Dictation Button */}
              <button
                type="button"
                onClick={handleVoiceToggle}
                className={`p-2.5 rounded-xl border transition-all ${
                  isDictating
                    ? 'bg-red-500 text-white border-red-400 animate-pulse shadow-[0_0_15px_#EF4444]'
                    : 'bg-white text-slate-700 border-emerald-500/30 hover:text-emerald-700 hover:border-emerald-400'
                }`}
                title={isDictating ? 'Stop Listening' : 'Speak to Ski'}
              >
                {isDictating ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="Share your practical skills, ask Ski questions, or describe your background..."
                disabled={loading}
                className="flex-1 py-2.5 px-4 rounded-xl bg-white border border-slate-300 text-slate-900 placeholder-slate-400 text-xs focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-sans"
              />

              <button
                type="submit"
                disabled={loading || !inputVal.trim()}
                className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_12px_rgba(16,185,129,0.3)] cursor-pointer"
                title="Send Message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
