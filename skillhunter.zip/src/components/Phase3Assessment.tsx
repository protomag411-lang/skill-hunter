import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  Award, 
  Clock, 
  CheckCircle2, 
  Sparkles, 
  Mic, 
  TrendingUp, 
  ArrowRight, 
  ShieldCheck, 
  Sliders,
  Layers,
  RotateCcw,
  Bot,
  Zap
} from 'lucide-react';
import { ProficiencyLevel, GradingResult, ProctoringState, ProfileTrack, AssessmentScenario } from '../types';
import { ASSESSMENT_SCENARIOS } from '../data/mockData';
import { gradeAssessment } from '../services/api';

interface Phase3AssessmentProps {
  selectedSkill: string;
  track?: ProfileTrack;
  proctoring: ProctoringState;
  onAssessmentCompleted: (grade: GradingResult) => void;
  onProceedToDrive: () => void;
  existingBadge: GradingResult | null;
}

export const Phase3Assessment: React.FC<Phase3AssessmentProps> = ({
  selectedSkill,
  track = 'TECHNICAL',
  proctoring,
  onAssessmentCompleted,
  onProceedToDrive,
  existingBadge,
}) => {
  const [tier, setTier] = useState<ProficiencyLevel>('ADVANCED');
  const [secondsRemaining, setSecondsRemaining] = useState(1200); // 20 mins
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  // Technical Track Simulator State (Workflow & Systems)
  const [routingThroughput, setRoutingThroughput] = useState(2500); // tasks/hr
  const [failoverThresholdMs, setFailoverThresholdMs] = useState(1400); // ms
  const [techStrategyNotes, setTechStrategyNotes] = useState(
    `Operational Continuity & Automated Routing Plan:
1. Implemented real-time request queue with priority dispatch: Urgent client requests are routed within 180 seconds.
2. Configured automated failover trigger at 1,400 ms response latency, redirecting traffic to secondary backup nodes with zero data loss.
3. Established a unified status dashboard across intake, service delivery, and executive reporting teams to eliminate manual reconciliation.`
  );

  // Non-Technical Track Simulator State (Growth & Budgeting)
  const [retargetingBudget, setRetargetingBudget] = useState(1600);
  const [prospectingBudget, setProspectingBudget] = useState(1200);
  const [marketingCopyAngle, setMarketingCopyAngle] = useState(
    'Premium Sustainability & Guaranteed Quality: 100% Verified Performance for Modern Commercial Living.'
  );
  const [growthStrategyNotes, setGrowthStrategyNotes] = useState(
    `Audited commercial customer acquisition funnel:
1. Reallocated $1,600 into dynamic engagement for high-intent 7-day interested prospects.
2. Directed $1,200 toward targeted regional partner networks with proven buyer retention.
3. Established an executive weekly reporting memo tracking customer lifetime value and cost per acquired account.`
  );

  // Manual Track Simulator State (Precision Craftsmanship & QA)
  const [surfaceGrit, setSurfaceGrit] = useState(240);
  const [coatingRatio, setCoatingRatio] = useState(3); // 3:1 ratio
  const [craftStrategyNotes, setCraftStrategyNotes] = useState(
    `Quality Control & Historic Restoration Procedure:
1. Cleaned and stabilized substrate delamination using reversible conservation-grade hide adhesive.
2. Step-sanded wood veneer progressing through 180 to 240 grit micro-abrasives to preserve heritage patina.
3. Applied hand-rubbed shellac and natural carnauba wax at calibrated 3:1 ratio, providing ultraviolet barrier with breathable sheen.`
  );

  // Verbal Defense State
  const [verbalDefenseTranscript, setVerbalDefenseTranscript] = useState('');
  const [isRecordingVerbal, setIsRecordingVerbal] = useState(false);

  // Evaluation & Grading State
  const [isGrading, setIsGrading] = useState(false);
  const [badgeResult, setBadgeResult] = useState<GradingResult | null>(existingBadge);

  const domainKey = track === 'TECHNICAL'
    ? 'Digital Systems & Workflow Coordination'
    : track === 'NON_TECHNICAL'
    ? 'Growth Strategy & Marketing Operations'
    : 'Precision Craftsmanship & Quality Control';

  const trackScenarios = ASSESSMENT_SCENARIOS[domainKey] || Object.values(ASSESSMENT_SCENARIOS)[0];
  const currentScenario: AssessmentScenario = trackScenarios[tier] || trackScenarios.ADVANCED;

  // Countdown Timer
  useEffect(() => {
    if (!isTimerRunning) return;
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsTimerRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSimulateVerbalRecord = () => {
    setIsRecordingVerbal(true);
    let sample = '';
    if (track === 'TECHNICAL') {
      sample = 'I prioritized high-throughput automated load balancing and set strict 1400ms failover rules to prevent downtime during peak enterprise usage.';
    } else if (track === 'NON_TECHNICAL') {
      sample = 'I reallocated 60% of the growth pool into high-intent retargeting while maintaining a 40% prospecting runway to ensure positive unit economics.';
    } else {
      sample = 'I balanced substrate preservation with reversible natural adhesives, stepping through 240 grit abrasive to protect the historic grain structure.';
    }

    setTimeout(() => {
      setVerbalDefenseTranscript(sample);
      setIsRecordingVerbal(false);
    }, 1800);
  };

  const handleSubmitForGrading = async () => {
    setIsGrading(true);
    let submissionArtifact = '';
    if (track === 'TECHNICAL') {
      submissionArtifact = `Throughput: ${routingThroughput}/hr | Failover: ${failoverThresholdMs}ms\n\nNotes:\n${techStrategyNotes}`;
    } else if (track === 'NON_TECHNICAL') {
      submissionArtifact = `Retargeting: $${retargetingBudget} | Prospecting: $${prospectingBudget} | Angle: ${marketingCopyAngle}\n\nNotes:\n${growthStrategyNotes}`;
    } else {
      submissionArtifact = `Grit: ${surfaceGrit} | Ratio: ${coatingRatio}:1\n\nNotes:\n${craftStrategyNotes}`;
    }

    try {
      const result = await gradeAssessment({
        skillDomain: currentScenario.skillDomain,
        tier,
        scenarioTitle: currentScenario.title,
        candidateWork: submissionArtifact,
        verbalDefenseText: verbalDefenseTranscript || 'Candidate demonstrated competent end-to-end technical approach.',
      });

      setBadgeResult(result);
      onAssessmentCompleted(result);

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#34d399', '#059669', '#6ee7b7'],
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsGrading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 text-slate-800">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-mono font-semibold mb-2 border border-emerald-500/30 shadow-xs">
            <Award className="w-3.5 h-3.5 text-emerald-600" />
            <span>Phase 3: Practical Skill Verification & Official Quantum Badge • Ski Evaluation</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {currentScenario.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 font-mono">
            Domain: <strong className="text-emerald-700">{selectedSkill}</strong> ({track.replace('_', ' ')} Track) • Proctored live session
          </p>
        </div>

        {/* Timer & Proctor Status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3.5 py-2 bg-white/90 text-slate-800 rounded-xl border border-emerald-500/30 shadow-xs">
            <Clock className="w-4 h-4 text-emerald-600" />
            <span className="font-mono text-sm font-bold tracking-wider text-emerald-700">
              {formatTime(secondsRemaining)}
            </span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-2 bg-emerald-100 text-emerald-800 border border-emerald-500/40 rounded-xl text-xs font-semibold font-mono shadow-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Verification Active</span>
          </div>
        </div>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Problem Brief & Objectives */}
        <div className="lg:col-span-5 space-y-6">
          {/* Tier Selector */}
          <div className="quantum-glass rounded-2xl p-4 border border-emerald-500/30 shadow-xs flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 uppercase font-mono">Target Tier:</span>
            <div className="flex gap-1.5">
              {(['BEGINNER', 'INTERMEDIATE', 'ADVANCED'] as ProficiencyLevel[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTier(t)}
                  className={`px-3 py-1 text-xs rounded-xl font-mono font-semibold transition-all cursor-pointer ${
                    tier === t
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Scenario Context */}
          <div className="quantum-glass rounded-2xl p-6 border border-emerald-500/30 space-y-4 shadow-xs">
            <div>
              <h3 className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-1 font-mono">
                Executive Problem Statement
              </h3>
              <p className="text-xs text-slate-700 leading-relaxed">
                {currentScenario.context}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-2 font-mono">
                Mandatory Deliverables
              </h3>
              <ul className="space-y-2">
                {currentScenario.taskObjectives.map((obj, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-500/20 text-xs text-slate-800 space-y-1">
              <span className="font-bold text-emerald-800 block font-mono">Baseline Parameters:</span>
              <pre className="font-mono text-[11px] whitespace-pre-line text-slate-700 leading-normal">
                {currentScenario.initialDataOrCode}
              </pre>
            </div>

            <div className="border-t border-emerald-500/20 pt-3">
              <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block mb-1 font-mono">
                Evaluation Criteria (Three Pillars):
              </span>
              <div className="text-[11px] text-slate-600 space-y-1">
                <p>• <strong className="text-slate-800">Execution Quality:</strong> {currentScenario.evaluationCriteria.technical}</p>
                <p>• <strong className="text-slate-800">Problem Solving:</strong> {currentScenario.evaluationCriteria.problemSolving}</p>
                <p>• <strong className="text-slate-800">Verbal Defense:</strong> {currentScenario.evaluationCriteria.verbalDefense}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Workspace & Verbal Defense */}
        <div className="lg:col-span-7 space-y-6">
          {/* Interactive Simulator Card */}
          <div className="quantum-glass rounded-2xl p-6 border border-emerald-500/30 space-y-5 shadow-xs">
            <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {track === 'TECHNICAL'
                    ? 'Interactive Workflow Orchestration & Resilience Simulator'
                    : track === 'NON_TECHNICAL'
                    ? 'Interactive Budget Reallocation & Growth Simulator'
                    : 'Interactive Surface Restoration & Quality Simulator'}
                </h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-500/30 font-semibold">
                Live Engine
              </span>
            </div>

            {/* Dynamic Simulator Controls based on Track */}
            {track === 'TECHNICAL' ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Task Routing Throughput</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">{routingThroughput} / hr</span>
                    </div>
                    <input
                      type="range"
                      min="500"
                      max="5000"
                      step="100"
                      value={routingThroughput}
                      onChange={(e) => setRoutingThroughput(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Service capacity ceiling</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Failover Latency Trigger</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">{failoverThresholdMs} ms</span>
                    </div>
                    <input
                      type="range"
                      min="800"
                      max="2500"
                      step="50"
                      value={failoverThresholdMs}
                      onChange={(e) => setFailoverThresholdMs(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Triggers automated secondary routing</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-500/30 text-slate-800 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    <span>Projected System Uptime: <strong className="text-emerald-700 font-bold">99.98%</strong></span>
                  </div>
                  <div className="text-emerald-800">
                    Routing Latency: <strong className="font-bold">140ms avg</strong>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-800 block mb-1 font-mono uppercase">
                    System Architecture & Handshake Specification
                  </label>
                  <textarea
                    value={techStrategyNotes}
                    onChange={(e) => setTechStrategyNotes(e.target.value)}
                    rows={4}
                    className="w-full text-xs p-3 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 leading-relaxed font-mono"
                  />
                </div>
              </div>
            ) : track === 'NON_TECHNICAL' ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Retargeting Pool</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">${retargetingBudget}</span>
                    </div>
                    <input
                      type="range"
                      min="500"
                      max="3000"
                      step="100"
                      value={retargetingBudget}
                      onChange={(e) => setRetargetingBudget(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">7-day high intent audience</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Prospecting Pool</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">${prospectingBudget}</span>
                    </div>
                    <input
                      type="range"
                      min="500"
                      max="3000"
                      step="100"
                      value={prospectingBudget}
                      onChange={(e) => setProspectingBudget(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Qualified partner channels</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-500/30 text-slate-800 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-600" />
                    <span>Projected MER: <strong className="text-emerald-700 font-bold">3.4x</strong></span>
                  </div>
                  <div className="text-emerald-800">
                    Est. CAC: <strong className="font-bold">$54 / client</strong>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-800 block mb-1 font-mono uppercase">
                    Core Messaging & Value Proposition
                  </label>
                  <input
                    type="text"
                    value={marketingCopyAngle}
                    onChange={(e) => setMarketingCopyAngle(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl bg-white border border-slate-300 text-slate-900 mb-2 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 font-sans"
                  />
                  <label className="text-xs font-bold text-slate-800 block mb-1 font-mono uppercase">
                    Strategic Budget Rationale & Executive Memo
                  </label>
                  <textarea
                    value={growthStrategyNotes}
                    onChange={(e) => setGrowthStrategyNotes(e.target.value)}
                    rows={4}
                    className="w-full text-xs p-3 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 leading-relaxed font-sans"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Surface Preparation Grit</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">{surfaceGrit} Grit</span>
                    </div>
                    <input
                      type="range"
                      min="120"
                      max="320"
                      step="40"
                      value={surfaceGrit}
                      onChange={(e) => setSurfaceGrit(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Micro-abrasive standard</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/80 border border-slate-200">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-xs font-semibold text-slate-700">Coating Mix Ratio</label>
                      <span className="text-xs font-bold font-mono text-emerald-700">{coatingRatio}:1</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      step="1"
                      value={coatingRatio}
                      onChange={(e) => setCoatingRatio(Number(e.target.value))}
                      className="w-full accent-emerald-600"
                    />
                    <span className="text-[10px] text-slate-500 font-mono">Resin to curing catalyst</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-500/30 text-slate-800 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-emerald-600" />
                    <span>Finish Grade: <strong className="text-emerald-700 font-bold">98.6% (Exceeds Spec)</strong></span>
                  </div>
                  <div className="text-emerald-800">
                    Delta E: <strong className="font-bold">1.2</strong>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-800 block mb-1 font-mono uppercase">
                    Conservation Protocol & QA Report
                  </label>
                  <textarea
                    value={craftStrategyNotes}
                    onChange={(e) => setCraftStrategyNotes(e.target.value)}
                    rows={4}
                    className="w-full text-xs p-3 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 leading-relaxed font-sans"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Verbal Defense Section */}
          <div className="quantum-glass rounded-2xl p-6 border border-emerald-500/30 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Verbal Defense & Strategic Explanation
                </h3>
              </div>
              <span className="text-[11px] text-emerald-800 font-mono font-semibold">
                Pillar 3: Spoken Rationale
              </span>
            </div>

            <p className="text-xs text-slate-600">
              Explain why your approach solves the root problem and how you defended against potential risks.
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
                  if (SpeechRecognition) {
                    try {
                      const rec = new SpeechRecognition();
                      rec.onstart = () => setIsRecordingVerbal(true);
                      rec.onresult = (ev: any) => {
                        const t = ev.results[0][0].transcript;
                        setVerbalDefenseTranscript((prev) => (prev ? prev + ' ' + t : t));
                      };
                      rec.onerror = () => setIsRecordingVerbal(false);
                      rec.onend = () => setIsRecordingVerbal(false);
                      rec.start();
                    } catch (err) {
                      handleSimulateVerbalRecord();
                    }
                  } else {
                    handleSimulateVerbalRecord();
                  }
                }}
                disabled={isRecordingVerbal}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  isRecordingVerbal
                    ? 'bg-red-500 text-white animate-pulse shadow-md'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 shadow-xs'
                }`}
              >
                <Mic className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isRecordingVerbal ? 'Listening & Transcribing...' : 'Record Spoken Explanation'}</span>
              </button>

              <span className="text-[11px] text-slate-500 font-mono">
                {isRecordingVerbal ? 'Microphone active — speak clearly...' : 'Microphone ready'}
              </span>
            </div>

            <textarea
              value={verbalDefenseTranscript}
              onChange={(e) => setVerbalDefenseTranscript(e.target.value)}
              rows={3}
              className="w-full text-xs p-3 rounded-xl bg-white border border-slate-300 text-slate-900 focus:outline-hidden focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 leading-relaxed font-sans placeholder:text-slate-400"
              placeholder="Your spoken explanation transcription appears here..."
            />

            {/* Submission CTA */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleSubmitForGrading}
                disabled={isGrading}
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition-all flex items-center justify-center gap-2 shadow-md disabled:opacity-50 cursor-pointer"
              >
                {isGrading ? (
                  <>
                    <Bot className="w-4 h-4 animate-spin" />
                    <span>Ski is evaluating your performance across core pillars...</span>
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4" />
                    <span>Submit Practical Evaluation for Official Badge</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Certified Official Badge Result */}
          {badgeResult && (
            <div className="quantum-glass rounded-2xl p-6 sm:p-8 border border-emerald-500 shadow-lg space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-emerald-500/20 pb-5">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md">
                    <Award className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-bold text-slate-900">
                        Verified {badgeResult.badgeTier} Badge
                      </h2>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 font-mono">
                        OFFICIAL 2050
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 font-mono">
                      Certificate ID: {badgeResult.certificateId} • Authenticity: Verified
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl sm:text-3xl font-black text-emerald-700 font-mono">
                    {badgeResult.overallScore}/100
                  </div>
                  <span className="text-[11px] text-slate-500 uppercase tracking-wider font-mono">
                    Composite Merit Score
                  </span>
                </div>
              </div>

              {/* 3 Pillars Score Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-500/30">
                  <span className="text-[11px] text-slate-600 block mb-1">Execution Quality</span>
                  <div className="text-lg font-bold text-emerald-700 font-mono">
                    {badgeResult.pillarScores.technicalProficiency}/100
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-500/30">
                  <span className="text-[11px] text-slate-600 block mb-1">Problem-Solving Strategy</span>
                  <div className="text-lg font-bold text-emerald-700 font-mono">
                    {badgeResult.pillarScores.problemSolvingProcess}/100
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-500/30">
                  <span className="text-[11px] text-slate-600 block mb-1">Verbal Defense & Clarity</span>
                  <div className="text-lg font-bold text-emerald-700 font-mono">
                    {badgeResult.pillarScores.verbalDefense}/100
                  </div>
                </div>
              </div>

              {/* Ski Feedback */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 font-mono">
                  <Bot className="w-4 h-4" />
                  <span>Evaluation from Ski:</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed bg-white p-3.5 rounded-xl border border-emerald-500/20 font-sans">
                  {badgeResult.constructiveFeedback}
                </p>
              </div>

              {/* Next Step CTA */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-xs text-slate-600 font-mono">
                  Next: Connect your practical documents, presentations, and team files.
                </span>
                <button
                  type="button"
                  onClick={onProceedToDrive}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <span>Proceed to Phase 4: Work Files Hub</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
