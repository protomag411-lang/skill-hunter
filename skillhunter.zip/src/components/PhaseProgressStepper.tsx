import React from 'react';
import { 
  CheckCircle2, 
  MessageSquare, 
  ShieldCheck, 
  Award, 
  FolderGit2, 
  FileText, 
  Compass, 
  Send, 
  Video,
  Layers,
  Cpu,
  Sparkles,
  Zap,
  Globe
} from 'lucide-react';
import { ProfileTrack, UserProfile } from '../types';

interface PhaseProgressStepperProps {
  currentPhase: number;
  onSelectPhase: (phase: number) => void;
  user: UserProfile;
  onSelectTrack: (track: ProfileTrack) => void;
  onOpenMCPModal: () => void;
}

interface StepMeta {
  phase: number;
  label: string;
  subtitle: string;
  icon: React.ElementType;
}

const PHASES: StepMeta[] = [
  { phase: 1, label: 'Intake & Track', subtitle: 'Meet with Ski', icon: MessageSquare },
  { phase: 2, label: 'System Check', subtitle: 'Camera & screen setup', icon: ShieldCheck },
  { phase: 3, label: 'Practical Evaluation', subtitle: 'Scenario & badge', icon: Award },
  { phase: 4, label: 'Work Files Hub', subtitle: 'Project evidence & cloud storage', icon: FolderGit2 },
  { phase: 5, label: 'Professional Resume', subtitle: 'ATS template & CV converter', icon: FileText },
  { phase: 6, label: 'Opportunities', subtitle: 'Universal connector radar', icon: Compass },
  { phase: 7, label: 'Review & Approval', subtitle: 'HITL dispatch gate', icon: Send },
  { phase: 8, label: 'Interview Prep', subtitle: 'AI-simulated scenarios', icon: Video },
  { phase: 9, label: 'Final Placement', subtitle: 'Autonomous career sync', icon: Globe },
];

export const PhaseProgressStepper: React.FC<PhaseProgressStepperProps> = ({
  currentPhase,
  onSelectPhase,
  user,
  onSelectTrack,
  onOpenMCPModal,
}) => {
  const currentStep = PHASES.find((p) => p.phase === currentPhase) || PHASES[0];
  const progressPercent = Math.round((currentPhase / PHASES.length) * 100);

  return (
    <div className="quantum-glass bg-white/75 border-b border-emerald-500/20 text-slate-800 backdrop-blur-xl relative overflow-hidden">
      {/* Subtle Holographic Grid Background Overlay */}
      <div className="absolute inset-0 quantum-grid-pattern opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 relative z-10">
        {/* Top Control Bar: Active Phase Title + 3D Frosted Track Switcher */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-emerald-500/15">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-500/30 text-xs font-bold font-mono shadow-xs">
              0{currentPhase}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 font-mono">
                  2050 Quantum Pipeline • Node {currentPhase} of 9
                </span>
                <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-500/30 font-semibold">
                  {progressPercent}% Harmonized
                </span>
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2 mt-0.5">
                <span>{currentStep.label}:</span>
                <span className="font-normal text-slate-600 text-xs sm:text-sm">{currentStep.subtitle}</span>
              </h2>
            </div>
          </div>

          {/* Floating 3D Frosted Track Selector */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-white/90 p-1 rounded-2xl border border-emerald-500/30 text-xs shadow-xs">
              <span className="text-[11px] text-slate-500 px-2 font-medium flex items-center gap-1 font-mono">
                <Layers className="w-3 h-3 text-emerald-600" />
                Track:
              </span>
              <button
                type="button"
                onClick={() => onSelectTrack('TECHNICAL')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  user.track === 'TECHNICAL'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-emerald-50/80'
                }`}
                title="Systems & Coordination: Organizing workflows, teamwork, and project delivery"
              >
                Systems & Coordination
              </button>
              <button
                type="button"
                onClick={() => onSelectTrack('NON_TECHNICAL')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  user.track === 'NON_TECHNICAL'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-emerald-50/80'
                }`}
                title="Business & Operations: Planning, strategy, budgets, and reporting"
              >
                Business & Operations
              </button>
              <button
                type="button"
                onClick={() => onSelectTrack('MANUAL')}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                  user.track === 'MANUAL'
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-emerald-50/80'
                }`}
                title="Hands-On & Craft: Quality control, practical work, and craftsmanship"
              >
                Hands-On & Craft
              </button>
            </div>

            <button
              type="button"
              onClick={onOpenMCPModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/80 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 border border-emerald-500/30 text-xs font-semibold transition-all hover:border-emerald-400 shadow-xs"
              title="Connected Tools, File Services & Intelligence Engine"
            >
              <Cpu className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Connected Tools</span>
            </button>
          </div>
        </div>

        {/* 9 Spatial Workflow Nodes */}
        <div className="pt-3 overflow-x-auto no-scrollbar">
          <div className="min-w-[840px] flex items-center justify-between gap-1.5">
            {PHASES.map((step, idx) => {
              const isCurrent = step.phase === currentPhase;
              const isCompleted = step.phase < currentPhase;
              const Icon = step.icon;

              return (
                <div key={step.phase} className="flex-1 flex items-center">
                  <button
                    type="button"
                    onClick={() => onSelectPhase(step.phase)}
                    className={`group w-full text-left p-2 rounded-xl transition-all flex items-center gap-2.5 quantum-tilt-card ${
                      isCurrent
                        ? 'bg-emerald-50/90 border-2 border-emerald-500 shadow-xs text-slate-900'
                        : isCompleted
                        ? 'bg-white/80 hover:bg-emerald-50/70 text-slate-800 border border-emerald-500/25 shadow-xs'
                        : 'bg-white/60 hover:bg-white/90 text-slate-500 border border-slate-200/80 shadow-xs'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold font-mono transition-all ${
                        isCurrent
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : isCompleted
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-500/30'
                          : 'bg-slate-100 text-slate-400 group-hover:bg-slate-200'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      ) : (
                        step.phase
                      )}
                    </div>

                    <div className="min-w-0 pr-1">
                      <div className={`text-xs font-semibold truncate leading-snug ${isCurrent ? 'text-emerald-800 font-bold' : 'text-slate-800'}`}>
                        {step.label}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate leading-snug font-mono">
                        {step.subtitle}
                      </div>
                    </div>
                  </button>

                  {idx < PHASES.length - 1 && (
                    <div className={`w-2 h-0.5 mx-1 shrink-0 ${isCompleted ? 'bg-emerald-500/60' : 'bg-slate-200'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Glowing Emerald Spatial Progress Line */}
        <div className="w-full bg-slate-200/80 h-1.5 rounded-full mt-3 overflow-hidden border border-emerald-500/20 p-0.2">
          <div
            className="bg-gradient-to-r from-emerald-600 to-emerald-500 h-full rounded-full transition-all duration-300 ease-out shadow-xs"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
