import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  DollarSign, 
  Briefcase, 
  Send, 
  FileSpreadsheet, 
  CheckCircle2, 
  Copy, 
  Check, 
  ExternalLink, 
  Award, 
  TrendingUp, 
  ShieldCheck, 
  Sparkles, 
  RefreshCw, 
  FileText,
  UserCheck,
  Building2,
  Calendar,
  MessageSquare
} from 'lucide-react';
import { UserProfile, GradingResult } from '../types';
import { fetchMonetizePitch } from '../services/api';

interface SkillMonetizationModuleProps {
  user: UserProfile;
  badge: GradingResult | null;
  onReturnToJobs?: () => void;
}

interface ProspectRow {
  id: string;
  companyName: string;
  decisionMaker: string;
  role: string;
  linkedInUrl: string;
  bottleneck: string;
  pitchStatus: 'READY_TO_SEND' | 'PITCH_SENT' | 'REPLIED' | 'DEAL_CLOSED';
  dealValue: string;
}

const INITIAL_PROSPECTS: ProspectRow[] = [
  {
    id: 'pr-1',
    companyName: 'Apex Data Labs',
    decisionMaker: 'David Chen',
    role: 'Head of Growth Operations',
    linkedInUrl: 'https://linkedin.com/in/david-chen-sample',
    bottleneck: 'Manual campaign tracking & delayed reporting',
    pitchStatus: 'READY_TO_SEND',
    dealValue: '$750',
  },
  {
    id: 'pr-2',
    companyName: 'Solstice Commerce',
    decisionMaker: 'Elena Rostova',
    role: 'Founder & CEO',
    linkedInUrl: 'https://linkedin.com/in/elena-rostova-sample',
    bottleneck: 'High checkout abandonment & lack of attribution',
    pitchStatus: 'PITCH_SENT',
    dealValue: '$1,800',
  },
  {
    id: 'pr-3',
    companyName: 'Vanguard Media Group',
    decisionMaker: 'Marcus Thorne',
    role: 'Managing Director',
    linkedInUrl: 'https://linkedin.com/in/marcus-thorne-sample',
    bottleneck: 'Scaling creative testing without agency headcount',
    pitchStatus: 'DEAL_CLOSED',
    dealValue: '$2,400',
  },
];

export const SkillMonetizationModule: React.FC<SkillMonetizationModuleProps> = ({
  user,
  badge,
  onReturnToJobs,
}) => {
  const [monetizationData, setMonetizationData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedTierIndex, setSelectedTierIndex] = useState<number>(1);
  const [activeChannel, setActiveChannel] = useState<'LINKEDIN' | 'EMAIL'>('LINKEDIN');
  const [prospects, setProspects] = useState<ProspectRow[]>(INITIAL_PROSPECTS);
  const [copiedPitch, setCopiedPitch] = useState<boolean>(false);
  const [copiedSOW, setCopiedSOW] = useState<boolean>(false);
  const [showSOWModal, setShowSOWModal] = useState<boolean>(false);

  // New Prospect State
  const [newCompany, setNewCompany] = useState('');
  const [newContact, setNewContact] = useState('');
  const [newBottleneck, setNewBottleneck] = useState('');
  const [newValue, setNewValue] = useState('$650');

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      setIsLoading(true);
      try {
        const data = await fetchMonetizePitch({
          skillName: user.primarySkill,
          badgeLevel: badge?.badgeTier || 'ADVANCED',
        });
        if (isMounted) setMonetizationData(data);
      } catch (e) {
        console.error(e);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [user.primarySkill, badge]);

  const handleCopyPitch = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPitch(true);
    setTimeout(() => setCopiedPitch(false), 2000);
  };

  const handleCopySOW = () => {
    const selectedPkg = monetizationData?.packages?.[selectedTierIndex] || {
      title: `${user.primarySkill} Execution Package`,
      deliverable: '48-hour turnkey execution sprint with tested artifacts',
      priceRecommendation: '$750',
    };
    const sowText = `================================================
STATEMENT OF WORK (SOW) & CLIENT ENGAGEMENT PROPOSAL
================================================
Prepared By: ${user.fullName}
Verified Credential: Skill Hunter ${badge?.badgeTier || 'ADVANCED'} (${user.primarySkill})
Certificate ID: ${badge?.certificateId || 'SH-2026-CERT98'}
Verification Seal: Certified by Ski

DELIVERABLE TIER: ${selectedPkg.title}
FEE: ${selectedPkg.priceRecommendation}
TIMELINE: 3 - 5 Business Days Turnaround

SCOPE OF WORK:
1. Complete diagnostic audit of business workflow and operational bottleneck.
2. Direct execution and implementation of ${user.primarySkill} strategy.
3. Delivery of documented, production-ready deliverables with full operational handover.
4. 14 days of post-deployment consultation and team enablement.

PAYMENT TERMS:
50% upon engagement kickoff, 50% upon final sign-off.
`;
    navigator.clipboard.writeText(sowText);
    setCopiedSOW(true);
    setTimeout(() => setCopiedSOW(false), 2000);
  };

  const handleAddProspect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompany.trim()) return;
    const newEntry: ProspectRow = {
      id: `pr-${Date.now()}`,
      companyName: newCompany,
      decisionMaker: newContact || 'Direct Hiring Manager',
      role: 'Operations / Technical Lead',
      linkedInUrl: 'https://linkedin.com/search/results/all',
      bottleneck: newBottleneck || 'Manual operational bottlenecks',
      pitchStatus: 'READY_TO_SEND',
      dealValue: newValue || '$750',
    };
    setProspects([newEntry, ...prospects]);
    setNewCompany('');
    setNewContact('');
    setNewBottleneck('');
  };

  const handleUpdateStatus = (id: string, nextStatus: ProspectRow['pitchStatus']) => {
    setProspects(
      prospects.map((p) => (p.id === id ? { ...p, pitchStatus: nextStatus } : p))
    );
  };

  const totalPipeline = prospects.reduce((acc, curr) => {
    const val = parseInt(curr.dealValue.replace(/[^0-9]/g, ''), 10) || 0;
    return acc + val;
  }, 0);

  const closedRevenue = prospects
    .filter((p) => p.pitchStatus === 'DEAL_CLOSED')
    .reduce((acc, curr) => {
      const val = parseInt(curr.dealValue.replace(/[^0-9]/g, ''), 10) || 0;
      return acc + val;
    }, 0);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 text-slate-800">
      {/* 2050 Quantum Frosted Header Banner */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 shadow-xs border border-emerald-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-500/30 text-xs font-mono font-semibold uppercase tracking-wider shadow-xs">
              <Zap className="w-3.5 h-3.5 text-emerald-600" />
              Phase 9 of 9: 2050 Direct Client Proposals & Earnings • Ski Marketplace
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Direct Advisory & Skill Monetization Hub
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              When standard hiring processes move slowly, capitalize on direct advisory opportunities. Ski packages your verified capability into high-value service tiers, executive outreach memos, and professional Statements of Work (SOW).
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 font-mono">
            <button
              onClick={() => setShowSOWModal(true)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Generate Statement of Work (SOW)</span>
            </button>
            {onReturnToJobs && (
              <button
                onClick={onReturnToJobs}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-medium text-xs transition-all cursor-pointer shadow-xs"
              >
                Return to Job Finder
              </button>
            )}
          </div>
        </div>

        {/* Revenue & Pipeline Metric Ribbon */}
        <div className="mt-6 pt-6 border-t border-emerald-500/20 grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono">
          <div className="p-3.5 rounded-xl bg-slate-50/90 border border-emerald-500/20 shadow-xs">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
              Active Prospect Pipeline
            </span>
            <span className="text-lg font-bold text-slate-900">${totalPipeline.toLocaleString()}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-emerald-50/90 border border-emerald-500/30 shadow-xs">
            <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider block">
              Direct Closed Revenue
            </span>
            <span className="text-lg font-bold text-emerald-700">${closedRevenue.toLocaleString()}</span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50/90 border border-emerald-500/20 shadow-xs">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
              Verified Credential Backing
            </span>
            <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1 mt-1">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              {badge?.badgeTier || 'ADVANCED'} ({badge?.overallScore || 96}/100)
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50/90 border border-emerald-500/20 shadow-xs">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
              Core Motto
            </span>
            <span className="text-[11px] text-slate-700 line-clamp-2 mt-1 font-sans">
              A single verified skill can never be laid off.
            </span>
          </div>
        </div>
      </div>

      {/* Section 1: Service Productization Tiers */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 border border-emerald-500/30 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-emerald-500/20">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-500/30 font-mono">
                Pillar 1: Productization
              </span>
              <span className="text-xs font-semibold text-slate-500 font-mono">
                Turn Skills into Turnkey Client Offers
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Packaged Service Tiers for {user.primarySkill}
            </h2>
            <p className="text-xs text-slate-600">
              Clients pay premium rates for fixed, predictable outcomes rather than hourly uncertainty.
            </p>
          </div>

          <div className="text-xs text-emerald-700 font-medium flex items-center gap-1.5 font-mono">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Pricing calibrated to your {badge?.badgeTier || 'ADVANCED'} badge score</span>
          </div>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {monetizationData?.packages?.map((pkg: any, idx: number) => {
            const isSelected = selectedTierIndex === idx;
            return (
              <div
                key={idx}
                onClick={() => setSelectedTierIndex(idx)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-emerald-50/90 border-emerald-500 shadow-sm ring-2 ring-emerald-500/20'
                    : 'bg-white/80 border-slate-200 hover:border-emerald-500/40 shadow-xs'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between font-mono">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                      {pkg.tier}
                    </span>
                    {isSelected && (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                        <Check className="w-3.5 h-3.5" /> Selected
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {pkg.title}
                  </h3>

                  <div className="text-xl font-extrabold text-emerald-700 font-mono">
                    {pkg.priceRecommendation}
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {pkg.deliverable}
                  </p>
                </div>

                <div className="mt-4 pt-4 border-t border-emerald-500/15 font-mono">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider block">
                    Proof Anchor:
                  </span>
                  <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                    {pkg.verifiedProofHighlight}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 2: Direct Outreach & Pitching Matrix */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 border border-emerald-500/30 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-emerald-500/20">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-500/30 font-mono">
                Pillar 2: Direct Outreach
              </span>
              <span className="text-xs font-semibold text-slate-500 font-mono">
                Client Acquisition
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Executive Outreach Templates Citing Verified Skill Proof
            </h2>
            <p className="text-xs text-slate-600">
              Cut through recruiter noise by pitching direct business outcomes to decision makers with verifiable credentials.
            </p>
          </div>

          {/* Channel Selector */}
          <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 font-mono">
            <button
              onClick={() => setActiveChannel('LINKEDIN')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeChannel === 'LINKEDIN'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              LinkedIn DM Pitch
            </button>
            <button
              onClick={() => setActiveChannel('EMAIL')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeChannel === 'EMAIL'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Email Proposal
            </button>
          </div>
        </div>

        {/* Selected Pitch Template */}
        {monetizationData?.pitches && (
          <div className="bg-slate-50/90 rounded-xl p-5 border border-emerald-500/20 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 font-mono">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-700">
                  Target Audience:
                </span>
                <span className="text-xs text-emerald-700 font-medium px-2 py-0.5 bg-emerald-50 rounded border border-emerald-500/30">
                  {activeChannel === 'LINKEDIN'
                    ? monetizationData.pitches[0]?.targetPersona
                    : monetizationData.pitches[1]?.targetPersona}
                </span>
              </div>

              <button
                onClick={() =>
                  handleCopyPitch(
                    activeChannel === 'LINKEDIN'
                      ? monetizationData.pitches[0]?.body
                      : `Subject: ${monetizationData.pitches[1]?.subject}\n\n${monetizationData.pitches[1]?.body}`
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-emerald-500/30 text-emerald-700 text-xs font-semibold hover:bg-emerald-50 transition-colors shadow-xs cursor-pointer"
              >
                {copiedPitch ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPitch ? 'Copied Pitch!' : 'Copy to Clipboard'}</span>
              </button>
            </div>

            {activeChannel === 'EMAIL' && (
              <div className="text-xs font-semibold text-slate-900 bg-white p-2.5 rounded-lg border border-emerald-500/20 font-mono">
                <span className="text-slate-500 font-normal">Subject Line: </span>
                {monetizationData.pitches[1]?.subject}
              </div>
            )}

            <div className="bg-white p-4 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed shadow-xs">
              {activeChannel === 'LINKEDIN'
                ? monetizationData.pitches[0]?.body
                : monetizationData.pitches[1]?.body}
            </div>
          </div>
        )}
      </div>

      {/* Section 3: Free-Tool Prospecting Tracker (Google Sheets Simulation) */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 sm:p-8 border border-emerald-500/30 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-emerald-500/20">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 px-2 py-0.5 rounded bg-emerald-50 border border-emerald-500/30 font-mono">
                Pillar 3: 2050 Deal Pipeline Tracker
              </span>
              <span className="text-xs font-semibold text-slate-500 font-mono">
                Google Sheets Integration
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Direct Client Deal Tracker
            </h2>
            <p className="text-xs text-slate-600">
              Daily prospecting workflow: add target organizations and send tailored pitches with zero software subscription fees.
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono">
            <span className="text-xs text-emerald-700 font-medium bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-500/30">
              {prospects.length} Active Leads
            </span>
          </div>
        </div>

        {/* Fast Add Prospect Form */}
        <form onSubmit={handleAddProspect} className="grid grid-cols-1 sm:grid-cols-5 gap-3 p-3.5 bg-slate-50/90 rounded-xl border border-emerald-500/20 font-mono shadow-xs">
          <input
            type="text"
            placeholder="Target Company (e.g. Zenith Media)"
            value={newCompany}
            onChange={(e) => setNewCompany(e.target.value)}
            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white text-slate-900 focus:outline-none focus:border-emerald-500 placeholder-slate-400"
            required
          />
          <input
            type="text"
            placeholder="Decision Maker Name"
            value={newContact}
            onChange={(e) => setNewContact(e.target.value)}
            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white text-slate-900 focus:outline-none focus:border-emerald-500 placeholder-slate-400"
          />
          <input
            type="text"
            placeholder="Identified Bottleneck"
            value={newBottleneck}
            onChange={(e) => setNewBottleneck(e.target.value)}
            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white text-slate-900 focus:outline-none focus:border-emerald-500 placeholder-slate-400"
          />
          <input
            type="text"
            placeholder="Est. Value (e.g. $800)"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            className="text-xs p-2.5 rounded-lg border border-slate-200 bg-white text-slate-900 focus:outline-none focus:border-emerald-500 placeholder-slate-400"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
          >
            <span>+ Add Lead</span>
          </button>
        </form>

        {/* Table of Leads */}
        <div className="overflow-x-auto border border-emerald-500/20 rounded-xl bg-white shadow-xs">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100 text-emerald-800 font-semibold border-b border-slate-200 uppercase text-[10px] tracking-wider font-mono">
              <tr>
                <th className="py-3 px-4">Target Company</th>
                <th className="py-3 px-4">Decision Maker</th>
                <th className="py-3 px-4">Bottleneck</th>
                <th className="py-3 px-4">Deal Value</th>
                <th className="py-3 px-4">Status & Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white/70 font-medium">
              {prospects.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900 flex items-center gap-2">
                    <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{p.companyName}</span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-700">
                    <div>{p.decisionMaker}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{p.role}</div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 max-w-xs truncate">
                    {p.bottleneck}
                  </td>
                  <td className="py-3.5 px-4 font-bold text-emerald-700 font-mono">
                    {p.dealValue}
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <div className="flex items-center gap-2">
                      {p.pitchStatus === 'READY_TO_SEND' && (
                        <button
                          onClick={() => handleUpdateStatus(p.id, 'PITCH_SENT')}
                          className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-semibold transition-colors cursor-pointer border border-slate-300"
                        >
                          Mark Pitch Sent
                        </button>
                      )}
                      {p.pitchStatus === 'PITCH_SENT' && (
                        <button
                          onClick={() => handleUpdateStatus(p.id, 'REPLIED')}
                          className="px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-[11px] font-semibold transition-colors cursor-pointer border border-emerald-500/30"
                        >
                          Client Replied
                        </button>
                      )}
                      {p.pitchStatus === 'REPLIED' && (
                        <button
                          onClick={() => handleUpdateStatus(p.id, 'DEAL_CLOSED')}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition-colors cursor-pointer shadow-xs"
                        >
                          Close Deal 🎉
                        </button>
                      )}
                      {p.pitchStatus === 'DEAL_CLOSED' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Contract Won
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SOW Modal */}
      {showSOWModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4">
          <div className="quantum-glass bg-white/95 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-xl border border-emerald-500/30">
            <div className="flex items-center justify-between pb-4 border-b border-emerald-500/20">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                <h3 className="text-lg font-bold text-slate-900 font-mono">
                  Direct Client Statement of Work (SOW)
                </h3>
              </div>
              <button
                onClick={() => setShowSOWModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              This ready-to-sign agreement embeds your Skill Hunter verified badge ID, official verification credentials, and clear project milestones to protect both you and the client.
            </p>

            <div className="bg-slate-50 text-slate-800 p-4 rounded-xl text-xs font-mono whitespace-pre-wrap leading-relaxed max-h-72 overflow-y-auto border border-slate-200 shadow-xs">
{`================================================
STATEMENT OF WORK (SOW) & CLIENT ENGAGEMENT PROPOSAL
================================================
Provider: ${user.fullName}
Verified Credential: Skill Hunter ${badge?.badgeTier || 'ADVANCED'} (${user.primarySkill})
Certificate ID: ${badge?.certificateId || 'SH-2026-CERT98'}
Verification Seal: Certified by Ski

DELIVERABLE TIER: ${monetizationData?.packages?.[selectedTierIndex]?.title || 'Custom Execution Sprint'}
ESTIMATED FEE: ${monetizationData?.packages?.[selectedTierIndex]?.priceRecommendation || '$750'}
TIMELINE: 3 - 5 Business Days Turnaround

SCOPE OF WORK:
1. Complete diagnostic audit of client workflow and bottleneck.
2. Direct execution and implementation of ${user.primarySkill} solution.
3. Delivery of documented, production-ready artifact with zero downtime.
4. 14 days of post-deployment support and verification handover.

PAYMENT TERMS:
50% upon kickoff milestone, 50% upon successful artifact delivery.`}
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 font-mono">
              <button
                onClick={() => setShowSOWModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={handleCopySOW}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {copiedSOW ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSOW ? 'Copied SOW Text!' : 'Copy SOW Agreement'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
