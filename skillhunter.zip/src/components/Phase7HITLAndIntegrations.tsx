import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Calendar, 
  Table2, 
  MessageSquare, 
  Send, 
  ShieldCheck, 
  Video, 
  Clock, 
  Sparkles, 
  ExternalLink, 
  ChevronRight, 
  Phone, 
  Check, 
  Building, 
  BellRing, 
  ArrowRight, 
  RotateCcw, 
  Zap,
  Globe2
} from 'lucide-react';
import { Opportunity, UserProfile, GradingResult, ApplicationRecord, WhatsAppAlert } from '../types';
import { scheduleCalendarInterview, logSheetsMilestone, triggerWhatsAppAlert } from '../services/api';

interface Phase7HITLAndIntegrationsProps {
  selectedOpportunities: Opportunity[];
  user: UserProfile;
  badge: GradingResult | null;
  onResetWorkflow: () => void;
  onOpenInterviewPrep?: () => void;
  onLaunchSellingEngine?: () => void;
}

export const Phase7HITLAndIntegrations: React.FC<Phase7HITLAndIntegrationsProps> = ({
  selectedOpportunities,
  user,
  badge,
  onResetWorkflow,
  onOpenInterviewPrep,
  onLaunchSellingEngine,
}) => {
  const [applications, setApplications] = useState<ApplicationRecord[]>(() =>
    selectedOpportunities.map((opp) => {
      const isAiNative = user.archetype === 'AI_NATIVE_BUILDER';
      const pitch = isAiNative
        ? `As an autonomous builder with a verified ${badge?.badgeTier || 'Advanced'} Skill Hunter Certification (Score: ${badge?.overallScore || 98}/100, verified under proctored evaluation standards), I bring confirmed execution capability to ${opp.company}. My structured workflows and tested deliverables ensure immediate organizational impact.`
        : `As a verified ${badge?.badgeTier || 'Gold'} Certified ${user.primarySkill} specialist (Score: ${badge?.overallScore || 95}/100, verified under proctored evaluation standards), I bring immediate execution capability to ${opp.company}. My structured upskilling and verified domain projects bridge my timeline with proven, high-ROI results.`;

      return {
        id: `app-${opp.id}`,
        userId: user.id,
        opportunityId: opp.id,
        opportunity: opp,
        status: 'PENDING_APPROVAL',
        customPitch: pitch,
        tailoredResumeSnapshotId: 'res-v5-01',
        whatsappAlertSent: false,
      };
    })
  );

  const [activeTab, setActiveTab] = useState<'HITL' | 'CALENDAR' | 'SHEETS' | 'WHATSAPP'>('HITL');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasApprovedAll, setHasApprovedAll] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState(user.phone || '+1 (555) 782-4190');

  const [alerts, setAlerts] = useState<WhatsAppAlert[]>([
    {
      id: 'wa-init',
      timestamp: 'Just now',
      recipientPhone: phoneNumber,
      type: 'BADGE_VERIFIED',
      message: `🎉 *Skill Hunter Alert:* Welcome ${user.fullName.split(' ')[0]}! Your verified *${badge?.badgeTier || 'ADVANCED'} Badge* in ${user.primarySkill} has been certified (Score: ${badge?.overallScore || 95}/100). Ready for multi-role submission!`,
      status: 'READ',
    },
  ]);

  const [calendarEvents, setCalendarEvents] = useState<
    Array<{
      title: string;
      interviewerName: string;
      scheduledIso: string;
      googleMeetUrl: string;
    }>
  >([]);

  const handleApproveSingle = async (appId: string) => {
    setApplications((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status: 'SUBMITTED' } : a))
    );

    const app = applications.find((a) => a.id === appId);
    if (!app) return;

    await logSheetsMilestone([app], user);

    const wa = await triggerWhatsAppAlert({
      recipientPhone: phoneNumber,
      messageType: 'APPLICATION_SUBMITTED',
      companyName: app.opportunity.company,
      roleTitle: app.opportunity.title,
    });
    if (wa.alert) {
      setAlerts((prev) => [wa.alert, ...prev]);
    }
  };

  const handleApproveAndDispatchAll = async () => {
    setIsSubmitting(true);

    await logSheetsMilestone(applications, user);

    setApplications((prev) =>
      prev.map((a) => ({
        ...a,
        status: 'SUBMITTED',
      }))
    );
    setHasApprovedAll(true);

    const targetOpp = applications[0]?.opportunity || selectedOpportunities[0];
    const cal = await scheduleCalendarInterview(targetOpp, user);

    setCalendarEvents([
      {
        title: `Technical Screening: ${targetOpp?.title || 'Senior Specialist'} at ${targetOpp?.company || 'Partner Enterprise'}`,
        interviewerName: 'Sarah Jenkins (VP of Talent)',
        scheduledIso: new Date(Date.now() + 86400000).toISOString(),
        googleMeetUrl: cal.calendarEvent?.googleMeetUrl || 'https://meet.google.com/shk-9821-cal',
      },
    ]);

    setApplications((prev) =>
      prev.map((a, i) =>
        i === 0
          ? {
              ...a,
              status: 'INTERVIEWING',
              recruiterNotes: 'Verified badge score & test artifact thoroughly vetted. Scheduled initial chat.',
            }
          : a
      )
    );

    const wa = await triggerWhatsAppAlert({
      recipientPhone: phoneNumber,
      messageType: 'INTERVIEW_INVITE',
      companyName: applications[0]?.opportunity.company || 'Target Partner',
      roleTitle: applications[0]?.opportunity.title || 'Specialist',
      meetUrl: cal.googleMeetUrl,
      interviewTime: 'Tomorrow at 2:00 PM EST',
    });

    if (wa.alert) {
      setAlerts((prev) => [wa.alert, ...prev]);
    }

    setIsSubmitting(false);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-slate-800">
      {/* 2050 Quantum Frosted Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-mono font-semibold mb-3 border border-emerald-500/30 shadow-xs">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Step 7 of 9: 2050 Human-in-the-Loop & Connected Automations</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight sm:text-4xl">
          Review, Authorize & Synchronize
        </h1>
        <p className="mt-2 text-sm text-slate-600">
          Nothing goes out without your sign-off. Review your tailored applications, schedule interviews, and monitor live updates.
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-emerald-500/20 pb-3">
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'HITL', label: 'Human-in-the-Loop Gate', icon: ShieldCheck, badge: `${applications.length} Drafts` },
            { id: 'CALENDAR', label: 'Google Calendar', icon: Calendar, badge: `${calendarEvents.length} Scheduled` },
            { id: 'SHEETS', label: 'Sheets Tracker', icon: Table2, badge: 'Live Sync' },
            { id: 'WHATSAPP', label: 'WhatsApp Suite', icon: MessageSquare, badge: `${alerts.length} Alerts` },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-200'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-emerald-600'}`} />
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                    isActive ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {tab.badge}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenInterviewPrep && (
            <button
              onClick={onOpenInterviewPrep}
              className="px-3.5 py-2 rounded-xl bg-white text-emerald-700 border border-emerald-500/30 hover:bg-emerald-50 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs font-mono"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Interview Coach</span>
            </button>
          )}

          {onLaunchSellingEngine && (
            <button
              onClick={onLaunchSellingEngine}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs font-mono"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Sell Skills Directly</span>
            </button>
          )}

          <button
            onClick={onResetWorkflow}
            className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium px-2 py-1.5 cursor-pointer font-mono"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restart</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Human-in-the-Loop (HITL) Gate */}
      {activeTab === 'HITL' && (
        <div className="space-y-6">
          {/* Master Dispatch Card */}
          <div className="quantum-glass rounded-2xl p-6 shadow-xs border border-emerald-500/30 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider font-mono">
                  YOUR-EYES-ONLY SAFETY CHECK
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-500/40">
                  Zero Spam Guarantee
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                {hasApprovedAll
                  ? 'All Applications Successfully Dispatched!'
                  : `Review & Authorize ${applications.length} Multi-Role Applications`}
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-xl">
                Every application incorporates your certified {badge?.badgeTier || 'ADVANCED'} badge ({badge?.overallScore || 95}/100) and customized rationale. No materials are submitted without your explicit consent.
              </p>
            </div>

            {!hasApprovedAll ? (
              <button
                onClick={handleApproveAndDispatchAll}
                disabled={isSubmitting}
                className="px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 shadow-md cursor-pointer whitespace-nowrap font-mono"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Approving & Sending...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve & Send All ({applications.length})</span>
                  </>
                )}
              </button>
            ) : (
              <div className="flex flex-wrap items-center gap-2 font-mono">
                <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1.5 mr-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Dispatched with Verified Seal
                </span>
                {onLaunchSellingEngine && (
                  <button
                    onClick={onLaunchSellingEngine}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Sell Skills (Phase 9)</span>
                  </button>
                )}
                {onOpenInterviewPrep && (
                  <button
                    onClick={onOpenInterviewPrep}
                    className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer border border-slate-200"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Coach Ski (Phase 8)</span>
                  </button>
                )}
                <button
                  onClick={() => setActiveTab('CALENDAR')}
                  className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer border border-slate-200"
                >
                  <span>View Calendar</span>
                  <ArrowRight className="w-3.5 h-3.5 text-emerald-600" />
                </button>
              </div>
            )}
          </div>

          {/* Applications Draft List */}
          <div className="space-y-4">
            {applications.map((app) => {
              const isSubmitted = app.status === 'SUBMITTED' || app.status === 'INTERVIEWING';
              return (
                <div
                  key={app.id}
                  className={`p-6 rounded-2xl border transition-all quantum-glass ${
                    app.status === 'INTERVIEWING'
                      ? 'border-emerald-500 shadow-md'
                      : isSubmitted
                      ? 'border-emerald-500/40'
                      : 'border-slate-200 hover:border-emerald-500/40'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h4 className="text-base font-bold text-slate-900">
                          {app.opportunity.title}
                        </h4>
                        <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 font-mono">
                          {app.opportunity.company}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full font-mono ${
                            app.status === 'INTERVIEWING'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-500/50'
                              : isSubmitted
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-500/30'
                              : 'bg-slate-100 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {app.status === 'INTERVIEWING' ? '⚡ INTERVIEW SCHEDULED' : app.status}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mb-3 font-mono">
                        <span>Scope: {app.opportunity.geographicScope}</span>
                        <span>•</span>
                        <span>{app.opportunity.salaryRange}</span>
                        <span>•</span>
                        <span className="text-emerald-700 font-semibold">
                          Match: {app.opportunity.matchScore}%
                        </span>
                      </div>

                      {/* Custom Pitch Draft */}
                      <div className="bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-500/20 text-xs">
                        <span className="font-bold text-emerald-800 block mb-1 text-[11px] font-mono">
                          Tailored Pitch & Verified Evidence:
                        </span>
                        <p className="text-slate-700 leading-relaxed italic font-sans">
                          &ldquo;{app.customPitch}&rdquo;
                        </p>
                      </div>

                      {/* Recruiter Notes (if interviewing) */}
                      {app.recruiterNotes && (
                        <div className="mt-3 p-3 bg-emerald-100/70 rounded-xl border border-emerald-500/30 text-xs text-emerald-900 font-mono">
                          <strong>Recruiter Feedback:</strong> {app.recruiterNotes}
                        </div>
                      )}
                    </div>

                    {/* Action Button */}
                    <div className="shrink-0 flex items-center gap-2">
                      {!isSubmitted ? (
                        <button
                          onClick={() => handleApproveSingle(app.id)}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer shadow-xs font-mono"
                        >
                          Approve Draft
                        </button>
                      ) : (
                        <div className="text-right font-mono">
                          <span className="text-xs font-semibold text-emerald-700 flex items-center justify-end gap-1">
                            <Check className="w-3.5 h-3.5" />
                            Approved & Sent
                          </span>
                          <span className="text-[10px] text-slate-500">
                            Snapshot: {app.tailoredResumeSnapshotId}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Google Calendar Integration View */}
      {activeTab === 'CALENDAR' && (
        <div className="quantum-glass rounded-2xl p-6 sm:p-8 border border-emerald-500/30 shadow-xs space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-500/20 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-500/30 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-emerald-700" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 font-mono">
                  Google Calendar Automated Scheduling
                </h3>
                <p className="text-xs text-slate-600 font-mono">
                  Synced Account: <span className="text-emerald-700">{user.email}</span>
                </p>
              </div>
            </div>

            <span className="text-xs font-mono bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full border border-emerald-500/40 font-semibold">
              Live Two-Way Sync Active
            </span>
          </div>

          {calendarEvents.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <Calendar className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="text-sm font-semibold text-slate-800">
                No interviews scheduled yet
              </p>
              <p className="text-xs text-slate-600 max-w-sm mx-auto">
                Approve your application drafts in the HITL Gate. Once recruiters review your verified proctored badge, interview slots schedule here automatically.
              </p>
              <button
                onClick={() => setActiveTab('HITL')}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer font-mono shadow-xs"
              >
                Go to HITL Gate & Dispatch
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {calendarEvents.map((evt, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-xl border border-emerald-500/30 bg-white/90 space-y-4 shadow-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider font-mono">
                        Confirmed Calendar Booking
                      </span>
                      <h4 className="text-base font-bold text-slate-900 mt-0.5">
                        {evt.title}
                      </h4>
                      <p className="text-xs text-slate-600 mt-1 flex items-center gap-2 font-mono">
                        <Clock className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Tomorrow at 2:00 PM EST (45 mins)</span>
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 font-mono">
                      {onOpenInterviewPrep && (
                        <button
                          onClick={onOpenInterviewPrep}
                          className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-emerald-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-emerald-500/30"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                          <span>AI Interview Coach</span>
                        </button>
                      )}
                      <a
                        href={evt.googleMeetUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        <Video className="w-3.5 h-3.5" />
                        <span>Join Google Meet</span>
                      </a>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-50/70 rounded-lg border border-emerald-500/20 text-xs flex flex-wrap items-center justify-between gap-2 font-mono text-slate-800">
                    <div>
                      <span className="text-slate-500">Host / Recruiter:</span>{' '}
                      <strong className="text-slate-900">{evt.interviewerName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Google Meet URL:</span>{' '}
                      <span className="text-emerald-700 underline">{evt.googleMeetUrl}</span>
                    </div>
                    <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-100 px-2 py-0.5 rounded border border-emerald-500/30">
                      Event Added to G-Calendar
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Google Sheets Live Application Tracker */}
      {activeTab === 'SHEETS' && (
        <div className="quantum-glass rounded-2xl border border-emerald-500/30 shadow-xs overflow-hidden">
          <div className="p-6 border-b border-emerald-500/20 bg-white/80 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-500/30 flex items-center justify-center">
                <Table2 className="w-5 h-5 text-emerald-700" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 font-mono">
                  Google Sheets Real-Time Application Tracker
                </h3>
                <p className="text-xs text-slate-600 font-mono">
                  File: <span className="text-emerald-700">Skill Hunter Tracker — {user.fullName}.gsheet</span>
                </p>
              </div>
            </div>

            <span className="text-xs font-mono bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full font-semibold border border-emerald-500/30">
              Live Spreadsheet Sync Active
            </span>
          </div>

          {/* Spreadsheet Table Simulator */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 border-b border-slate-200 font-mono">
                  <th className="py-2.5 px-4">Row</th>
                  <th className="py-2.5 px-4">Company</th>
                  <th className="py-2.5 px-4">Target Role</th>
                  <th className="py-2.5 px-4">Geographic Scope</th>
                  <th className="py-2.5 px-4">Verified Badge Tier</th>
                  <th className="py-2.5 px-4">Compensation Target</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4">Recruiter Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white/70">
                {applications.map((app, idx) => (
                  <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-500">{idx + 2}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{app.opportunity.company}</td>
                    <td className="py-3 px-4 text-slate-800">{app.opportunity.title}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{app.opportunity.geographicScope}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-500/30 font-mono font-bold text-[10px]">
                        {badge?.badgeTier || 'ADVANCED'} ({badge?.overallScore || 95}%)
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-emerald-700 font-semibold">{app.opportunity.salaryRange}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          app.status === 'INTERVIEWING'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-500/40'
                            : app.status === 'SUBMITTED'
                            ? 'bg-slate-100 text-emerald-800 border border-emerald-500/30'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 italic">
                      {app.status === 'INTERVIEWING'
                        ? 'Google Meet Scheduled'
                        : app.status === 'SUBMITTED'
                        ? 'Under Senior Review'
                        : 'Awaiting Candidate Signoff'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: WhatsApp Notification Alerts Simulator */}
      {activeTab === 'WHATSAPP' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Phone Configuration & Triggers */}
          <div className="lg:col-span-5 space-y-6">
            <div className="quantum-glass rounded-2xl p-6 border border-emerald-500/30 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 border border-emerald-500/30 text-emerald-700 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 font-mono">
                    WhatsApp Automated Alert Suite
                  </h3>
                  <p className="text-[11px] text-emerald-700 font-mono font-medium">
                    Direct SMS/WhatsApp Dispatch
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Candidates receive instant push notifications to their mobile phone for interview requests, status changes, and recruiter views so you never miss an urgent invitation.
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-mono">
                  Candidate WhatsApp Phone Number:
                </label>
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 text-slate-900 rounded-xl focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 focus:outline-hidden font-mono"
                />
              </div>

              {/* Alert Triggers */}
              <div className="space-y-2 pt-2 border-t border-emerald-500/20">
                <span className="text-xs font-bold text-slate-800 block font-mono">
                  Simulate Live WhatsApp Alerts:
                </span>
                <div className="grid grid-cols-1 gap-2 font-mono">
                  <button
                    onClick={async () => {
                      const res = await triggerWhatsAppAlert({
                        recipientPhone: phoneNumber,
                        messageType: 'INTERVIEW_INVITE',
                        companyName: 'Apex Midwest Retailers',
                        roleTitle: 'Senior Growth & Paid Acquisition Lead',
                        meetUrl: 'https://meet.google.com/shk-9821',
                        interviewTime: 'Tomorrow at 2:00 PM EST',
                      });
                      if (res.alert) setAlerts((prev) => [res.alert, ...prev]);
                    }}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-500/40 bg-white text-left text-xs font-medium text-slate-800 flex items-center justify-between cursor-pointer shadow-xs"
                  >
                    <span>⚡ Send Simulated Interview Invite</span>
                    <BellRing className="w-3.5 h-3.5 text-emerald-600" />
                  </button>

                  <button
                    onClick={async () => {
                      const res = await triggerWhatsAppAlert({
                        recipientPhone: phoneNumber,
                        messageType: 'APPLICATION_SUBMITTED',
                        companyName: 'NovaHealth Care Tech',
                        roleTitle: 'Performance Marketing Strategist',
                      });
                      if (res.alert) setAlerts((prev) => [res.alert, ...prev]);
                    }}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-500/40 bg-white text-left text-xs font-medium text-slate-800 flex items-center justify-between cursor-pointer shadow-xs"
                  >
                    <span>✅ Send Submission Confirmation</span>
                    <BellRing className="w-3.5 h-3.5 text-emerald-600" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Smartphone Mockup Simulator */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="w-full max-w-sm rounded-[36px] bg-white p-3 shadow-2xl border-4 border-emerald-500/30">
              {/* Phone Screen */}
              <div className="rounded-[28px] bg-slate-50 overflow-hidden flex flex-col h-[540px] border border-slate-200">
                {/* Status Bar */}
                <div className="bg-slate-100 text-slate-700 px-6 py-2 flex items-center justify-between text-[10px] font-mono border-b border-slate-200">
                  <span>9:41 AM</span>
                  <div className="flex items-center gap-1.5">
                    <span>5G</span>
                    <span>100%</span>
                  </div>
                </div>

                {/* WhatsApp Chat Header */}
                <div className="bg-emerald-600 text-white px-4 py-3 flex items-center justify-between border-b border-emerald-700">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center font-bold text-xs">
                      SH
                    </div>
                    <div>
                      <h4 className="text-xs font-bold leading-none">Skill Hunter Bot</h4>
                      <span className="text-[10px] text-emerald-100 font-mono">Verified Career Channel</span>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-white" />
                </div>

                {/* Messages Stream */}
                <div className="flex-1 bg-emerald-50/30 p-4 overflow-y-auto space-y-3">
                  <div className="text-center">
                    <span className="text-[9px] bg-white text-slate-600 px-2 py-0.5 rounded font-mono border border-slate-200 shadow-2xs">
                      TODAY
                    </span>
                  </div>

                  {alerts.map((alt) => (
                    <div
                      key={alt.id}
                      className="bg-white text-slate-800 rounded-xl rounded-tl-none p-3 text-xs shadow-xs space-y-2 max-w-[90%] border border-emerald-500/20"
                    >
                      <div className="whitespace-pre-line text-[11px] leading-relaxed">
                        {alt.message}
                      </div>
                      <div className="flex items-center justify-end gap-1 text-[9px] text-slate-400 font-mono">
                        <span>{alt.timestamp}</span>
                        <span>✓✓</span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Input Bar */}
                <div className="bg-white p-2 border-t border-slate-200 flex items-center gap-2">
                  <div className="flex-1 bg-slate-100 rounded-full px-4 py-1.5 text-[11px] text-slate-500">
                    Message Skill Hunter Bot...
                  </div>
                  <div className="w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center text-white">
                    <Send className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
