import React, { useState } from 'react';
import { 
  Compass, 
  MapPin, 
  Globe2, 
  Building2, 
  DollarSign, 
  CheckSquare, 
  Square, 
  Filter, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Heart,
  Briefcase,
  Zap,
  GraduationCap,
  Bot,
  TrendingUp,
  CheckCircle2,
  Award,
  Video,
  Layers,
  Send
} from 'lucide-react';
import { GeographicScope, Opportunity, UserProfile, GradingResult } from '../types';
import { MOCK_OPPORTUNITIES } from '../data/mockData';
import { UniversalJobBoardConnectorsModal } from './UniversalJobBoardConnectorsModal';

interface Phase6OpportunityDiscoveryProps {
  user: UserProfile;
  badge: GradingResult | null;
  onProceedToHITL: (selectedOpportunities: Opportunity[]) => void;
  onLaunchSellingEngine?: () => void;
  onOpenInterviewPrep?: () => void;
}

export const Phase6OpportunityDiscovery: React.FC<Phase6OpportunityDiscoveryProps> = ({
  user,
  badge,
  onProceedToHITL,
  onLaunchSellingEngine,
  onOpenInterviewPrep,
}) => {
  const [workModelFilter, setWorkModelFilter] = useState<'ALL' | 'Remote' | 'Hybrid' | 'On-site'>('ALL');
  const [activeScope, setActiveScope] = useState<'ALL' | GeographicScope>('ALL');
  const [returnshipOnly, setReturnshipOnly] = useState(false);
  const [aiNativeOnly, setAiNativeOnly] = useState(user.archetype === 'AI_NATIVE_BUILDER');
  const [noDegreeOnly, setNoDegreeOnly] = useState(false);
  const [selectedOppIds, setSelectedOppIds] = useState<string[]>(
    MOCK_OPPORTUNITIES.map((o) => o.id)
  );
  const [appliedOppIds, setAppliedOppIds] = useState<string[]>([]);
  const [isConnectorsModalOpen, setIsConnectorsModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const filteredOpportunities = MOCK_OPPORTUNITIES.filter((opp) => {
    if (workModelFilter !== 'ALL') {
      if (opp.workModel !== workModelFilter) return false;
    }
    if (activeScope !== 'ALL' && opp.geographicScope !== activeScope) return false;
    if (returnshipOnly && !opp.returnshipFriendly) return false;
    if (aiNativeOnly && !opp.aiNativeFriendly) return false;
    if (noDegreeOnly && !opp.noDegreeRequired) return false;
    return true;
  });

  const toggleSelect = (id: string) => {
    setSelectedOppIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    setSelectedOppIds(filteredOpportunities.map((o) => o.id));
  };

  const deselectAll = () => {
    setSelectedOppIds([]);
  };

  const handleQuickApply = (opp: Opportunity) => {
    if (appliedOppIds.includes(opp.id)) {
      setAppliedOppIds((prev) => prev.filter((id) => id !== opp.id));
      setToastMessage(`Application withdrawn for ${opp.title}.`);
    } else {
      setAppliedOppIds((prev) => [...prev, opp.id]);
      setToastMessage(`Applied to ${opp.title} at ${opp.company} with your verified quantum profile!`);
    }
    setTimeout(() => setToastMessage(null), 4000);
  };

  const selectedList = MOCK_OPPORTUNITIES.filter((o) => selectedOppIds.includes(o.id));

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 text-slate-800">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-white/95 text-slate-800 px-5 py-3 rounded-xl shadow-md border border-emerald-500/40 text-xs font-semibold flex items-center gap-2.5 animate-in slide-in-from-top duration-200 backdrop-blur-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 2050 Quantum Frosted Header */}
      <div className="text-center max-w-3xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-mono font-semibold mb-3 border border-emerald-500/30 shadow-xs">
          <Compass className="w-3.5 h-3.5 text-emerald-600" />
          <span>Step 6 of 9: 2050 Opportunity Discovery & Neural Job Matching</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight sm:text-4xl">
          Find Jobs Matched to Your Verified Skills
        </h1>
        <p className="mt-2 text-base text-slate-600">
          Roles where employers hire for what you can do, not where you went to school.
        </p>

        {/* Universal Job Board Connectors Toolbar button */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => setIsConnectorsModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-emerald-700 border border-emerald-500/40 text-xs font-bold transition-all flex items-center gap-2 shadow-xs cursor-pointer font-mono"
          >
            <Globe2 className="w-4 h-4 text-emerald-600" />
            <span>Universal Job Board Connectors (6 Linked)</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </button>

          {onLaunchSellingEngine && (
            <button
              type="button"
              onClick={onLaunchSellingEngine}
              className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer font-mono shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Direct Skill Selling Alternative</span>
            </button>
          )}
        </div>
      </div>

      {/* Career Protection Shield Banner */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold">
                Verification Guarantee
              </span>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Career Protection Shield
              </h2>
            </div>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed font-normal">
            Your verified scores and work portfolio are locked in. Employers see what you can actually do — completely free from resume bias, career gaps, or keyword screening filters.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-2 text-xs font-mono">
            <span className="px-3 py-1 rounded-full bg-slate-100/90 border border-slate-200 text-slate-700">
              ✓ 100% Bias-Free Screening
            </span>
            <span className="px-3 py-1 rounded-full bg-slate-100/90 border border-slate-200 text-slate-700">
              ✓ Verified Merit Guarantee
            </span>
            <span className="px-3 py-1 rounded-full bg-slate-100/90 border border-slate-200 text-slate-700">
              ✓ Zero-Ramp Day 1 Productivity
            </span>
          </div>
        </div>
      </div>

      {/* Filter by Work Model */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-5 border border-emerald-500/30 shadow-xs mb-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-slate-700 block mb-2 font-mono uppercase">
              Filter by Work Model:
            </span>
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'ALL', label: 'All Roles' },
                { id: 'Remote', label: 'Remote' },
                { id: 'Hybrid', label: 'Hybrid' },
                { id: 'On-site', label: 'In-Person' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setWorkModelFilter(filter.id as any)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer font-mono ${
                    workModelFilter === filter.id
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-emerald-500/40 shadow-xs'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={selectedOppIds.length === filteredOpportunities.length ? deselectAll : selectAll}
              className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold cursor-pointer underline font-mono"
            >
              {selectedOppIds.length === filteredOpportunities.length ? 'Deselect All' : 'Select All Filtered'}
            </button>
          </div>
        </div>

        {/* Additional Merit Flags */}
        <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-emerald-500/15 text-xs font-mono">
          <span className="text-slate-500 font-medium mr-1">Preferences:</span>

          <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 cursor-pointer select-none hover:border-emerald-500/40 shadow-xs">
            <input
              type="checkbox"
              checked={aiNativeOnly}
              onChange={(e) => setAiNativeOnly(e.target.checked)}
              className="rounded accent-emerald-600 cursor-pointer"
            />
            <span className="flex items-center gap-1 font-semibold text-emerald-700">
              <Zap className="w-3 h-3 text-emerald-600 fill-emerald-600" />
              AI-Native / Self-Taught Welcomed
            </span>
          </label>

          <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 cursor-pointer select-none hover:border-emerald-500/40 shadow-xs">
            <input
              type="checkbox"
              checked={noDegreeOnly}
              onChange={(e) => setNoDegreeOnly(e.target.checked)}
              className="rounded accent-emerald-600 cursor-pointer"
            />
            <span className="flex items-center gap-1 font-semibold text-emerald-700">
              <GraduationCap className="w-3 h-3 text-emerald-600" />
              No Degree Required
            </span>
          </label>

          <label className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 cursor-pointer select-none hover:border-emerald-500/40 shadow-xs">
            <input
              type="checkbox"
              checked={returnshipOnly}
              onChange={(e) => setReturnshipOnly(e.target.checked)}
              className="rounded accent-emerald-600 cursor-pointer"
            />
            <span className="flex items-center gap-1 font-semibold text-emerald-700">
              <Heart className="w-3 h-3 text-emerald-600 fill-emerald-600" />
              Returnship Programs
            </span>
          </label>
        </div>
      </div>

      {/* Matched Opportunities List */}
      <div className="space-y-4 mb-8">
        <h3 className="text-sm font-bold text-emerald-700 uppercase tracking-wider font-mono">
          Matched Opportunities ({filteredOpportunities.length})
        </h3>

        {filteredOpportunities.map((opp, idx) => {
          const isSelected = selectedOppIds.includes(opp.id);
          const isApplied = appliedOppIds.includes(opp.id);

          return (
            <div
              key={opp.id}
              className={`p-6 rounded-2xl border transition-all quantum-glass bg-white/80 backdrop-blur-xl shadow-xs ${
                isSelected
                  ? 'border-emerald-500 shadow-xs ring-1 ring-emerald-500/20'
                  : 'border-slate-200 hover:border-emerald-500/40'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex items-start gap-3.5 flex-1">
                  <button
                    type="button"
                    onClick={() => toggleSelect(opp.id)}
                    className="mt-1 text-emerald-600 shrink-0 cursor-pointer p-0.5 rounded hover:bg-slate-100 transition-colors"
                    title={isSelected ? 'Deselect for batch application' : 'Select for batch application'}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 fill-emerald-600 text-white" />
                    ) : (
                      <Square className="w-5 h-5 text-slate-400" />
                    )}
                  </button>

                  <div className="space-y-2 flex-1">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold font-mono text-emerald-700">
                          #{idx + 1}
                        </span>
                        <h4 className="text-base font-bold text-slate-900">
                          {opp.title}
                        </h4>
                        <span className="text-xs text-slate-500 font-semibold font-mono">
                          — {opp.company}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs text-slate-600 leading-relaxed">
                      <strong className="text-emerald-700 font-semibold font-mono">What you'll do: </strong>
                      {opp.description}
                    </div>

                    {/* Metadata chips */}
                    <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-xs">
                      <span className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-emerald-600" />
                        <span>{opp.location} ({opp.workModel})</span>
                      </span>

                      <span className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                        <DollarSign className="w-3 h-3 text-emerald-600" />
                        <span>{opp.salaryRange}</span>
                      </span>

                      <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-500/30 font-bold">
                        {opp.matchScore}% Match
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right side CTA: Quick Apply with Verified Profile */}
                <div className="flex flex-col sm:flex-row md:flex-col items-end gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleQuickApply(opp)}
                    className={`w-full sm:w-auto px-4 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer font-mono shadow-xs ${
                      isApplied
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-500/40'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {isApplied ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Applied (Verified)</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Apply with Ski Profile</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Batch Application Proceed Bar */}
      <div className="quantum-glass bg-white/75 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/30 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold">
            Step 6 of 9 Review
          </h4>
          <p className="text-sm text-slate-800 font-medium">
            {selectedList.length} opportunities selected for executive review.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onProceedToHITL(selectedList)}
          className="py-3 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition-all flex items-center gap-2 shadow-xs cursor-pointer font-mono"
        >
          <span>Proceed to Step 7: Review & Connect</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Universal Job Board Connectors Modal */}
      <UniversalJobBoardConnectorsModal
        isOpen={isConnectorsModalOpen}
        onClose={() => setIsConnectorsModalOpen(false)}
        verifiedBadge={badge}
      />
    </div>
  );
};
