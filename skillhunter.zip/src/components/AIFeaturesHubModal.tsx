import React, { useState } from 'react';
import { 
  X, 
  Cpu, 
  Sparkles, 
  Bot, 
  FileText, 
  ShieldCheck, 
  Compass, 
  DollarSign, 
  CheckCircle2, 
  Zap, 
  Activity,
  Sliders
} from 'lucide-react';

interface AIFeaturesHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIFeaturesHubModal: React.FC<AIFeaturesHubModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [agents, setAgents] = useState([
    {
      id: 'ski-core',
      name: 'Ski Neural Career Orchestrator',
      description: 'Conversational assessment, empathy-driven skill discovery and voice synthesis.',
      model: 'Gemini 2.5 Flash',
      status: 'ONLINE',
      latency: '240ms',
      activeTask: 'Standing by for user voice/chat input',
      icon: Bot,
    },
    {
      id: 'proctor-vision',
      name: 'Anti-Cheat Proctoring Sentry',
      description: 'Tab blur watchdog, singular face lock, gaze divergence & acoustic monitoring.',
      model: 'Computer Vision & Audio Analyzer',
      status: 'READY',
      latency: '42ms',
      activeTask: 'Continuous background telemetry locked',
      icon: ShieldCheck,
    },
    {
      id: 'rubric-evaluator',
      name: 'Tri-Tier Assessment Grader',
      description: 'Semantic rubric evaluation across technical accuracy, problem solving & verbal defense.',
      model: 'Gemini 2.5 Flash Structured Schema',
      status: 'STANDBY',
      latency: '310ms',
      activeTask: 'Rubric compiled for 3 specialized tracks',
      icon: Sparkles,
    },
    {
      id: 'resume-transpiler',
      name: 'ATS Merit Resume Transpiler',
      description: 'Transforms legacy CVs, career breaks, and project artifacts into ATS-topping profiles.',
      model: 'Gemini 2.5 Document Generator',
      status: 'ONLINE',
      latency: '410ms',
      activeTask: 'Google Drive & raw document parsing engine',
      icon: FileText,
    },
    {
      id: 'opportunity-radar',
      name: 'Universal Job Board Radar',
      description: 'Autonomous multi-platform crawler synchronizing LinkedIn, Indeed, Greenhouse & Upwork.',
      model: 'Vector Semantic Matching',
      status: 'ACTIVE',
      latency: '180ms',
      activeTask: 'Scoring 90%+ merit alignments',
      icon: Compass,
    },
    {
      id: 'monetization-synthesizer',
      name: 'High-Ticket Proposal Synthesizer',
      description: 'Generates client contract scopes, Google Sheets prospecting columns & outbound pitches.',
      model: 'Gemini 2.5 B2B Copywriter',
      status: 'STANDBY',
      latency: '380ms',
      activeTask: 'Escrow & contract agreements ready',
      icon: DollarSign,
    },
  ]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/35 backdrop-blur-md">
      <div className="quantum-glass bg-white/95 backdrop-blur-2xl border border-emerald-500/30 rounded-2xl w-full max-w-3xl overflow-hidden shadow-xl relative text-slate-800">
        <div className="h-1 w-full bg-gradient-to-r from-transparent via-emerald-500 to-transparent" />

        {/* Modal Header */}
        <div className="p-6 border-b border-slate-200 flex items-center justify-between bg-white/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-500/30 flex items-center justify-center text-emerald-600 shadow-xs">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                  Ski AI Features & Intelligence Hub
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-500/30 uppercase font-semibold">
                  Quantum Core
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Centralized telemetry and background intelligence engines orchestrating your career acceleration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Status Bar */}
          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-500/25 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_#10B981]" />
              <span className="font-semibold text-slate-900">All 6 Autonomous Career Subroutines Operational</span>
            </div>
            <div className="flex items-center gap-4 text-slate-600 font-mono text-[11px]">
              <span>Avg Latency: <strong className="text-emerald-700">220ms</strong></span>
              <span>•</span>
              <span>Model: <strong className="text-slate-800">Gemini 2.5 Resilient Ladder</strong></span>
            </div>
          </div>

          {/* Grid of AI Agents */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {agents.map((agent) => {
              const Icon = agent.icon;
              return (
                <div
                  key={agent.id}
                  className="p-4 rounded-xl bg-white/80 border border-emerald-500/20 hover:border-emerald-500/40 transition-all space-y-2.5 shadow-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-500/30">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900 leading-tight">
                          {agent.name}
                        </div>
                        <div className="text-[10px] font-mono text-emerald-700">
                          {agent.model}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-500/30 font-semibold">
                      {agent.status}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {agent.description}
                  </p>

                  <div className="pt-1 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="truncate max-w-[200px] text-slate-600 font-mono">
                      {agent.activeTask}
                    </span>
                    <span className="text-emerald-700 font-mono font-semibold">
                      {agent.latency}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Privacy & Zero-Retention Guarantee */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="font-semibold text-slate-800">Zero Third-Party Training:</span>
              <span className="text-[11px] ml-1">
                Your submitted files, assessment code, and personal transcripts are never retained or utilized for foundation model retraining.
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-white/90 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
