import React, { useState } from 'react';
import { 
  X, 
  MessageSquare, 
  CheckCircle2, 
  Bell, 
  Smartphone, 
  Send, 
  ShieldCheck, 
  Sparkles,
  Lock
} from 'lucide-react';
import { UserProfile } from '../types';

interface WhatsAppNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
}

export const WhatsAppNotificationModal: React.FC<WhatsAppNotificationModalProps> = ({
  isOpen,
  onClose,
  user,
}) => {
  const [phoneNumber, setPhoneNumber] = useState(user.phone || '+1 (555) 234-8901');
  const [notifyInterviews, setNotifyInterviews] = useState(true);
  const [notifyJobMatches, setNotifyJobMatches] = useState(true);
  const [notifyOfferLetters, setNotifyOfferLetters] = useState(true);
  const [isTestSent, setIsTestSent] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  if (!isOpen) return null;

  const handleSendTestPing = () => {
    setIsTestSent(true);
    setTimeout(() => {
      setIsTestSent(false);
    }, 4000);
  };

  const handleSavePreferences = () => {
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="quantum-glass border border-emerald-500/40 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl relative text-stone-200">
        <div className="h-1 w-full bg-gradient-to-r from-transparent via-emerald-400 to-transparent" />

        {/* Modal Header */}
        <div className="p-6 border-b border-emerald-500/20 flex items-center justify-between bg-stone-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  WhatsApp Career Gateway
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/40 uppercase font-semibold">
                  2050 Mobile
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Direct mobile dispatch for interviews, verified matches & offers
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-2 rounded-lg hover:bg-stone-800/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Phone Number Input */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 uppercase tracking-wider mb-2">
              WhatsApp Mobile Number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-emerald-400">
                <Smartphone className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-emerald-500/30 text-white font-mono text-sm focus:outline-hidden focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-all"
              />
            </div>
            <p className="text-[11px] text-stone-500 mt-1">
              Used strictly for critical career events. Zero marketing, zero spam.
            </p>
          </div>

          {/* Alert Channel Toggles */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider">
              Notification Preferences
            </div>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-stone-900/60 border border-stone-800 hover:border-emerald-500/30 transition-colors cursor-pointer">
              <input
                type="checkbox"
                checked={notifyInterviews}
                onChange={(e) => setNotifyInterviews(e.target.checked)}
                className="mt-1 rounded border-stone-700 text-emerald-500 focus:ring-emerald-400 focus:ring-offset-stone-900"
              />
              <div>
                <div className="text-xs font-bold text-stone-200">
                  Instant Interview Requests
                </div>
                <div className="text-[11px] text-stone-400 leading-relaxed">
                  Direct WhatsApp ping within 60 seconds when a hiring manager requests a live interview.
                </div>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-stone-900/60 border border-stone-800 hover:border-emerald-500/30 transition-colors cursor-pointer">
              <input
                type="checkbox"
                checked={notifyJobMatches}
                onChange={(e) => setNotifyJobMatches(e.target.checked)}
                className="mt-1 rounded border-stone-700 text-emerald-500 focus:ring-emerald-400 focus:ring-offset-stone-900"
              />
              <div>
                <div className="text-xs font-bold text-stone-200">
                  Daily High-Confidence Job Matches (90%+ Match)
                </div>
                <div className="text-[11px] text-stone-400 leading-relaxed">
                  Morning summary of 3 curated roles aligned to your verified badge.
                </div>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-stone-900/60 border border-stone-800 hover:border-emerald-500/30 transition-colors cursor-pointer">
              <input
                type="checkbox"
                checked={notifyOfferLetters}
                onChange={(e) => setNotifyOfferLetters(e.target.checked)}
                className="mt-1 rounded border-stone-700 text-emerald-500 focus:ring-emerald-400 focus:ring-offset-stone-900"
              />
              <div>
                <div className="text-xs font-bold text-stone-200">
                  Contract & Offer Escrow Alerts
                </div>
                <div className="text-[11px] text-stone-400 leading-relaxed">
                  Immediate notification when a verified employer funds an escrow contract or submits an offer.
                </div>
              </div>
            </label>
          </div>

          {/* Test Ping Action */}
          <div className="pt-1">
            <button
              onClick={handleSendTestPing}
              className="w-full py-2 px-3 rounded-xl bg-stone-900 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-950/40 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Test Ping to WhatsApp</span>
            </button>
            {isTestSent && (
              <div className="mt-2 p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-[11px] text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Test ping dispatched: &ldquo;Hello from Ski! Your 2050 Quantum Channel is active.&rdquo;</span>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-emerald-500/20 bg-stone-950/80 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-stone-500">
            <Lock className="w-3.5 h-3.5 text-emerald-500/70" />
            <span>Encrypted E2E</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSavePreferences}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 text-xs font-bold transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isSaved ? 'Saved!' : 'Save & Activate'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
