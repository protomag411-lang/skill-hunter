import React, { useState } from 'react';
import { 
  Award, 
  Sparkles, 
  Compass, 
  Bot,
  Cpu,
  RotateCcw,
  TrendingUp,
  Share2,
  MessageSquare,
  Volume2,
  VolumeX,
  ShieldCheck,
  Zap,
  Layers
} from 'lucide-react';
import { UserProfile, GradingResult } from '../types';

interface NavbarProps {
  currentPhase: number;
  onSelectPhase: (phase: number) => void;
  user: UserProfile;
  badge: GradingResult | null;
  onOpenMCPModal: () => void;
  onResetWorkflow: () => void;
  onOpenForecastModal?: () => void;
  onOpenNetworkSyncModal?: () => void;
  onOpenWhatsAppModal?: () => void;
  onOpenAIFeaturesHub?: () => void;
  isVoiceGuidanceActive?: boolean;
  onToggleVoiceGuidance?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPhase,
  onSelectPhase,
  user,
  badge,
  onOpenMCPModal,
  onResetWorkflow,
  onOpenForecastModal,
  onOpenNetworkSyncModal,
  onOpenWhatsAppModal,
  onOpenAIFeaturesHub,
  isVoiceGuidanceActive = true,
  onToggleVoiceGuidance,
}) => {
  return (
    <header className="sticky top-0 z-40 quantum-glass-nav text-slate-900 border-b border-emerald-500/25 shadow-sm">
      {/* 2050 Quantum Status Ticker Bar */}
      <div className="bg-emerald-50/70 text-slate-700 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-emerald-500/20 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_#10B981]" />
          <span className="font-semibold text-slate-900 tracking-wide">
            Skill Hunter 2050
          </span>
          <span className="text-emerald-500/40">|</span>
          <span className="text-slate-700 font-medium hidden sm:inline">
            Autonomous Career Navigator: <strong className="text-emerald-700 font-semibold">Ski</strong>
          </span>
          <span className="text-slate-400 hidden md:inline">•</span>
          <span className="text-slate-600 hidden md:inline font-mono text-[11px]">
            &ldquo;In the AI Era, a Verified Skill Means You Are Never Out of Work&rdquo;
          </span>
        </div>

        <div className="flex items-center gap-3 text-slate-700">
          {/* 5D Quantum Resonance Live Status */}
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 bg-emerald-100/70 px-2.5 py-0.5 rounded-full border border-emerald-500/30 font-mono font-medium">
            <Zap className="w-3 h-3 text-emerald-600" />
            <span className="hidden sm:inline">5D Quantum Resonance:</span>
            <span>Active</span>
          </div>

          <span className="bg-white text-emerald-800 px-2.5 py-0.5 rounded-md border border-emerald-500/30 text-[11px] font-mono font-semibold shadow-xs">
            {badge ? `Proof: ${badge.badgeTier} (${badge.overallScore}/100)` : 'Readiness: Certified Track'}
          </span>
        </div>
      </div>

      {/* Floating Light Frosted Glass Bar with Vibrant Emerald Accents */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & 2050 Quantum Brand */}
          <div 
            className="flex items-center gap-3 cursor-pointer group" 
            onClick={() => onSelectPhase(1)}
            title="Return to Intake Phase 1"
          >
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-white to-emerald-100 flex items-center justify-center text-emerald-600 border border-emerald-500/30 shadow-xs group-hover:border-emerald-500 group-hover:shadow-[0_0_12px_rgba(16,185,129,0.25)] transition-all">
              <Compass className="w-5 h-5 text-emerald-600 group-hover:rotate-45 transition-transform duration-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-slate-900 tracking-tight">
                  Skill Hunter
                </span>
                <span className="text-[10px] font-mono font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-400/40">
                  2050 Quantum
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-mono hidden md:block">
                Merit-First Placement & Autonomous Multi-Dimensional Growth
              </p>
            </div>
          </div>

          {/* Candidate Snapshot & Quick Actions */}
          <div className="flex items-center gap-2.5">
            {/* Candidate Context Pill */}
            <div className="text-right hidden sm:block mr-1">
              <div className="text-xs font-semibold text-slate-800 flex items-center justify-end gap-1.5">
                <span>{user.fullName}</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-emerald-100/70 text-emerald-800 border border-emerald-500/30">
                  {user.trackName}
                </span>
              </div>
              <p className="text-[11px] text-emerald-700 font-mono truncate max-w-[220px]">
                Target: {user.primarySkill}
              </p>
            </div>

            {/* 4D Forecast Button */}
            {onOpenForecastModal && (
              <button
                type="button"
                onClick={onOpenForecastModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/30 bg-white/80 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 text-xs font-semibold shadow-xs transition-all hover:border-emerald-400"
                title="Skill to Offer Forecast (Salary & Timeline Predictor)"
              >
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden md:inline">4D Forecast</span>
              </button>
            )}

            {/* Network Sync Button */}
            {onOpenNetworkSyncModal && (
              <button
                type="button"
                onClick={onOpenNetworkSyncModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/30 bg-white/80 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 text-xs font-semibold shadow-xs transition-all hover:border-emerald-400"
                title="Professional Network Sync (LinkedIn, GitHub, Indeed)"
              >
                <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden lg:inline">Network Sync</span>
              </button>
            )}

            {/* WhatsApp Gateway Button */}
            {onOpenWhatsAppModal && (
              <button
                type="button"
                onClick={onOpenWhatsAppModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/30 bg-white/80 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 text-xs font-semibold shadow-xs transition-all hover:border-emerald-400"
                title="WhatsApp Direct Career Notifications"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden xl:inline">WhatsApp</span>
              </button>
            )}

            {/* AI Features Hub Button */}
            {onOpenAIFeaturesHub && (
              <button
                type="button"
                onClick={onOpenAIFeaturesHub}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-emerald-500/30 bg-white/80 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 text-xs font-semibold shadow-xs transition-all hover:border-emerald-400"
                title="AI Features Hub: Autonomous Background Subroutines"
              >
                <Cpu className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden md:inline">AI Hub</span>
              </button>
            )}

            {/* Voice Guidance Toggle */}
            {onToggleVoiceGuidance && (
              <button
                type="button"
                onClick={onToggleVoiceGuidance}
                className={`p-2 rounded-xl border text-xs font-semibold transition-all ${
                  isVoiceGuidanceActive
                    ? 'border-emerald-500 bg-emerald-100/70 text-emerald-700 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                    : 'border-slate-200 bg-white/80 text-slate-500 hover:text-slate-800'
                }`}
                title={isVoiceGuidanceActive ? 'Ski Voice Guidance: ON' : 'Ski Voice Guidance: OFF'}
              >
                {isVoiceGuidanceActive ? (
                  <Volume2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-400" />
                )}
              </button>
            )}

            {/* Verified Badge Quick Jump */}
            {badge && (
              <div 
                onClick={() => onSelectPhase(3)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100/80 border border-emerald-500/50 text-emerald-900 text-xs font-semibold shadow-xs cursor-pointer hover:bg-emerald-200/80 transition-colors"
                title="View Verified Assessment Badge"
              >
                <Award className="w-4 h-4 text-emerald-600" />
                <span className="hidden sm:inline">Certified</span>
                <span className="bg-emerald-500 text-white px-1.5 py-0.2 rounded font-mono font-bold text-[11px]">
                  {badge.overallScore}%
                </span>
              </div>
            )}

            {/* Reset / New Intake */}
            <button
              type="button"
              onClick={onResetWorkflow}
              className="p-2 text-slate-500 hover:text-slate-900 rounded-xl hover:bg-emerald-50 transition-colors border border-transparent hover:border-emerald-200"
              title="Reset Intake Workflow"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
