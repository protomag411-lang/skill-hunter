export type ProficiencyLevel = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';
export type VerificationStatus = 'CLAIMED' | 'OBSERVED' | 'ASSESSED' | 'VERIFIED';
export type GeographicScope = 'REGIONAL' | 'NATIONAL' | 'INTERNATIONAL';
export type OpportunityType = 'JOB' | 'FREELANCE' | 'CONTRACT';
export type ApplicationStatus = 'DRAFT' | 'PENDING_APPROVAL' | 'SUBMITTED' | 'INTERVIEWING' | 'SUCCESS';

export type ProfileTrack = 'TECHNICAL' | 'NON_TECHNICAL' | 'MANUAL';

export type CandidateArchetype = 
  | 'CAREER_RETURNER'     // Returning to workforce after career break / caregiving
  | 'EXPERIENCED_BUILDER' // Self-taught practitioner with proven execution
  | 'FRESH_GRADUATE'      // Recent graduate demonstrating verified capability
  | 'CAREER_SWITCHER'     // Transitioning into a new industry
  | 'AI_NATIVE_BUILDER';  // AI-native builder demonstrating modern execution

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  location: string;
  track: ProfileTrack;
  trackName: string;
  archetype: CandidateArchetype;
  careerGapYears: number;
  gapReason: string;
  targetRole: string;
  primarySkill: string;
  preferredScope: GeographicScope;
  workAuthorization: string;
  linkedInUrl?: string;
  portfolioUrl?: string;
  selfTaughtSummary?: string;
}

export interface MCPServerConfig {
  id: string;
  name: string;
  type: 'FILESYSTEM' | 'DATABASE' | 'WORKSPACE' | 'CUSTOM';
  protocolUri: string;
  status: 'CONNECTED' | 'DISCONNECTED' | 'CONNECTING';
  description: string;
  enabled: boolean;
  capabilities: string[];
  latencyMs?: number;
}

export interface AIProviderConfig {
  id: string;
  name: string;
  type: 'GOOGLE_AI_STUDIO' | 'LOCAL_OPEN_WEIGHTS';
  modelId: string;
  endpointUrl?: string;
  status: 'ACTIVE' | 'AVAILABLE';
  isFreeTier: boolean;
  description: string;
}

export interface SkillGraphNode {
  id: string;
  userId: string;
  skillName: string;
  category: string;
  proficiencyLevel: ProficiencyLevel;
  verificationStatus: VerificationStatus;
  score: number; // 0 - 100
  assessedAt?: string;
  certificateHash?: string;
  evidence: {
    screenRecordingId?: string;
    assessmentSubmission?: string;
    googleDriveFileIds?: string[];
    verbalDefenseSummary?: string;
    threePillarScores?: {
      technicalProficiency: number;
      problemSolvingProcess: number;
      verbalDefense: number;
    };
  };
}

export interface AssessmentScenario {
  id: string;
  skillDomain: string;
  track: ProfileTrack;
  tier: ProficiencyLevel;
  title: string;
  description: string;
  context: string;
  taskObjectives: string[];
  initialDataOrCode: string;
  evaluationCriteria: {
    technical: string;
    problemSolving: string;
    verbalDefense: string;
  };
}

export interface GradingResult {
  overallScore: number;
  badgeTier: ProficiencyLevel;
  certificateId: string;
  verificationHash: string;
  pillarScores: {
    technicalProficiency: number;
    problemSolvingProcess: number;
    verbalDefense: number;
  };
  keyStrengths: string[];
  constructiveFeedback: string;
  employerPitchSnippet: string;
  verifiedAt: string;
}

export interface DriveDocument {
  id: string;
  name: string;
  mimeType: string;
  size: string;
  modifiedTime: string;
  thumbnailUrl?: string;
  category: 'CV' | 'PORTFOLIO' | 'CERTIFICATE' | 'VIDEO' | 'PROJECT_ARTIFACT' | 'SPECIFICATION';
  extractedInsights?: string[];
}

export interface MeritProject {
  title: string;
  techStack: string[];
  summary: string;
  liveArtifactUrl?: string;
  outcomes: string[];
}

export interface TailoredResume {
  id: string;
  candidateName: string;
  contactEmail: string;
  contactPhone: string;
  location: string;
  resumeMode: 'MERIT_FIRST_PROJECTS' | 'CAREER_BRIDGE';
  verifiedBadge: {
    tier: ProficiencyLevel;
    skillDomain: string;
    score: number;
    certificateId: string;
    issuedDate: string;
    badgeSealUrl?: string;
  };
  professionalHeadline: string;
  empowermentSummary: string; // Highlights verified capability over traditional corporate pedigree
  verifiedCoreCompetencies: string[];
  keyAchievements: string[];
  meritProjects?: MeritProject[];
  experience: Array<{
    role: string;
    company: string;
    period: string;
    highlights: string[];
  }>;
  careerBreakBridge?: {
    duration: string;
    learningFocus: string;
    projectsUndertaken: string[];
  };
  education: Array<{
    degree: string;
    institution: string;
    year: string;
  }>;
}

export interface Opportunity {
  id: string;
  title: string;
  company: string;
  logoUrl?: string;
  geographicScope: GeographicScope;
  opportunityType: OpportunityType;
  location: string;
  salaryRange: string;
  workModel: 'Remote' | 'Hybrid' | 'On-site';
  matchScore: number; // 0-100%
  requiredBadgeTier: ProficiencyLevel;
  returnshipFriendly: boolean;
  aiNativeFriendly: boolean;
  noDegreeRequired: boolean;
  rawRequirements: string;
  description: string;
  skillsRequired: string[];
  postedDaysAgo: number;
}

export interface ApplicationRecord {
  id: string;
  userId: string;
  opportunityId: string;
  opportunity: Opportunity;
  status: ApplicationStatus;
  customPitch: string;
  tailoredResumeSnapshotId: string;
  submittedAt?: string;
  calendarEvent?: {
    eventId: string;
    meetingTime: string;
    googleMeetUrl: string;
    interviewerName: string;
  };
  sheetsRowId?: string;
  whatsappAlertSent: boolean;
  recruiterNotes?: string;
}

export interface WhatsAppAlert {
  id: string;
  timestamp: string;
  recipientPhone: string;
  type: 'INTERVIEW_INVITE' | 'APPLICATION_SUBMITTED' | 'BADGE_VERIFIED' | 'RECRUITER_VIEW';
  message: string;
  actionUrl?: string;
  status: 'DELIVERED' | 'READ';
}

export interface ProctoringState {
  isScreenSharing: boolean;
  isCameraActive: boolean;
  isAudioActive: boolean;
  antiCheatViolations: Array<{
    timestamp: string;
    type: 'TAB_SWITCH' | 'WINDOW_BLUR' | 'EXTERNAL_AI_SUSPECTED' | 'FACE_NOT_DETECTED';
    description: string;
  }>;
  faceDetected: boolean;
  gazeStatus: 'FOCUSED_ON_SCREEN' | 'LOOKING_AWAY' | 'SUSPICIOUS_GAZE';
  ambientAudioDb: number;
  sessionHeartbeat: number;
}
