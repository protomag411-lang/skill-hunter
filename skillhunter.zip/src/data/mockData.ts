import { AssessmentScenario, Opportunity, UserProfile, DriveDocument, CandidateArchetype, ProfileTrack, MCPServerConfig, AIProviderConfig } from '../types';

export const PROFILE_TRACK_PRESETS: Record<ProfileTrack, UserProfile> = {
  TECHNICAL: {
    id: 'usr-tech-01',
    fullName: 'Alex Chen',
    email: 'alex.chen@worksystems.co',
    phone: '+1 (555) 782-4190',
    location: 'Austin, TX (Hybrid & Remote Ready)',
    track: 'TECHNICAL',
    trackName: 'Systems & Coordination',
    archetype: 'EXPERIENCED_BUILDER',
    careerGapYears: 2,
    gapReason: 'Professional sabbatical focused on organizing team workflows, cross-department communication, and reliable project delivery systems.',
    targetRole: 'Workflow & Systems Project Coordinator',
    primarySkill: 'Systems & Coordination',
    preferredScope: 'NATIONAL',
    workAuthorization: 'Authorized to work without restriction',
    linkedInUrl: 'https://linkedin.com/in/alex-chen-systems',
    portfolioUrl: 'https://alexchen-systems.org',
    selfTaughtSummary: 'Proven ability to organize team workflows, streamline daily handoffs, and deliver projects on schedule with clear communication.',
  },
  NON_TECHNICAL: {
    id: 'usr-nontech-02',
    fullName: 'Elena Rostova',
    email: 'elena.rostova@marketgrowth.io',
    phone: '+1 (555) 438-2910',
    location: 'Chicago, IL (Hybrid & Remote Ready)',
    track: 'NON_TECHNICAL',
    trackName: 'Business & Operations',
    archetype: 'CAREER_RETURNER',
    careerGapYears: 3,
    gapReason: 'Caregiving sabbatical and career return; focused on business planning, budget allocation, operational strategy, and executive reporting.',
    targetRole: 'Senior Business Strategy & Operations Lead',
    primarySkill: 'Business & Operations',
    preferredScope: 'NATIONAL',
    workAuthorization: 'Authorized to work without restriction',
    linkedInUrl: 'https://linkedin.com/in/elena-rostova-growth',
    portfolioUrl: 'https://elenarostova-strategy.com',
    selfTaughtSummary: 'Direct track record managing business budgets, improving operational efficiency, and delivering clear executive reports to leadership.',
  },
  MANUAL: {
    id: 'usr-manual-03',
    fullName: 'David Miller',
    email: 'david.miller@precisioncraft.net',
    phone: '+1 (555) 614-9982',
    location: 'Atlanta, GA (On-site & Workshop Ready)',
    track: 'MANUAL',
    trackName: 'Hands-On & Craft',
    archetype: 'CAREER_SWITCHER',
    careerGapYears: 1,
    gapReason: 'Independent workshop residency mastering hands-on craftsmanship, material quality control, and zero-defect inspection standards.',
    targetRole: 'Quality Assurance & Craftsmanship Lead',
    primarySkill: 'Hands-On & Craft',
    preferredScope: 'REGIONAL',
    workAuthorization: 'Authorized to work without restriction',
    linkedInUrl: 'https://linkedin.com/in/david-miller-craft',
    portfolioUrl: 'https://davidmiller-craftsmanship.com',
    selfTaughtSummary: 'Extensive practical experience in high-standard craftsmanship, physical material inspection, and dependable quality control.',
  },
};

export const ARCHETYPE_PRESETS: Record<CandidateArchetype, UserProfile> = {
  EXPERIENCED_BUILDER: PROFILE_TRACK_PRESETS.TECHNICAL,
  CAREER_RETURNER: PROFILE_TRACK_PRESETS.NON_TECHNICAL,
  FRESH_GRADUATE: {
    ...PROFILE_TRACK_PRESETS.TECHNICAL,
    id: 'usr-fg-04',
    fullName: 'Priya Sharma',
    archetype: 'FRESH_GRADUATE',
    careerGapYears: 0,
    gapReason: 'Recent graduate bypassing traditional pedigree gatekeeping through direct demonstration of workflow execution and digital operations mastery.',
    targetRole: 'Digital Operations Analyst & Systems Associate',
    selfTaughtSummary: 'Demonstrated exceptional problem-solving and structured project coordination during live proctored simulations.',
  },
  CAREER_SWITCHER: PROFILE_TRACK_PRESETS.MANUAL,
  AI_NATIVE_BUILDER: {
    ...PROFILE_TRACK_PRESETS.TECHNICAL,
    archetype: 'AI_NATIVE_BUILDER',
  },
};

export const DEFAULT_USER: UserProfile = PROFILE_TRACK_PRESETS.TECHNICAL;

export const DEFAULT_MCP_SERVERS: MCPServerConfig[] = [
  {
    id: 'mcp-fs-01',
    name: 'Local Filesystem MCP Server',
    type: 'FILESYSTEM',
    protocolUri: 'mcp://filesystem/workplace-archive',
    status: 'CONNECTED',
    description: 'Secures direct local access to project documents, work portfolios, and case briefs without cloud data exposure.',
    enabled: true,
    capabilities: ['Read Directory', 'Index Documents', 'Safe File Ingestion'],
    latencyMs: 12,
  },
  {
    id: 'mcp-db-02',
    name: 'Enterprise Business Records MCP Server',
    type: 'DATABASE',
    protocolUri: 'mcp://database/operational-ledger',
    status: 'CONNECTED',
    description: 'Queries internal business records, client engagement rosters, and operational inventory through safe parameterized access.',
    enabled: true,
    capabilities: ['Read-Only Records', 'Schema Verification', 'Client Roster Sync'],
    latencyMs: 18,
  },
  {
    id: 'mcp-ws-03',
    name: 'Google Workspace & Productivity MCP Server',
    type: 'WORKSPACE',
    protocolUri: 'mcp://google-workspace/drive-and-docs',
    status: 'CONNECTED',
    description: 'Synchronizes project drafts, spreadsheets, presentation decks, and executive schedules seamlessly.',
    enabled: true,
    capabilities: ['Drive Read', 'Calendar Event Scheduling', 'Sheets Milestone Logging'],
    latencyMs: 45,
  },
  {
    id: 'mcp-custom-04',
    name: 'Custom Local Tool Protocol',
    type: 'CUSTOM',
    protocolUri: 'http://localhost:8080/sse',
    status: 'DISCONNECTED',
    description: 'Connects any local tool or private corporate microservice following the open Model Context Protocol standard.',
    enabled: false,
    capabilities: ['Custom RPC Calling', 'Local Tool Execution'],
    latencyMs: 0,
  },
];

export const DEFAULT_AI_PROVIDERS: AIProviderConfig[] = [
  {
    id: 'ai-prov-gemini',
    name: 'Google AI Studio (Gemini 3.6 Flash / 3.1 Flash-Lite)',
    type: 'GOOGLE_AI_STUDIO',
    modelId: 'gemini-3.6-flash',
    status: 'ACTIVE',
    isFreeTier: true,
    description: 'High-speed, enterprise-grade AI engine providing deep reasoning, candidate evaluation, and resume synthesis.',
  },
  {
    id: 'ai-prov-local',
    name: 'Local Open-Weights Engine (Ollama / vLLM)',
    type: 'LOCAL_OPEN_WEIGHTS',
    modelId: 'llama-3.3-70b-instruct-local',
    endpointUrl: 'http://localhost:11434/v1',
    status: 'AVAILABLE',
    isFreeTier: true,
    description: 'Runs entirely on your local machine for complete data confidentiality, zero external API costs, and offline autonomy.',
  },
];

export const SKILL_DOMAINS = [
  {
    id: 'systems-coordination',
    name: 'Systems & Coordination',
    track: 'TECHNICAL' as ProfileTrack,
    icon: 'Layers',
    description: 'Organizing workflows, teamwork, project delivery, and operational coordination.',
    popularTools: ['Workflow Coordination Boards', 'Team Communication Tools', 'Project Delivery Planners', 'Operational Checklist Systems'],
  },
  {
    id: 'business-operations',
    name: 'Business & Operations',
    track: 'NON_TECHNICAL' as ProfileTrack,
    icon: 'TrendingUp',
    description: 'Business planning, strategy, budgets, and executive reporting.',
    popularTools: ['Business Planning Sheets', 'Budget Allocation Matrices', 'Executive Summary Portals', 'Performance Dashboards'],
  },
  {
    id: 'hands-on-craft',
    name: 'Hands-On & Craft',
    track: 'MANUAL' as ProfileTrack,
    icon: 'Award',
    description: 'Quality control, practical work, craftsmanship, and inspection standards.',
    popularTools: ['Precision Measurement Tools', 'Quality Assurance Checklists', 'Material Inspection Guidelines', 'Craftsmanship Logbooks'],
  },
];

export const ASSESSMENT_SCENARIOS: Record<string, Record<string, AssessmentScenario>> = {
  'Digital Systems & Workflow Coordination': {
    BEGINNER: {
      id: 'tech-beg-01',
      skillDomain: 'Digital Systems & Workflow Coordination',
      track: 'TECHNICAL',
      tier: 'BEGINNER',
      title: 'Digital Process Streamlining & Team Handshake Setup',
      description: 'Audit a multi-stage team handoff process, eliminate communication bottlenecks, and structure an automated intake checklist.',
      context: 'An operational department experiences a 48-hour delay transferring project specifications between intake and delivery teams due to manual re-entry.',
      taskObjectives: [
        'Formulate a standardized digital intake specification with mandatory verification fields.',
        'Define automated notification rules so incoming work is immediately routed to the responsible specialist.',
        'Establish an escalation threshold when a request remains unassigned for more than 2 hours.',
      ],
      initialDataOrCode: `Intake Workflow Baseline Parameters:
- Current Average Intake Latency: 48 hours
- Unassigned Work Queue Drop-Off Rate: 14%
- Core Handshake Stages:
  1. Client Submission -> 2. Manual Review -> 3. Resource Assignment -> 4. Delivery Handoff
- Target Latency Goal: Under 4 hours with 100% routing auditability`,
      evaluationCriteria: {
        technical: 'Clear, structured decomposition of workflow stages and routing logic.',
        problemSolving: 'Pragmatic removal of friction points without complicating the user journey.',
        verbalDefense: 'Concise explanation of operational efficiency gains to executive leadership.',
      },
    },
    INTERMEDIATE: {
      id: 'tech-int-01',
      skillDomain: 'Digital Systems & Workflow Coordination',
      track: 'TECHNICAL',
      tier: 'INTERMEDIATE',
      title: 'Cross-Departmental Workflow Orchestration & Data Flow Auditing',
      description: 'Design a unified project handoff architecture connecting three disparate business applications with real-time status visibility.',
      context: 'Project managers waste 12 hours weekly reconciling inconsistent milestone statuses between sales, customer success, and service delivery systems.',
      taskObjectives: [
        'Draft an automated status synchronization framework with bidirectional update triggers.',
        'Create a conflict resolution guideline when milestone dates are modified simultaneously by separate teams.',
        'Establish an executive visibility dashboard displaying overall project health and milestone completion times.',
      ],
      initialDataOrCode: `Departmental System Mapping:
- Sales Portal: Tracks initial scope, contracted milestones, and account tier
- Project Delivery Platform: Tracks active deliverables, team assignments, and target deadlines
- Customer Success Roster: Tracks client satisfaction ratings and renewal dates
- Core Operational Defect: Status updates in one platform fail to propagate to partner teams, causing client escalations.`,
      evaluationCriteria: {
        technical: 'Structured workflow mapping, fail-safe data validation, and clean event coordination.',
        problemSolving: 'Balanced approach to data reconciliation that respects team autonomy.',
        verbalDefense: 'Articulate presentation of ROI and time savings across departmental stakeholders.',
      },
    },
    ADVANCED: {
      id: 'tech-adv-01',
      skillDomain: 'Digital Systems & Workflow Coordination',
      track: 'TECHNICAL',
      tier: 'ADVANCED',
      title: 'Enterprise Multi-System Automation & Incident Recovery Protocol',
      description: 'Architect a high-resilience operational continuity framework that reroutes critical tasks automatically during service interruptions.',
      context: 'A global logistics and service network requires a fault-tolerant workflow system capable of handling 50,000 monthly service requests with zero data loss.',
      taskObjectives: [
        'Establish an automated failover strategy that switches to a secondary queue when primary response times exceed 1.5 seconds.',
        'Define clear prioritization rules: categorize urgent client inquiries vs routine notifications to protect system throughput.',
        'Produce an executive-ready business continuity summary explaining risk mitigation measures.',
      ],
      initialDataOrCode: `Service Operational Parameters:
- Monthly Request Volume: 50,000 requests
- Primary Response Time Target: Under 1,200 ms
- Failover Threshold: Trigger automated secondary routing at 1,500 ms latency
- Priority Tiering:
  * Tier 1 (Urgent Fulfillment): Guaranteed sub-5-minute dispatch
  * Tier 2 (Standard Processing): Normal scheduling within 4 hours
  * Tier 3 (Informational Logs): Low-priority background sync`,
      evaluationCriteria: {
        technical: 'Comprehensive grasp of workflow resilience, queue balancing, and service level agreements (SLAs).',
        problemSolving: 'Effective handling of edge cases, failover routing, and bottleneck mitigation.',
        verbalDefense: 'Executive authority, strategic clarity, and confident verbal defense.',
      },
    },
  },
  'Growth Strategy & Marketing Operations': {
    BEGINNER: {
      id: 'growth-beg-01',
      skillDomain: 'Growth Strategy & Marketing Operations',
      track: 'NON_TECHNICAL',
      tier: 'BEGINNER',
      title: 'Audience Segmentation & Marketing Funnel Efficiency Review',
      description: 'Analyze audience response data, identify drop-off stages in the customer journey, and restructure the onboarding sequence.',
      context: 'An expanding regional brand is experiencing high interest on initial promotions but noticing a 42% abandonment rate before first purchase.',
      taskObjectives: [
        'Segment prospective customers based on interest level and engagement frequency.',
        'Formulate a 3-touchpoint follow-up schedule designed to answer common buyer questions.',
        'Establish core success metrics: calculate conversion uplift and cost-per-lead improvements.',
      ],
      initialDataOrCode: `Campaign Performance Snapshot:
- Initial Promotional Reach: 85,000 prospective buyers
- Inbound Inquiry Rate: 6.4% (5,440 inquiries)
- Funnel Abandonment Point: Between initial consultation and confirmation (42% drop)
- Projected Return on Ad Spend (ROAS): 2.4x
- Strategic Objective: Elevate ROAS to 3.5x through targeted messaging and timely follow-up`,
      evaluationCriteria: {
        technical: 'Solid grasp of conversion funnel economics, audience segmentation, and touchpoint design.',
        problemSolving: 'Creative, practical adjustments to messaging that rebuild buyer trust.',
        verbalDefense: 'Clear, compelling narrative on customer lifecycle value.',
      },
    },
    INTERMEDIATE: {
      id: 'growth-int-01',
      skillDomain: 'Growth Strategy & Marketing Operations',
      track: 'NON_TECHNICAL',
      tier: 'INTERMEDIATE',
      title: 'Commercial Growth Strategy & Omnichannel Budget Reallocation',
      description: 'Rebalance a $150,000 quarterly promotional budget across digital, search, and partnership channels to maximize overall efficiency.',
      context: 'Rising advertising costs in paid search have compressed profit margins; the marketing director must reallocate capital toward higher-performing channels.',
      taskObjectives: [
        'Audit historical performance across three promotional channels to determine true customer acquisition cost (CAC).',
        'Model a revised budget distribution that redirects underperforming spend into organic partnership and retargeting initiatives.',
        'Formulate an executive reporting memo justifying the reallocation strategy with projected return projections.',
      ],
      initialDataOrCode: `Quarterly Budget Baseline ($150,000 Total Allocation):
- Paid Search Advertising: $75,000 (Current CAC: $140, Diminishing Returns)
- Partner & Referral Networks: $45,000 (Current CAC: $62, High Conversion Quality)
- Brand Engagement & Retargeting: $30,000 (Current CAC: $48, High Retention)
- Target Blended Efficiency: Reduce average customer acquisition cost from $95 to $68`,
      evaluationCriteria: {
        technical: 'Disciplined financial modeling of customer acquisition cost and return on investment.',
        problemSolving: 'Strategic capital reallocation that preserves brand reach while boosting profitability.',
        verbalDefense: 'Authoritative, business-minded defense of budget decisions.',
      },
    },
    ADVANCED: {
      id: 'growth-adv-01',
      skillDomain: 'Growth Strategy & Marketing Operations',
      track: 'NON_TECHNICAL',
      tier: 'ADVANCED',
      title: 'Executive Marketing Operations & Global Brand Scaling Roadmap',
      description: 'Design a scalable multi-market commercial expansion strategy managing a $1.2M budget pool across three global territories.',
      context: 'An international enterprise is preparing expansion into European and Asia-Pacific markets while navigating varied regional buyer expectations.',
      taskObjectives: [
        'Formulate a territory budget allocation matrix across North America (55%), Europe (30%), and Asia-Pacific (15%).',
        'Establish an executive performance dashboard tracking customer retention, lifetime value, and marketing efficiency ratio.',
        'Draft a risk management protocol addressing market saturation, seasonal demand shifts, and competitive reactions.',
      ],
      initialDataOrCode: `Global Capital Distribution ($1.2M Monthly Pool):
- North American Foundation: $660,000 (Targeting 4.2x Return on Spend)
- European Expansion Market: $360,000 (Targeting 3.6x Return on Spend)
- Asia-Pacific Market Launch: $180,000 (Targeting 3.0x Return on Spend)
- Target Blended Marketing Efficiency Ratio (MER): 3.8x minimum`,
      evaluationCriteria: {
        technical: 'Mastery of macro-budgeting, customer lifetime value modeling, and multi-market KPI architectures.',
        problemSolving: 'Nuanced capital distribution mitigating channel fatigue and market-entry friction.',
        verbalDefense: 'Executive presence, polished delivery, and confident defense of strategic assumptions.',
      },
    },
  },
  'Precision Craftsmanship & Quality Control': {
    BEGINNER: {
      id: 'manual-beg-01',
      skillDomain: 'Precision Craftsmanship & Quality Control',
      track: 'MANUAL',
      tier: 'BEGINNER',
      title: 'Material Inspection & Defect Identification Audit',
      description: 'Conduct a physical quality assessment on incoming hardwood and architectural substrates, documenting defects against tolerances.',
      context: 'A custom architectural millwork workshop received a shipment of premium walnut with variable moisture content and surface checking.',
      taskObjectives: [
        'Inspect incoming material samples against standard grain uniformity and moisture tolerance thresholds (6-8%).',
        'Classify defects into repairable surface blemishes vs structural rejections.',
        'Compile an intake inspection log with clear acceptance or vendor return recommendations.',
      ],
      initialDataOrCode: `Material Intake Specifications:
- Substrate: Premium Architectural Grade American Walnut
- Moisture Tolerance Window: 6.0% to 8.5%
- Inspection Lot Size: 120 board feet
- Recorded Deviations: 8 boards show surface checking; 4 boards exceed 10.2% moisture content
- Operational Standard: 100% defect containment prior to machining`,
      evaluationCriteria: {
        technical: 'Accurate knowledge of material properties, moisture tolerances, and grading standards.',
        problemSolving: 'Disciplined sorting that maximizes usable yield while safeguarding final product integrity.',
        verbalDefense: 'Clear, practical justification for material acceptance and rejection decisions.',
      },
    },
    INTERMEDIATE: {
      id: 'manual-int-01',
      skillDomain: 'Precision Craftsmanship & Quality Control',
      track: 'MANUAL',
      tier: 'INTERMEDIATE',
      title: 'High-Precision Surface Preparation & Coating Formulation',
      description: 'Formulate a multi-stage surface preparation and durable finishing procedure for high-wear hospitality installations.',
      context: 'A boutique luxury hotel requires custom tabletops that withstand daily commercial sanitization without losing warmth or natural grain depth.',
      taskObjectives: [
        'Specify an incremental sanding grit progression (80 -> 120 -> 180 -> 240) with grain-raising protocols.',
        'Select a chemical-resistant topcoat formulation balancing UV resistance, hardness, and repairability.',
        'Establish a step-by-step quality checkpoint schedule before final delivery.',
      ],
      initialDataOrCode: `Finishing Protocol Parameters:
- Surface Substrate: Solid White Oak with Quarter-Sawn Figure
- Environmental Exposure: Daily sanitization wiping, ambient UV exposure, high wear
- Target Finish Thickness: 3.5 mils dry film build
- Curing Schedule: 24-hour intercoat interval, 72-hour full cure before commercial packing
- Benchmark Standards: Zero orange peel, zero micro-bubbles, uniform satin sheen (25-30 GU)`,
      evaluationCriteria: {
        technical: 'Deep understanding of substrate preparation, resin chemistry, and finishing tools.',
        problemSolving: 'Balancing aesthetic beauty with commercial durability requirements.',
        verbalDefense: 'Professional communication detailing craftsmanship techniques and maintenance guidelines.',
      },
    },
    ADVANCED: {
      id: 'manual-adv-01',
      skillDomain: 'Precision Craftsmanship & Quality Control',
      track: 'MANUAL',
      tier: 'ADVANCED',
      title: 'Master Craftsmanship Restoration & Architectural Quality Assurance',
      description: 'Execute an end-to-end historic surface restoration plan, rectifying structural delamination while matching original patina.',
      context: 'A designated historic landmark interior requires restoration of 19th-century mahogany wall paneling damaged by water infiltration.',
      taskObjectives: [
        'Formulate a non-invasive stabilization method for degraded structural veneer without disturbing surrounding woodwork.',
        'Develop a reversible, conservation-grade color blending formulation matching aged historic patina.',
        'Produce an exhaustive Quality Assurance and Conservation Report for architectural preservation authorities.',
      ],
      initialDataOrCode: `Historic Restoration Field Conditions:
- Workpiece: 1890s Honduran Mahogany architectural millwork
- Damage Extent: 14 linear feet of lower wainscot exhibiting localized veneer lift and finish blanching
- Preservation Requirement: All conservation treatments must be fully documented and reversible
- Quality Tolerance: Color match tolerance under 1.5 Delta E; substrate flatness within 0.5 mm`,
      evaluationCriteria: {
        technical: 'Mastery of historic materials, reversible conservation ethics, and precision leveling.',
        problemSolving: 'Flawless stabilization of delicate architectural elements under strict historic standards.',
        verbalDefense: 'Expert, authoritative defense of conservation choices before architects and preservation boards.',
      },
    },
  },
};

// Aliases for clean professional track keys
ASSESSMENT_SCENARIOS['Systems & Coordination'] = ASSESSMENT_SCENARIOS['Digital Systems & Workflow Coordination'];
ASSESSMENT_SCENARIOS['Business & Operations'] = ASSESSMENT_SCENARIOS['Growth Strategy & Marketing Operations'];
ASSESSMENT_SCENARIOS['Hands-On & Craft'] = ASSESSMENT_SCENARIOS['Precision Craftsmanship & Quality Control'];

export const INITIAL_DRIVE_DOCS: DriveDocument[] = [
  {
    id: 'drv-doc-01',
    name: 'Workflow & Operations Guide.pdf',
    mimeType: 'application/pdf',
    size: '3.4 MB',
    modifiedTime: '2026-03-12',
    category: 'SPECIFICATION',
    extractedInsights: [
      'How you organized daily tasks, fixed delays, and sped up projects by 76%.',
    ],
  },
  {
    id: 'drv-doc-02',
    name: 'Business Growth Report.pdf',
    mimeType: 'application/pdf',
    size: '4.8 MB',
    modifiedTime: '2026-02-18',
    category: 'PORTFOLIO',
    extractedInsights: [
      'Your budgeting plans, cost savings, and leadership results (achieving a 3.8x return).',
    ],
  },
  {
    id: 'drv-doc-03',
    name: 'Practical Quality Manual.pdf',
    mimeType: 'application/pdf',
    size: '2.9 MB',
    modifiedTime: '2026-01-24',
    category: 'PROJECT_ARTIFACT',
    extractedInsights: [
      'Step-by-step guides for hands-on restoration and quality checks with zero errors.',
    ],
  },
  {
    id: 'drv-doc-04',
    name: 'Leadership Certificate.pdf',
    mimeType: 'application/pdf',
    size: '950 KB',
    modifiedTime: '2025-11-04',
    category: 'CERTIFICATE',
    extractedInsights: [
      'Official recognition for team leadership and process improvement.',
    ],
  },
];

export const MOCK_OPPORTUNITIES: Opportunity[] = [
  // Technical Track Openings
  {
    id: 'opp-tech-01',
    title: 'Systems & Operations Specialist',
    company: 'Nexus Enterprise Solutions',
    geographicScope: 'NATIONAL',
    opportunityType: 'JOB',
    location: 'United States (Hybrid / Remote)',
    salaryRange: '$125,000 - $155,000 / year + Benefits',
    workModel: 'Remote',
    matchScore: 99,
    requiredBadgeTier: 'ADVANCED',
    returnshipFriendly: true,
    aiNativeFriendly: true,
    noDegreeRequired: true,
    skillsRequired: ['Systems & Coordination', 'Process Automation', 'Stakeholder Communication', 'Operational Reporting'],
    postedDaysAgo: 1,
    description: 'Lead team coordination and service delivery. We hire based on proven ability rather than traditional resume checks.',
    rawRequirements: 'Verified Skill Hunter certification in Systems & Coordination. Proven ability to streamline complex business workflows.',
  },
  {
    id: 'opp-tech-02',
    title: 'Workflow & Operations Coordinator',
    company: 'Horizon Logistics & Transport',
    geographicScope: 'REGIONAL',
    opportunityType: 'CONTRACT',
    location: 'Austin, TX (Hybrid)',
    salaryRange: '$65 - $85 / hour',
    workModel: 'Hybrid',
    matchScore: 95,
    requiredBadgeTier: 'INTERMEDIATE',
    returnshipFriendly: true,
    aiNativeFriendly: true,
    noDegreeRequired: true,
    skillsRequired: ['Systems & Coordination', 'Resource Scheduling', 'Distribution Hub Tracking', 'Team Handoffs'],
    postedDaysAgo: 2,
    description: 'Coordinate daily tracking and resource scheduling across distribution hubs. Return-to-work and self-taught professionals warmly welcomed.',
    rawRequirements: 'Demonstrated problem-solving skill, clear verbal explanation, and verified workflow management mastery.',
  },

  // Non-Technical Track Openings
  {
    id: 'opp-nontech-01',
    title: 'Growth & Operations Director',
    company: 'Solstice Consumer Brands',
    geographicScope: 'NATIONAL',
    opportunityType: 'JOB',
    location: 'United States (100% Remote)',
    salaryRange: '$135,000 - $165,000 / year + Bonus',
    workModel: 'Remote',
    matchScore: 98,
    requiredBadgeTier: 'ADVANCED',
    returnshipFriendly: true,
    aiNativeFriendly: false,
    noDegreeRequired: true,
    skillsRequired: ['Business & Operations', 'Multi-channel Growth', 'Commercial Budgets', 'Executive Reporting'],
    postedDaysAgo: 1,
    description: 'Manage multi-channel growth and commercial budgets. We evaluate practical performance over resume histories.',
    rawRequirements: 'Verified Skill Hunter Gold/Silver badge in Business & Operations. Proven experience managing budgets and articulating clear ROI.',
  },
  {
    id: 'opp-nontech-02',
    title: 'International Business Strategy Lead',
    company: 'Vantage Global Partners',
    geographicScope: 'INTERNATIONAL',
    opportunityType: 'JOB',
    location: 'Global Remote',
    salaryRange: '$140,000 - $170,000 USD / year',
    workModel: 'Remote',
    matchScore: 94,
    requiredBadgeTier: 'ADVANCED',
    returnshipFriendly: true,
    aiNativeFriendly: false,
    noDegreeRequired: false,
    skillsRequired: ['Business & Operations', 'International Strategy', 'Cross-Border Expansion', 'Performance Reporting'],
    postedDaysAgo: 3,
    description: 'Drive international business initiatives. Flexible, merit-focused culture welcoming professionals returning to work.',
    rawRequirements: 'Demonstrated ability to drive international initiatives and communicate strategic directions with clarity.',
  },

  // Manual Track Openings
  {
    id: 'opp-manual-01',
    title: 'Master Quality & Restoration Lead',
    company: 'Heritage Architectural Guild',
    geographicScope: 'REGIONAL',
    opportunityType: 'JOB',
    location: 'Atlanta, GA (On-site)',
    salaryRange: '$95,000 - $125,000 / year + Bonus',
    workModel: 'On-site',
    matchScore: 97,
    requiredBadgeTier: 'ADVANCED',
    returnshipFriendly: true,
    aiNativeFriendly: false,
    noDegreeRequired: true,
    skillsRequired: ['Hands-On & Craft', 'Surface Restoration', 'Material Inspection', 'Quality Assurance Protocols'],
    postedDaysAgo: 2,
    description: 'Direct high-precision surface restoration and quality checks for major projects. A crafts-first organization that values hands-on skill.',
    rawRequirements: 'Verified Skill Hunter badge in Hands-On & Craft. Demonstrated mastery of substrate inspection and tolerance standards.',
  },
  {
    id: 'opp-manual-02',
    title: 'Quality Control Specialist',
    company: 'Artisan Architectural Millwork',
    geographicScope: 'REGIONAL',
    opportunityType: 'CONTRACT',
    location: 'Chicago, IL (Workshop)',
    salaryRange: '$55 - $75 / hour',
    workModel: 'On-site',
    matchScore: 93,
    requiredBadgeTier: 'INTERMEDIATE',
    returnshipFriendly: true,
    aiNativeFriendly: false,
    noDegreeRequired: true,
    skillsRequired: ['Hands-On & Craft', 'Material Testing', 'Finishing Compliance', 'Inspection Checklists'],
    postedDaysAgo: 4,
    description: 'Oversee material inspection, testing, and surface finish compliance for custom commercial projects.',
    rawRequirements: 'Hands-on practical capability, precision measuring equipment fluency, and strong attention to quality detail.',
  },
];
