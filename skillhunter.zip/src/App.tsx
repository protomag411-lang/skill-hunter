import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { PhaseProgressStepper } from './components/PhaseProgressStepper';
import { MCPIntegrationModal } from './components/MCPIntegrationModal';
import { Phase1Dialogue } from './components/Phase1Dialogue';
import { Phase2Proctoring } from './components/Phase2Proctoring';
import { Phase3Assessment } from './components/Phase3Assessment';
import { Phase4GoogleDrive } from './components/Phase4GoogleDrive';
import { Phase5TailoredResume } from './components/Phase5TailoredResume';
import { Phase6OpportunityDiscovery } from './components/Phase6OpportunityDiscovery';
import { Phase7HITLAndIntegrations } from './components/Phase7HITLAndIntegrations';
import { AIInterviewPrepAgent } from './components/AIInterviewPrepAgent';
import { SkillMonetizationModule } from './components/SkillMonetizationModule';
import { SkiVoiceAgent } from './components/SkiVoiceAgent';
import { 
  UserProfile, 
  GradingResult, 
  ProctoringState, 
  DriveDocument, 
  TailoredResume, 
  Opportunity 
} from './types';
import { DEFAULT_USER, INITIAL_DRIVE_DOCS, MOCK_OPPORTUNITIES, PROFILE_TRACK_PRESETS } from './data/mockData';

export default function App() {
  const [currentPhase, setCurrentPhase] = useState<number>(1);
  const [isMCPModalOpen, setIsMCPModalOpen] = useState<boolean>(false);
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);
  const [selectedSkill, setSelectedSkill] = useState<string>(DEFAULT_USER.primarySkill);
  
  const [proctoringState, setProctoringState] = useState<ProctoringState>({
    isScreenSharing: false,
    isCameraActive: false,
    isAudioActive: false,
    antiCheatViolations: [],
    faceDetected: false,
    gazeStatus: 'FOCUSED_ON_SCREEN',
    ambientAudioDb: 25,
    sessionHeartbeat: Date.now(),
  });

  const [badge, setBadge] = useState<GradingResult | null>(null);
  const [driveDocs, setDriveDocs] = useState<DriveDocument[]>(INITIAL_DRIVE_DOCS);
  const [tailoredResume, setTailoredResume] = useState<TailoredResume | null>(null);
  const [selectedOpportunities, setSelectedOpportunities] = useState<Opportunity[]>(MOCK_OPPORTUNITIES);

  const handleUpdateUser = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
    if (updated.primarySkill) {
      setSelectedSkill(updated.primarySkill);
    }
  };

  const handleProceedToProctoring = (skill: string) => {
    setSelectedSkill(skill);
    handleUpdateUser({ primarySkill: skill });
    setCurrentPhase(2);
  };

  const handleProceedToAssessment = (pState: ProctoringState) => {
    setProctoringState(pState);
    setCurrentPhase(3);
  };

  const handleAssessmentCompleted = (grade: GradingResult) => {
    setBadge(grade);
  };

  const handleProceedToDrive = () => {
    setCurrentPhase(4);
  };

  const handleProceedToResume = (docs: DriveDocument[]) => {
    setDriveDocs(docs);
    setCurrentPhase(5);
  };

  const handleProceedToJobDiscovery = (resume: TailoredResume) => {
    setTailoredResume(resume);
    setCurrentPhase(6);
  };

  const handleProceedToHITL = (opportunities: Opportunity[]) => {
    setSelectedOpportunities(opportunities);
    setCurrentPhase(7);
  };

  const handleResetWorkflow = () => {
    setCurrentPhase(1);
    setBadge(null);
  };

  return (
    <div className="min-h-screen quantum-bg text-slate-900 flex flex-col font-sans selection:bg-emerald-200 selection:text-emerald-950">
      <Navbar
        currentPhase={currentPhase}
        onSelectPhase={(phase) => setCurrentPhase(phase)}
        user={user}
        badge={badge}
        onOpenMCPModal={() => setIsMCPModalOpen(true)}
        onResetWorkflow={handleResetWorkflow}
      />

      {/* Visual 9-Phase Workflow Stepper */}
      <PhaseProgressStepper
        currentPhase={currentPhase}
        onSelectPhase={(phase) => setCurrentPhase(phase)}
        user={user}
        onSelectTrack={(track) => handleUpdateUser(PROFILE_TRACK_PRESETS[track])}
        onOpenMCPModal={() => setIsMCPModalOpen(true)}
      />

      <main className="flex-1 pb-16">
        {currentPhase === 1 && (
          <Phase1Dialogue
            user={user}
            onUpdateUser={handleUpdateUser}
            onProceedToProctoring={handleProceedToProctoring}
          />
        )}

        {currentPhase === 2 && (
          <Phase2Proctoring
            selectedSkill={selectedSkill}
            userPhone={user.phone}
            onProceedToAssessment={handleProceedToAssessment}
          />
        )}

        {currentPhase === 3 && (
          <Phase3Assessment
            selectedSkill={selectedSkill}
            proctoring={proctoringState}
            onAssessmentCompleted={handleAssessmentCompleted}
            onProceedToDrive={handleProceedToDrive}
            existingBadge={badge}
          />
        )}

        {currentPhase === 4 && (
          <Phase4GoogleDrive
            user={user}
            badge={badge}
            onProceedToResume={handleProceedToResume}
          />
        )}

        {currentPhase === 5 && (
          <Phase5TailoredResume
            user={user}
            badge={badge}
            driveDocs={driveDocs}
            onProceedToJobDiscovery={handleProceedToJobDiscovery}
          />
        )}

        {currentPhase === 6 && (
          <Phase6OpportunityDiscovery
            user={user}
            badge={badge}
            onProceedToHITL={handleProceedToHITL}
            onLaunchSellingEngine={() => setCurrentPhase(9)}
            onOpenInterviewPrep={() => setCurrentPhase(8)}
          />
        )}

        {currentPhase === 7 && (
          <Phase7HITLAndIntegrations
            selectedOpportunities={selectedOpportunities}
            user={user}
            badge={badge}
            onResetWorkflow={handleResetWorkflow}
            onOpenInterviewPrep={() => setCurrentPhase(8)}
            onLaunchSellingEngine={() => setCurrentPhase(9)}
          />
        )}

        {currentPhase === 8 && (
          <AIInterviewPrepAgent
            user={user}
            badge={badge}
            onClose={() => setCurrentPhase(7)}
            onProceedToMonetization={() => setCurrentPhase(9)}
          />
        )}

        {currentPhase === 9 && (
          <SkillMonetizationModule
            user={user}
            badge={badge}
            onReturnToJobs={() => setCurrentPhase(6)}
          />
        )}
      </main>

      {/* Model Context Protocol (MCP) & AI Provider Integration Modal */}
      <MCPIntegrationModal
        isOpen={isMCPModalOpen}
        onClose={() => setIsMCPModalOpen(false)}
      />

      {/* Interactive Global Voice Assistant powered by Ski */}
      <SkiVoiceAgent
        currentPhase={currentPhase}
        user={user}
      />

      {/* Persistent Minimal Footer */}
      <footer className="quantum-glass text-slate-600 text-xs py-6 border-t border-emerald-500/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-900">Skill Hunter</span>
            <span>—</span>
            <span className="text-slate-600">Career Acceleration & Placement Navigator</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <span className="text-emerald-700 font-semibold">Verified Skills Standard</span>
            <span>•</span>
            <span>Google Workspace Synchronized</span>
            <span>•</span>
            <span className="text-emerald-700 font-semibold">Guided by Ski</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
